cls

Remove-Variable * -ErrorAction SilentlyContinue; Remove-Module *; $error.Clear(); Clear-Host

$Login = "south32\srvDBA"
$password = ConvertTo-SecureString "FXhwX8BCYtutKCbd1fsmRc92HtZtQd24" -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential ($Login, $password)

$Cred = $null # run under current credentials

# update 43
# 26/06/24 - added shared dribes for cluster

# SELECT @SharedDriveNames = @SharedDriveNames + ',' + DriveName FROM sys.dm_io_cluster_shared_drives


# update 42 
# 23/05/2024 - added fixed port 

# Updates 34
# 04/04/2024 - joined with BD-preparation
# 11/07/2023 - Added "Windows Internal Database" into the reports, moved host check in the only one loop 
# 10/07/2023 - Added -and $_.Caption -ne "Windows Internal Database" 
# related to https://www.sqlshack.com/managing-the-windows-internal-database-wid/#:~:text=It%20is%20used%20to%20store,Windows%20system%20resource%20manager



Function GetClusterNodes 
{  param ($NodeName,$Path)
   try {   
        $ClusterNodes = Get-ClusterNode -Cluster $NodeName -ErrorAction SilentlyContinue -WarningAction silentlyContinue #| SELECT Cluster, State, Name
        $ClusterNodes | SELECT Cluster, Name, NodeName, State  | Export-Csv -Path $Path\-clusternodes.csv -append -NoTypeInformation 
        return $ClusterNodes | SELECT Cluster, Name , State
   } catch { return $null }
}

Function GetNodesInstances 
{  param ($NodeName)
   try {   

    $InstancesTable = New-Object System.Data.DataTable
    $InstancesTable.Columns.Add("Instance", "System.String")    | Out-Null 
    $InstancesTable.Columns.Add("Connection","System.String")   | Out-Null 
    $InstancesTable.Columns.Add("PortFixed","System.String")    | Out-Null 
    $InstancesTable.Columns.Add("Host","System.String")         | Out-Null
    $InstancesTable.Columns.Add("Named","System.String")        | Out-Null


        $arrINST = Get-Clusterresource -Cluster $NodeName -ErrorAction SilentlyContinue  -WarningAction silentlyContinue `
        | Where-Object {$_.resourcetype -like 'sql server'} `
        | Get-Clusterparameter "instancename" `
        | Sort-Object objectname `
        | Select-Object -expandproperty value
 
        $arrVSN = Get-Clusterresource -Cluster $NodeName -ErrorAction SilentlyContinue  -WarningAction silentlyContinue `
        | Where-Object {$_.resourcetype -like 'sql server'} `
        | Get-Clusterparameter "virtualservername" `
        | Sort-Object objectname `
        | Select-Object -expandproperty value

        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $NodeName)

        $regKey= $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL" )
        $values = $regkey.GetValueNames()

        foreach ($i in 0..($arrINST.count-1)) {
            if ($arrINST[$i] -ne "MSSQLSERVER") { $Instance = $arrVSN[$i] + "\" + $arrINST[$i] }
                else { $Instance = $arrVSN[$i] }
                
            $InstMatch = $values | where { $_ -eq $arrINST[$i] }

            # check - if instance is alive for this node
            if ($InstMatch -ne $null) {
                    $Inst = $regkey.GetValue($InstMatch)
                    $TcpPort = $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $Inst +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\IPAll").GetValue("TcpPort")
                    if ($TcpPort -ne "" )  {  
                            $PortFixed = $TcpPort ; $connectio_IP = $arrVSN[$i] + "," + $TcpPort } 
                        else { 
                            $PortFixed = "" ; $connectio_IP = $Instance  }
                    $InstancesTable.Rows.Add($Instance, $connectio_IP, $PortFixed, $arrVSN[$i], $arrINST[$i]) | out-null 
                } else { $InstancesTable.Rows.Add($Instance, "Not live on this node","","","" ) | out-null }
        }
        return $InstancesTable
   } catch { return $null }
}


Function GetHostInstances 
{  param ($HostName, $Path)

    $ListInstances = New-Object System.Data.DataTable
    $ListInstances.Columns.Add("Instance", "System.String")    | Out-Null 
    $ListInstances.Columns.Add("Connection","System.String")   | Out-Null 
    $ListInstances.Columns.Add("PortFixed","System.String")    | Out-Null 
    $ListInstances.Columns.Add("Host","System.String")         | Out-Null 
    $ListInstances.Columns.Add("Named","System.String")        | Out-Null

    $ListNodes = GetClusterNodes $HostName $Path

    if ( $ListNodes.count -ne 0 ) {
        foreach ($Node in $ListNodes) {
            $ListInstances += GetNodesInstances $Node.Name $Path 
        }
    } else {

            $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $HostName)
            $regKey= $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL" )
            $values = $regkey.GetValueNames()

            $values | ForEach-Object {
             
                 $h = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $regKey.GetValue($_) +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\IPAll" #+ $f[1].PSChildName
                 $o = $reg.OpenSubKey($h).GetValue("TcpPort").ToString()

                 if (($_ -eq "MSSQLSERVER")) {$Instance = "$HostName"; $Named = "$HostName"
                  } else { $Instance = "$HostName\$_" ; $Named = "$_"}
                  
                 if (($_ -eq "SQLEXPRESS")) {$Instance = "$HostName"; $Named = "$HostName"}     

                 if ($o -ne "" ) {  
                    $PortFixed = $o.ToString() 
                    $connection_IP = $Instance.ToString() + "," +$PortFixed   
                  } else { 
                    $PortFixed = "" 
                    $connection_IP = $Instance.ToString() #+ ",1433" 
                  }

                  if (($_ -eq "SQLEXPRESS")) {$Instance = "$HostName\$_"; $Named = "$HostName";$connection_IP = "$HostName"}     

                  $ListInstances.Rows.Add($Instance, $connection_IP,  $PortFixed, $HostName, $_) | out-null

            }
    }
    $FilteredInstances = $ListInstances | Sort-Object -Property Instance, Connection, PortFixed, Host, Named -Unique | Select-Object Instance, Connection, PortFixed, Host, Named
    return $FilteredInstances
}

####################

# Main BD Report - $Path\-instances.csv 
$TableBD = New-Object System.Data.DataTable
$TableBD.Columns.Add("Type",      "System.String")   | Out-Null
$TableBD.Columns.Add("Name",      "System.String")   | Out-Null  # $i.Instance
$TableBD.Columns.Add("DateInstallation","System.String")   | Out-Null

$TableBD.Columns.Add("ActiveNode","System.String")   | Out-Null  # $recs.ActiveNode
$TableBD.Columns.Add("ListNodes", "System.String")   | Out-Null  # $recs.ListNodes
$TableBD.Columns.Add("SQL sysadmin","System.String") | Out-Null  # $recs.Admin
$TableBD.Columns.Add("LocalAdmin"   ,"System.String")| Out-Null  # #$Instance.OSAdmin
$TableBD.Columns.Add("ErrorLogAcces","System.String")| Out-Null  # #$PathOk
$TableBD.Columns.Add("Account",   "System.String")   | Out-Null
$TableBD.Columns.Add("SQL Version","System.String")  | Out-Null
$TableBD.Columns.Add("SP",        "System.String")   | Out-Null
$TableBD.Columns.Add("CU",        "System.String")   | Out-Null
$TableBD.Columns.Add("KB",        "System.String")   | Out-Null
$TableBD.Columns.Add("Edition",   "System.String")   | Out-Null
$TableBD.Columns.Add("IP",        "System.String")   | Out-Null
$TableBD.Columns.Add("Port",      "System.String")   | Out-Null  # #$port
$TableBD.Columns.Add("PortFixed", "System.String")   | Out-Null
$TableBD.Columns.Add("ErrorLog",  "System.String")   | Out-Null  # #$C
$TableBD.Columns.Add("Clustered", "System.String")   | Out-Null
$TableBD.Columns.Add("AAG (any)", "System.String")   | Out-Null
$TableBD.Columns.Add("LogShipping","System.String")  | Out-Null
$TableBD.Columns.Add("SSAS",      "System.String")   | Out-Null
$TableBD.Columns.Add("SSRS",      "System.String")   | Out-Null
$TableBD.Columns.Add("SSIS",      "System.String")   | Out-Null
$TableBD.Columns.Add("FulTextSerach","System.String")| Out-Null
$TableBD.Columns.Add("LastRestart"  ,"System.String")| Out-Null

$TableBD.Columns.Add("OSversion"    ,"System.String")| Out-Null
$TableBD.Columns.Add("Connection_IP","System.String")| Out-Null
$TableBD.Columns.Add("SharedDrives","System.String") | Out-Null 


$QueryTXTBD = "Declare @aag VARCHAR(50)
Set @aag = 'No'
Declare @logShipping VARCHAR(50)
Set @logShipping = 'No'

declare @IS datetime 

SELECT @IS = create_date 
FROM sys.server_principals
WHERE sid = 0x010100000000000512000000

DECLARE @ClusterDrives VARCHAR(100) =''
SELECT @ClusterDrives  = @ClusterDrives  + ',' + DriveName FROM sys.dm_io_cluster_shared_drives
IF LEN(@ClusterDrives) <> 0 SET @ClusterDrives = SUBSTRING(@ClusterDrives,2,LEN(@ClusterDrives)-1)

DECLARE @NumRec INT = 0

IF (SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)),1,CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)))-1) > 10)
BEGIN
	IF EXISTS( select 1
				from sys.dm_hadr_availability_replica_states ars
				inner join sys.availability_groups ag on ag.group_id = ars.group_id 
				where ars.role_desc = 'PRIMARY'  
                ) Set @aag = 'PRIMARY'
        ELSE Set @aag = 'SECONDARY'

	select @NumRec = COUNT(*)
	from sys.dm_hadr_availability_replica_states ars
	inner join sys.availability_groups ag on ag.group_id = ars.group_id 
	where ars.role_desc = 'PRIMARY'

	IF @NumRec = 0 Set @aag = 'NO'
END

IF EXISTS(	SELECT 1
			FROM msdb.dbo.log_shipping_primary_databases pd
			JOIN msdb.dbo.log_shipping_primary_secondaries ps ON pd.primary_id = ps.primary_id
			JOIN msdb.dbo.log_shipping_monitor_primary mp ON mp.primary_id = pd.primary_id)
  OR EXISTS(SELECT 1
			FROM msdb.dbo.log_shipping_secondary_databases sd
			JOIN msdb.dbo.log_shipping_secondary s ON sd.secondary_id = s.secondary_id
			JOIN msdb.dbo.log_shipping_monitor_secondary ms ON ms.secondary_id = sd.secondary_id)
	Set @logShipping = 'Yes'			

Declare @a varchar(max)
SET @a = ''
SELECT @a = @a + NodeName + ','   FROM sys.dm_os_cluster_nodes

Declare @startTime varchar(max)
SELECT @startTime = create_date FROM sys.databases WHERE name = 'tempdb'
				
SELECT TOP 1
  'SQL instance' AS [Type]
, CAST(@@SERVERNAME AS VARCHAR(20)) AS [Name]
, CAST(CASE WHEN IS_SRVROLEMEMBER('sysadmin') = 1 THEN 'True' else 'False' end AS VARCHAR(50)) as [Admin]
, suser_name() AS [Account], Cast(SERVERPROPERTY('Edition') as varchar(max))  + ' ('+ Cast(SERVERPROPERTY('ProductVersion') as varchar(50)) +')' AS [Edition]

, ISNULL(CONNECTIONPROPERTY('local_net_address'),'please run remotely') AS [IP]
, REPLACE(CAST(SERVERPROPERTY('ErrorLogFileName') AS VARCHAR(500)),':','$') as [ErrorLog]
, CASE WHEN SERVERPROPERTY('IsClustered') = 0 THEN 'No' ELSE 'Yes' END AS [Clustered]
, @aag AS [AAG]
, @logShipping AS [LogShipping]
, CONNECTIONPROPERTY('local_tcp_port') AS [local_tcp_port]
,SERVERPROPERTY('ProductLevel') AS SP
,SERVERPROPERTY('ProductUpdateLevel') AS CU
,SERVERPROPERTY('ProductUpdateReference') AS KB
,CASE 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,1) = '8' THEN 'SQL 2000' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,1) = '9' THEN 'SQL 2005' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = '10' THEN 
		CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,4) = '10.0' THEN 'SQL 2008'
		ELSE 'SQL 2008 R2' END
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 11 THEN 'SQL 2012' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 12 THEN 'SQL 2014' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 13 THEN 'SQL 2016' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 14 THEN 'SQL 2017' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 15 THEN 'SQL 2019' 
    WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 16 THEN 'SQL 2022' 
END AS SQLversion
,SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS ActiveNode
,CASE 
                WHEN @a is NULL OR LTRIM(RTRIM(@a)) = '' THEN ''
                ELSE SUBSTRING(@a,1,len(@a)-1) 
	END AS ListNodes
, @startTime AS [LastRestart]
,SUBSTRING(@@VERSION,CHARINDEX('Windows',@@VERSION),LEN(@@VERSION)-CHARINDEX('Windows',@@VERSION)) [OSversion]
,@ClusterDrives as [ClusterDrives]
,@IS as [installationSQL]
"

####################  START

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
    { Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"; Break }

$SMO = [reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo").ImageRuntimeVersion
if ($SMO -eq $null )
 { Write-Warning "SMO library is not installed on local host"; Break } 
else 
 { if ($SMO.Substring(1,1) -lt 2) { Write-Warning "SMO version less 2 is not supported"; Break } }

# Path where report will be stored. The file names are "-hosts.txt" 
$Path = split-path -parent $MyInvocation.MyCommand.Definition 
if ((Test-Path -Path $Path ) -ne $true) { Write-Warning "The folder '$Path' doesn't exists!"; Break }
if ((Test-Path $Path\hosts.txt) -ne $true) { Write-Warning "The file 'hosts.txt' doesn't exists in the folder $Path!"; Break } 
$Path = $Path + "\"

if (Test-Path $Path\-BD_helpe.csv)     { Remove-Item $Path\-BD_helper.csv }
if (Test-Path $Path\-clusternodes.csv) { Remove-Item $Path\-clusternodes.csv }  # created list of discovered cluster nodes (if any discovered) 
if (Test-Path $Path\-errors.txt)       { Remove-Item $Path\-errors.txt }        # created list of IP interfaces available on host(?)


$Hosts = @()

try { $Hosts = Get-Content $Path\hosts.txt 
    } catch { Write-Warning "$Path\hosts.txt is not readable"; Break }

$RunTime = Get-Date  
$RunningHost = [System.Net.Dns]::GetHostName()
Write-Host "Hosts and SQL Server access check and BD helper script running from $RunningHost" -ForegroundColor Green
if ($Cred -eq $null) { Write-Host "Using credentials $Env:UserDomain\$Env:UserName" -ForegroundColor Green } else { Write-Host "Using credentials $Login" -ForegroundColor Green }
Write-Host "Reports location: $Path" -fore Green
#Write-Host "$RunTime - Getting list of instances on each host" -ForegroundColor Green

#$InstancesArray = $null

$InstancesArray = @() 

foreach ($HostName in $Hosts) {
    #$HostName
    if (($HostName -eq '') -or ($HostName.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string
        $InstancesArray += GetHostInstances $HostName $Path
}


foreach ($i in $InstancesArray) {

    $MSG = "Instance processing: " + $i.Instance + " using connection: " + $i.Connection
    Write-Host $MSG -fore DarkYellow

    try { if ($i.Host -ne $env:COMPUTERNAME) { (Test-Connection -ComputerName $i.Host -Quiet) | Out-Null } } catch { $MSG = $i.Host + " is not accessible";  Write-Warning $MSG; MoveNext }

    $InstanceName = $i.Connection
    $strConn = "server='tcp:$InstanceName';Integrated Security=SSPI;Initial Catalog='master';Connection Timeout=30;"

    $Connection = New-Object System.Data.SQLClient.SQLConnection($strConn) 
    $Connection.Open() 
    $Command = New-Object System.Data.SQLClient.SQLCommand
    $Command.Connection = $Connection
    #$Command.CommandTimeout = 30
    $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command 
    $dataset = New-Object System.Data.DataSet

    $Command.CommandText = $QueryTXTBD
    $adapter.SelectCommand = $Command
    $dataset.Reset()
    $adapter.Fill($dataset) | out-null    
    
    $recs = $dataset.Tables[0]

    IF ($i.PortFixed -eq "") { 
        if ($recs.local_tcp_port -lt 0 ) {$port = 65536+ $recs.local_tcp_port} else {$port = $recs.local_tcp_port} } else { $port = "" } 

    $AdminAccess = "Not identified yet" 
        try { 
           #$hardware = gwmi Win32_bios -computername $HostName | Out-Null; 
           $os = gwmi  Win32_OperatingSystem -computername $i.Host # -Credential
           $AdminAccess = "True" 
        } catch { $AdminAccess = "False" }
    
        $ErrorLogUCN = "\\" + $i.Host + "\" + $recs.ErrorLog

        # Checking access to ERRORLOG
        if ($Cred -eq $null) { 
            try {
                $Login = $Env:UserDomain + '\' + $Env:UserName
                $PathOk = Test-Path -Path $ErrorLogUCN  -ErrorAction SilentlyContinue
            } catch {$PathOk = $false}      
         } else {
            try {
                $PathOk = Invoke-Command -ComputerName $HostName -Credential $Cred -Scriptblock {param($p1) Test-Path -Path $p1 } -ArgumentList $ErrorLogUCN -ErrorAction SilentlyContinue
            } catch {$PathOk = $false}
         }


        if ($Cred -eq $null) {  
            $SSAS = Get-WmiObject Win32_Service -ComputerName $i.Host | Where-Object -Property DisplayName -EQ "SQL Server Analysis Services ($($i.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
            $SSRS = Get-WmiObject Win32_Service -ComputerName $i.Host | Where-Object -Property DisplayName -EQ "SQL Server Reporting Services ($($i.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
            $FTS  = Get-WmiObject Win32_Service -ComputerName $i.Host | Where-Object -Property DisplayName -EQ "SQL Full-text Filter Daemon Launcher ($($i.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
            $SSISinstances = Get-WmiObject Win32_Service -ComputerName $i.Host | Where-Object -Property DisplayName -Like "SQL Server Integration Services*" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, PathName, StartName, State, StartMode       
        } else {
            $SSAS = Get-WmiObject Win32_Service -ComputerName $i.Host -Credential $Cred | Where-Object -Property DisplayName -EQ "SQL Server Analysis Services ($($i.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
            $SSRS = Get-WmiObject Win32_Service -ComputerName $i.Host -Credential $Cred | Where-Object -Property DisplayName -EQ "SQL Server Reporting Services ($($i.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
            $FTS  = Get-WmiObject Win32_Service -ComputerName $i.Host -Credential $Cred | Where-Object -Property DisplayName -EQ "SQL Full-text Filter Daemon Launcher ($($i.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
            $SSISinstances = Get-WmiObject Win32_Service -ComputerName $i.Host -Credential $Cred | Where-Object -Property DisplayName -Like "SQL Server Integration Services*" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, PathName, StartName, State, StartMode       
        }
        
        IF ($SSAS -eq $null) { $AS = "No" } else { $AS = "Yes" }
        IF ($SSRS -eq $null) { $RS = "No" } else { $RS = "Yes" }
        IF ($FTS -eq $null)  { $FS = "No" } else { $FS = "Yes" }
        $IS = "No"                 

        try {       
            foreach($SSIS in $SSISinstances)       
            {          
                $ConfigXMLPath = ($SSIS.PathName.Substring(0,$SSIS.PathName.IndexOf('MsDtsSrvr.exe')) + 'MsDtsSrvr.ini.xml') -replace '"', ''       
                $ConfigXMLPath = "\\$($i.Host)\" + $SSIS.PathName.Substring(1,1) + '$\' + $ConfigXMLPath.Substring(3)     
                [xml]$ConfigXML = Get-Content -Path $ConfigXMLPath              

                if ($ConfigXML.DtsServiceConfiguration.TopLevelFolders.Folder.ServerName -like "*$($i.Named)*")       
                    { IF ($SSIS -eq $null) { $IS = "No" } else { $IS = "Yes" } }       
                elseif (($ConfigXML.DtsServiceConfiguration.TopLevelFolders.Folder.ServerName -EQ ".") -and ($i.Named -eq 'MSSQLSERVER'))       
                    { IF ($SSIS -eq $null) { $IS = "No" } else { $IS = "Yes" } }       
            } 
        } catch { $IS = "No" }      

    $TableBD.Rows.Add("SQL instance", 
        $i.Instance, 
        $recs.installationSQL,
        $recs.ActiveNode, 
            $recs.ListNodes, 
            $recs.Admin, 
            $AdminAccess, #$Instance.OSAdmin, 
            $PathOk, 
            $recs.Account, 
            $recs.SQLversion, 
            $recs.SP, 
            $recs.CU, 
            $recs.KB, 
            $recs.Edition, 
            $recs.IP, 
            $port, 
            $i.PortFixed, 
            $ErrorLogUCN, #$C, 
            $recs.Clustered, 
            $recs.AAG, 
            $recs.LogShipping, 
            $AS, 
            $RS, 
            $IS, 
            $FS, 
            $recs.LastRestart, 
            $recs.OSversion, #$Instance.Os, 
            $i.Connection, 
            $recs.ClusterDrives #$SharedDrives
            ) | Out-Null

    $Connection.Close()
    $Connection.Dispose()
}

$TableBD      | Export-Csv -Path $Path\-BD_helper.csv -NoTypeInformation 
$RunTime = Get-Date  
Write-Host "$RunTime - End testing connections"  -ForegroundColor Green








<#

Instance processing: WAPLMDSP1 using connection: WAPLMDSP1,1433
Get-Content : Cannot find path '\\\E$\Program Files\Microsoft SQL Server\150\DTS\Binn\MsDtsSrvr.ini.xml' because it does not exist.
At C:\temp\BCS\functions.ps1:374 char:35

Instance processing: WAPLNEONP\SQLEXPRESS using connection: WAPLNEONP\SQLEXPRESS
Exception calling "Open" with "0" argument(s): "A network-related or instance-specific error occurred while establishing a connection to SQL Server. The server was not found or was 
not accessible. Verify that the instance name is correct and that SQL Server is configured to allow remote connections. (provider: SQL Network Interfaces, error: 26 - Error 





#>