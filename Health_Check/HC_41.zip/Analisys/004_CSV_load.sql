SET NOCOUNT ON;
SET DATEFORMAT dmy;  

DECLARE @client VARCHAR(max)
DECLARE @timestamp DATETIME
SET @client =  'AAL' --(SELECT DISTINCT [Client] FROM [dbo].[InstanceInformation])
SET @timestamp =  GETDATE() --  (SELECT DISTINCT [timestamp] FROM [dbo].[InstanceInformation])


--DECLARE @path VARCHAR(250) = 'C:\Gennadi\CLIENTS\B&C\HCdata\' 
--DECLARE @path VARCHAR(250) = 'C:\Users\gennadi.gretchkosiy\Desktop\Clients\AAL\HC\HC_020823\' 
DECLARE @path VARCHAR(250) = 'C:\Gennadi\CLIENTS\AAL\HC_1704\' 
DECLARE @tsql VARCHAR(500)

-- To clean all tables 
-- SELECT 'TRUNCATE TABLE [' + [TABLE_SCHEMA] + '].[' + [TABLE_NAME] +']' FROM [INFORMATION_SCHEMA].[TABLES]  WHERE [TABLE_TYPE] = 'BASE TABLE'

-------------------------------------------------------------------------------------------------------

--------
-- 01 -- 
--------
TRUNCATE TABLE [LOAD].[AAG_load]
SET @tsql = 'BULK INSERT [LOAD].[AAG_load] FROM ''' + @path + '-aag.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[AAG_Load]
SET 
	   [AAG name]							= REPLACE([AAG name],'"', '')
      ,[Listener DNS name]					= REPLACE([Listener DNS name],'"', '')
      ,[Listener PORT]						= REPLACE([Listener PORT],'"', '')
      ,[Cluster IP configuration string]	= REPLACE([Cluster IP configuration string],'"', '')
      ,[Primary node]						= REPLACE([Primary node],'"', '')
      ,[Secondary node]						= REPLACE([Secondary node],'"', '')
      ,[Endpoint]							= REPLACE([Endpoint],'"', '')
      ,[Availability Mode]					= REPLACE([Availability Mode],'"', '')
      ,[Failover Mode]						= REPLACE([Failover Mode],'"', '')
      ,[Seeding Mode]						= REPLACE([Seeding Mode],'"', '')
      ,[Operational State]					= REPLACE([Operational State],'"', '')
      ,[Connected State]					= REPLACE([Connected State],'"', '')
      ,[Health]								= REPLACE([Health],'"', '')
  FROM [LOAD].[AAG_Load]

INSERT INTO  [dbo].[AAG]
  SELECT [AAG name]
      ,[Listener DNS name]
      ,[Listener PORT]
      ,[Cluster IP configuration string]
      ,[Primary node]
      ,[Secondary node]
      ,[Endpoint]
      ,[Availability Mode]
      ,[Failover Mode]
      ,[Seeding Mode]
      ,[Operational State]
      ,[Connected State]
      ,[Health]
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[AAG_Load]

--SELECT * FROM [dbo].[AAG]

--------
-- 02 -- 
--------
TRUNCATE TABLE [LOAD].[AAGbackup_load]
SET @tsql = 'BULK INSERT [LOAD].[AAGbackup_load] FROM ''' + @path + '-aagbackups.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[AAGbackup_load]
SET	   [InstaneName] = REPLACE([InstaneName], '"', '')
      ,[type] = REPLACE([type], '"', '')
      ,[name] = REPLACE([name], '"', '')
      ,[RM] = REPLACE([RM], '"', '')
      ,[AAGname] = REPLACE([AAGname], '"', '')
      ,[Last backup] = REPLACE([Last backup], '"', '')
FROM [LOAD].[AAGbackup_load]

  INSERT INTO [dbo].[AAGbackup] (
	   [InstaneName]
      ,[type]
      ,[name]
      ,[RM]
      ,[AAGname]
      ,[Last Backup]
	  ,[Client]
      ,[timestamp]
      ,[Host Name])
SELECT [InstaneName]
      ,[type]
      ,[name]
      ,[RM]
      ,[AAGname]
      ,CASE WHEN [Last Backup] = '' THEN NULL ELSE [Last Backup] END AS [Last Backup]
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
	  ,'' AS [Host Name]
  FROM [LOAD].[AAGbackup_load]

--SELECT * FROM [dbo].[AAGbackup]

--------
-- 03 -- 
--------
TRUNCATE TABLE [LOAD].[AAGobjects_load]
SET @tsql = 'BULK INSERT [LOAD].[AAGobjects_load] FROM ''' + @path + '-aagobjects.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[AAGobjects_load]
SET	   [ObjName] = REPLACE([ObjName], '"', '')
      ,[InstanceName] = REPLACE([InstanceName], '"', '')
      ,[name] = REPLACE([name], '"', '')
FROM [LOAD].[AAGobjects_load]

INSERT INTO [dbo].[AAGobjects] (
	[Object type], 
	[Instance Name], 
	[Object name],
	[Client]
    ,[timestamp]
    ,[Host Name])
SELECT 
	[ObjName],
	[InstanceName],
	[name]
	,@client as [Client]
	,@timestamp AS [timestamp]
	,'' AS [Host Name]
FROM [LOAD].[AAGobjects_load]

--SELECT * FROM [dbo].[AAGobjects]

--------
-- 04 -- 
--------
TRUNCATE TABLE [LOAD].[ChangeTracking_load]
SET @tsql = 'BULK INSERT [LOAD].[ChangeTracking_load] FROM ''' + @path + '-ChangeTracking.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[ChangeTracking_load]
SET	   InstanceName = REPLACE(InstanceName, '"', '')
	  ,[change_tracking_db] = REPLACE([change_tracking_db], '"', '')
      ,[is_auto_cleanup_on] = REPLACE([is_auto_cleanup_on], '"', '')
      ,[retention_period] = REPLACE([retention_period], '"', '')
	  ,[retention_period_units_desc] = REPLACE([retention_period_units_desc], '"', '')
FROM [LOAD].[ChangeTracking_load]

INSERT INTO [dbo].[ChangeTracking] 
SELECT 
	*
	,@client as [Client]
	,@timestamp AS [timestamp]
FROM [LOAD].[ChangeTracking_load]

--SELECT * FROM [dbo].[ChangeTracking] 

--------
-- 05 -- 
--------
TRUNCATE TABLE [LOAD].[Compression_load]
SET @tsql = 'BULK INSERT [LOAD].[Compression_load] FROM ''' + @path + '-Compression.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)


UPDATE [LOAD].[Compression_load]
SET 
	   [InstanceName]							= REPLACE([InstanceName],'"', '')
      ,[DatabaseName]					= REPLACE([DatabaseName],'"', '')
      ,[Table]						= REPLACE([Table],'"', '')
      ,[Partition]	= REPLACE([Partition],'"', '')
      ,[Compression]						= REPLACE([Compression],'"', '')
      ,[Index]						= REPLACE([Index],'"', '')
FROM [LOAD].[Compression_load]


INSERT INTO [dbo].[Compression]
	([InstanceName]
      ,[DatabaseName]
      ,[Table]
      ,[Partition]
      ,[Compression]
      ,[Index]
      ,[Client]
      ,[timestamp])
SELECT [InstanceName]
      ,[DatabaseName]
      ,[Table]
      ,[Partition]
      ,[Compression]
      ,[Index]
	,@client as [Client]
	,@timestamp AS [timestamp]
  FROM [LOAD].[Compression_load]

--------
-- 06 -- 
--------
TRUNCATE TABLE [LOAD].[Configuration_load]
SET @tsql = 'BULK INSERT [LOAD].[Configuration_load] FROM ''' + @path + '-configuration.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''",'');'
EXEC(@tsql)

UPDATE [LOAD].[Configuration_load]
SET
	  [HostName]= REPLACE([HostName], '"', ''),
      [InstanceName]= REPLACE([InstanceName], '"', ''),
      [StartUpFlags]= REPLACE([StartUpFlags], '"', ''),
      [DAC]= REPLACE([DAC], '"', ''),
      [net_transport]= REPLACE([net_transport], '"', ''),
      [protocol_type]= REPLACE([protocol_type], '"', ''),
      [auth_scheme]= REPLACE([auth_scheme], '"', ''),
      [ActiveNode]= REPLACE([ActiveNode], '"', ''),
      [ListNodes]= REPLACE([ListNodes], '"', ''),
      [client_net_address]= REPLACE([client_net_address], '"', ''),
      [local_net_address]= REPLACE([local_net_address], '"', ''),
      [local_tcp_port]= REPLACE([local_tcp_port], '"', ''),
      [ServiceAccount]= REPLACE([ServiceAccount], '"', ''),
      [ServiceAccountStatus]= REPLACE([ServiceAccountStatus], '"', ''),
      [ServiceAccountStartup]= REPLACE([ServiceAccountStartup], '"', ''),
      [AgentAccount]= REPLACE([AgentAccount], '"', ''),
      [AgentAccountStatus]= REPLACE([AgentAccountStatus], '"', ''),
      [AgentAccountStartup]= REPLACE([AgentAccountStartup], '"', ''),
      [AuthentificationMode]= REPLACE([AuthentificationMode], '"', ''),
      [BackupCompression]= REPLACE([BackupCompression], '"', ''),
      [DOP]= REPLACE([DOP], '"', ''),
      [OSmemoryGB]= REPLACE([OSmemoryGB], '"', ''),
      [MinRAM]= REPLACE([MinRAM], '"', ''),
      [MaxRAM]= REPLACE([MaxRAM], '"', ''),
      [CPUs]= REPLACE([CPUs], '"', ''),
      [GrowthFile_Master]= REPLACE([GrowthFile_Master], '"', ''),
      [GrowthFile_Msdb]= REPLACE([GrowthFile_Msdb], '"', ''),
      [GrowthFile_Model]= REPLACE([GrowthFile_Model], '"', ''),
      [NumberTempDB]= REPLACE([NumberTempDB], '"', ''),
      [ListSharedDrives]= REPLACE([ListSharedDrives], '"', ''),
      [DataFileSizeMB]= REPLACE([DataFileSizeMB], '"', ''),
      [MSDB_used]= REPLACE([MSDB_used], '"', ''),
      [MASTER_file_location]= REPLACE([MASTER_file_location], '"', ''),
      [MODEL_file_location]= REPLACE([MODEL_file_location], '"', ''),
      [MSDB_file_location]= REPLACE([MSDB_file_location], '"', ''),
      [InitialSizeTempDB]= REPLACE([InitialSizeTempDB], '"', ''),
      [GrowthFileTempDB]= REPLACE([GrowthFileTempDB], '"', ''),
      [SizeDataTempDB]= REPLACE([SizeDataTempDB], '"', ''),
      [SizeLogTempDB]= REPLACE([SizeLogTempDB], '"', ''),
      [TempDB_fileLocation]= REPLACE([TempDB_fileLocation], '"', ''),
      [TempDB_LogLocation]= REPLACE([TempDB_LogLocation], '"', ''),
      [DB_FileLocation]= REPLACE([DB_FileLocation], '"', ''),
      [DB_LogLocation]= REPLACE([DB_LogLocation], '"', ''),
      [DB_BackupLocation]= REPLACE([DB_BackupLocation], '"', ''),
      [BIN_Location]= REPLACE([BIN_Location], '"', ''),
      [MailServer]= REPLACE([MailServer], '"', ''),
      [ProductLevel]= REPLACE([ProductLevel], '"', ''),
      [ProductUpdateLevel]= REPLACE([ProductUpdateLevel], '"', ''),
      [ProductBuildType]= REPLACE([ProductBuildType], '"', ''),
      [ProductUpdateReference]= REPLACE([ProductUpdateReference], '"', ''),
      [ProductVersion]= REPLACE([ProductVersion], '"', ''),
      [ProductMajorVersion]= REPLACE([ProductMajorVersion], '"', ''),
      [ProductMinorVersion]= REPLACE([ProductMinorVersion], '"', ''),
      [ProductBuild]= REPLACE([ProductBuild], '"', ''),
      [ProductCollation]= REPLACE([ProductCollation], '"', ''),
      [Edition]= REPLACE([Edition], '"', ''),
      [MaintenancePlansWith_no_SA]= REPLACE([MaintenancePlansWith_no_SA], '"', ''),
      [JobsWith_no_SA]= REPLACE([JobsWith_no_SA], '"', ''),
      [ErrorLogLocation]= REPLACE([ErrorLogLocation], '"', ''),
      [AgentErrorLogLocation]= REPLACE([AgentErrorLogLocation], '"', ''),
      [MultiServerJobs]= REPLACE([MultiServerJobs], '"', ''),
      [OsName]= REPLACE([OsName], '"', ''),
      [NumberErrorLog_files]= REPLACE([NumberErrorLog_files], '"', ''),
      [MSDB_DatabaseMailUserRole]= REPLACE([MSDB_DatabaseMailUserRole], '"', '')
FROM [LOAD].[Configuration_load]

INSERT INTO  [dbo].[Configuration]
SELECT [HostName]
      ,[InstanceName]
      ,[StartUpFlags]
      ,[DAC]
      ,[net_transport]
      ,[protocol_type]
      ,[auth_scheme]
      ,[ActiveNode]
      ,[ListNodes]
      ,[client_net_address]
      ,[local_net_address]
      ,[local_tcp_port]
      ,[ServiceAccount]
      ,[ServiceAccountStatus]
      ,[ServiceAccountStartup]
      ,[AgentAccount]
      ,[AgentAccountStatus]
      ,[AgentAccountStartup]
      ,[AuthentificationMode]
      ,[BackupCompression]
      ,[DOP]
      ,[OSmemoryGB]
      ,[MinRAM]
      ,[MaxRAM]
      ,[CPUs]
      ,[GrowthFile_Master]
      ,[GrowthFile_Msdb]
      ,[GrowthFile_Model]
      ,[NumberTempDB]
      ,[ListSharedDrives]
      ,[DataFileSizeMB]
      ,[MSDB_used]
      ,[MASTER_file_location]
      ,[MODEL_file_location]
      ,[MSDB_file_location]
      ,[InitialSizeTempDB]
      ,[GrowthFileTempDB]
      ,[SizeDataTempDB]
      ,[SizeLogTempDB]
      ,[TempDB_fileLocation]
      ,[TempDB_LogLocation]
      ,[DB_FileLocation]
      ,[DB_LogLocation]
      ,[DB_BackupLocation]
      ,[BIN_Location]
      ,[MailServer]
      ,[ProductLevel]
      ,[ProductUpdateLevel]
      ,[ProductBuildType]
      ,[ProductUpdateReference]
      ,[ProductVersion]
      ,[ProductMajorVersion]
      ,[ProductMinorVersion]
      ,[ProductBuild]
      ,[ProductCollation]
      ,[Edition]
      ,[MaintenancePlansWith_no_SA]
      ,[JobsWith_no_SA]
      ,[ErrorLogLocation]
      ,[AgentErrorLogLocation]
      ,[MultiServerJobs]
      ,[OsName]
      ,[NumberErrorLog_files]
      ,[MSDB_DatabaseMailUserRole]
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[Configuration_load]

--------
-- 07 -- 
--------
TRUNCATE TABLE [LOAD].[DatabaseDetails_load]
SET @tsql = 'BULK INSERT [LOAD].[DatabaseDetails_load] FROM ''' + @path + '-DatabaseDetails.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[DatabaseDetails_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [File Name]= REPLACE([File Name],'"', ''),
	 [Type]= REPLACE([Type],'"', ''),
	 [Total Size (MB)]= REPLACE([Total Size (MB)],'"', ''),
	 [Used Size (MB)]= REPLACE([Used Size (MB)],'"', ''),
	 [Auto-growth]= REPLACE([Auto-growth],'"', '')
FROM [LOAD].[DatabaseDetails_load]


INSERT INTO  [dbo].[DatabaseDetails]
([Instance Name],
      [Host Name],
      [Database Name],
      [File Name],
      [Type],
      [Total Size (MB)],
      [Used Size (MB)],
      [Auto-growth],
	  [Client],
	  [timestamp]
)
SELECT 
	   [Instance Name],
      [Host Name],
      [Database Name],
      [File Name],
      [Type],
      [Total Size (MB)],
      CAST([Used Size (MB)] AS BIGINT) AS [Used Size (MB)],
      [Auto-growth],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[DatabaseDetails_load]


--------
-- 08 -- 
--------
TRUNCATE TABLE [LOAD].[DatabaseMasterKey_load]
SET @tsql = 'BULK INSERT [LOAD].[DatabaseMasterKey_load] FROM ''' + @path + '-DatabaseMasterKey.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[DatabaseMasterKey_load]
SET 
	 InstanceName= REPLACE(InstanceName,'"', ''),
	 KeyName= REPLACE(KeyName,'"', ''),
	 PrincipalName= REPLACE(PrincipalName,'"', ''),
	 create_date= REPLACE(create_date,'"', ''),
	 modify_date= REPLACE(modify_date,'"', '')
FROM [LOAD].[DatabaseMasterKey_load]

INSERT INTO  [dbo].[DatabaseMasterKey]
SELECT 
	  *,
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[DatabaseMasterKey_load]

--SELECT * FROM [dbo].[DatabaseMasterKey]

--------
-- 09 -- 
--------
TRUNCATE TABLE [LOAD].[DatabasesRoles_load]
SET @tsql = 'BULK INSERT [LOAD].[DatabasesRoles_load] FROM ''' + @path + '-DatabasesRoles.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[DatabasesRoles_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [Role]= REPLACE([Role],'"', ''),
	 [User name]= REPLACE([User name],'"', '')
FROM [LOAD].[DatabasesRoles_load]

INSERT INTO  [dbo].[DatabasesRoles]
SELECT 
	  *,
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[DatabasesRoles_load]

--------
-- 10 -- 
--------
TRUNCATE TABLE [LOAD].[DBoption_load]
SET @tsql = 'BULK INSERT [LOAD].[DBoption_load] FROM ''' + @path + '-DBoption.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[DBoption_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [DBowner]= REPLACE([DBowner],'"', ''),
	 [State]= REPLACE([State],'"', ''),
	 [Compatibility]= REPLACE([Compatibility],'"', ''),
	 [Collation]= REPLACE([Collation],'"', ''),
	 [Page Verify]= REPLACE([Page Verify],'"', ''),
	 [auto_close]= REPLACE([auto_close],'"', ''),
	 [auto_shrink]= REPLACE([auto_shrink],'"', ''),
	 [db_chaining]= REPLACE([db_chaining],'"', ''),
	 [auto_create_stats]= REPLACE([auto_create_stats],'"', ''),
	 [auto_update_stats]= REPLACE([auto_update_stats],'"', '')
FROM [LOAD].[DBoption_load]

INSERT INTO  [dbo].[DBoption]
SELECT 
      *,
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[DBoption_load]

--------
-- 11 -- 
--------
TRUNCATE TABLE [LOAD].[DiskSpace_load]
SET @tsql = 'BULK INSERT [LOAD].[DiskSpace_load] FROM ''' + @path + '-drives.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[DiskSpace_load]
SET 
	[Host Name]= REPLACE([Host Name],'"', ''),
	[DeviceID]= REPLACE([DeviceID],'"', ''),
	[VolumeName]= REPLACE([VolumeName],'"', ''),
	[Size]= REPLACE([Size],'"', ''),
	[FreeSpace]= REPLACE([FreeSpace],'"', '')
FROM [LOAD].[DiskSpace_load]

INSERT INTO  [dbo].[DiskSpace]
SELECT 
	  [Host Name]
      ,[DeviceID]
      ,[VolumeName]
      ,[Size]
      ,[FreeSpace],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[DiskSpace_load]

--SELECT * FROM[dbo].[DiskSpace]

--------
-- 12 -- 
--------
TRUNCATE TABLE [LOAD].[EcryptionCertificates_load]
SET @tsql = 'BULK INSERT [LOAD].[EcryptionCertificates_load] FROM ''' + @path + '-EcryptionCertificates.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[EcryptionCertificates_load]
SET 
	[InstanceName]= REPLACE([InstanceName],'"', ''),
	[Name]= REPLACE([Name],'"', ''),
	[pvt_key_encryption_type_desc]= REPLACE([pvt_key_encryption_type_desc],'"', ''),
	[start_date]= REPLACE([start_date],'"', ''),
	[expiry_date]= REPLACE([expiry_date],'"', ''),
	[pvt_key_last_backup_date]= REPLACE([pvt_key_last_backup_date],'"', '')
  FROM [LOAD].[EcryptionCertificates_load]

INSERT INTO [dbo].[EcryptionCertificates]
SELECT 
	*,
	  @client as [Client],
	  @timestamp AS [timestamp]

--[InstanceName]
--      ,[Name]
--      ,[pvt_key_encryption_type_desc]
--      ,[start_date]
--      ,[expiry_date]
--      ,[pvt_key_last_backup_date]
  FROM [LOAD].[EcryptionCertificates_load]

--------
-- 13 -- 
--------
TRUNCATE TABLE [LOAD].[ExtendedEvents_load]
SET @tsql = 'BULK INSERT [LOAD].[ExtendedEvents_load] FROM ''' + @path + '-ExtendedEvents.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[ExtendedEvents_load]
SET 
	[InstanceName]= REPLACE([InstanceName],'"', ''),
	[Name]= REPLACE([Name],'"', '')
  FROM [LOAD].[ExtendedEvents_load]

INSERT INTO [dbo].[ExtendedEvents]
SELECT 
	  *,
	  @client as [Client],
	  @timestamp AS [timestamp]
  FROM [LOAD].[ExtendedEvents_load]

--------
-- 14 -- 
--------
TRUNCATE TABLE [LOAD].[IdleDatabases_load]
SET @tsql = 'BULK INSERT [LOAD].[IdleDatabases_load] FROM ''' + @path + '-IdleDatabases.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[IdleDatabases_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', '')
FROM [LOAD].[IdleDatabases_load]

INSERT INTO  [dbo].[IdleDatabases]
SELECT 
	 [Instance Name],
	 [Host Name],
	 [Database Name],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[IdleDatabases_load]

--------
-- 15 -- 
--------
TRUNCATE TABLE [LOAD].[IndexFragmentation_load]
SET @tsql = 'BULK INSERT [LOAD].[IndexFragmentation_load] FROM ''' + @path + '-IndexFragmentation.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)


UPDATE [LOAD].[IndexFragmentation_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [Table Name]= REPLACE([Table Name],'"', ''),
	 [Index Size (MB)]= REPLACE([Index Size (MB)],'"', ''),
	 [Max Percentage]= REPLACE([Max Percentage],'"', ''),
	 [Average Percentage]= REPLACE([Average Percentage],'"', '')
FROM [LOAD].[IndexFragmentation_load]

INSERT INTO  [dbo].[IndexFragmentation]
SELECT 
      [Instance Name],
      [Host Name],
      [Database Name],
      [Table Name],
      [Index Size (MB)],
      [Max Percentage],
      [Average Percentage],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[IndexFragmentation_load]


--------
-- 16 -- 
--------
TRUNCATE TABLE [LOAD].[InstanceInformation_load] 
SET @tsql = 'BULK INSERT [LOAD].[InstanceInformation_load] FROM ''' + @path + '-instance.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[InstanceInformation_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [ID]= REPLACE([ID],'"', ''),
	 [Type]= REPLACE([Type],'"', ''),
	 [Client]= REPLACE([Client],'"', ''),
	 [timestamp]= REPLACE([timestamp],'"', ''),
	 [Value]= REPLACE([Value],'"', '')
FROM [LOAD].[InstanceInformation_load]

INSERT INTO  [dbo].[InstanceInformation]
SELECT 
      [ID],
      [Host Name],
      [Instance Name],
      [Type],
      [Value],
      [Client],
      [timestamp]
FROM [LOAD].[InstanceInformation_load]

--SELECT * FROM [dbo].[InstanceInformation]

--------
-- 17 -- 
--------
TRUNCATE TABLE [LOAD].[IntegrityCheck_load]
SET @tsql = 'BULK INSERT [LOAD].[IntegrityCheck_load] FROM ''' + @path + '-IntegrityCheck.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[IntegrityCheck_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [State]= REPLACE([State],'"', ''),
	 [Last Executed]= REPLACE([Last Executed],'"', '')
FROM [LOAD].[IntegrityCheck_load]

INSERT INTO  [dbo].[IntegrityCheck]
SELECT 
      *, 
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[IntegrityCheck_load]

--------
-- 18 -- 
--------
TRUNCATE TABLE [LOAD].[IPs_load]
SET @tsql = 'BULK INSERT [LOAD].[IPs_load] FROM ''' + @path + '-IPs.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[IPs_load]
SET 
	   [InstanceName]		= REPLACE([InstanceName],'"', '')
      ,[IPname]				= REPLACE([IPname],'"', '')	
      ,[Active]				= REPLACE([Active],'"', '')
      ,[Enabled]			= REPLACE([Enabled],'"', '')
      ,[IPaddress]			= REPLACE([IPaddress],'"', '')
      ,[Dynamic]			= REPLACE([Dynamic],'"', '')
      ,[port]				= REPLACE([port],'"', '')
      ,[DisplayName]		= REPLACE([DisplayName],'"', '')
      --,[Client]
      --,[timestamp]
FROM [LOAD].[IPs_load]

INSERT INTO  [dbo].[IPs]
SELECT 
	*
	,@client as [Client]
	,@timestamp AS [timestamp]
FROM [LOAD].[IPs_load]

--SELECT * FROM  [dbo].[IPs]

--------
-- 19 -- 
--------
TRUNCATE TABLE [LOAD].[isolation_level_load]
SET @tsql = 'BULK INSERT [LOAD].[isolation_level_load] FROM ''' + @path + '-isolation_level.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[isolation_level_load]
SET 
	   [Instance name]					= REPLACE([Instance name],'"', '')
      ,[Database Name]					= REPLACE([Database Name],'"', '')
      ,[ALLOW_SNAPSHOT_ISOLATION]		= REPLACE([ALLOW_SNAPSHOT_ISOLATION],'"', '')
      ,[TRANSACTION_ISOLATION_LEVEL]	= REPLACE([TRANSACTION_ISOLATION_LEVEL],'"', '')
FROM [LOAD].[isolation_level_load]

INSERT INTO  [dbo].[isolation_level]
SELECT 
	*
	,@client as [Client]
	,@timestamp AS [timestamp]
FROM [LOAD].[isolation_level_load]

--------
-- 20 -- 
--------

TRUNCATE TABLE [LOAD].[Jobs_load]
SET @tsql = 'BULK INSERT [LOAD].[Jobs_load] FROM ''' + @path + '-Jobs.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[Jobs_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Job Name]= REPLACE([Job Name],'"', ''),
	 [enabled]= REPLACE([enabled],'"', ''),
	 [job_id]= REPLACE([job_id],'"', ''),
	 [freq_type]= REPLACE([freq_type],'"', ''),
	 [freq_recurrence_factor]= REPLACE([freq_recurrence_factor],'"', ''),
	 [active_start_date]= REPLACE([active_start_date],'"', ''),
	 [freq_interval]= REPLACE([freq_interval],'"', ''),
	 [freq_relative_interval]= REPLACE([freq_relative_interval],'"', ''),
	 [freq_subday_type]= REPLACE([freq_subday_type],'"', ''),
	 [active_start_time]= REPLACE([active_start_time],'"', ''),
	 [active_end_time]= REPLACE([active_end_time],'"', ''),
	 [freq_subday_interval]= REPLACE([freq_subday_interval],'"', ''),
	 [Owner]= REPLACE([Owner],'"', '')
FROM [LOAD].[Jobs_load]


INSERT INTO  [dbo].[Jobs]
SELECT 
       [Instance Name],
      [Host Name],
      [Job Name],
      [enabled],
      [job_id],
      [freq_type],
      [freq_recurrence_factor],
      [active_start_date],
      [freq_interval],
      [freq_relative_interval],
      [freq_subday_type],
      [active_start_time],
      [active_end_time],
      [freq_subday_interval],
      [Owner],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[Jobs_load]

--------
-- 21 -- 
--------
TRUNCATE TABLE [LOAD].[JobsScheduler_load]
SET @tsql = 'BULK INSERT [LOAD].[JobsScheduler_load] FROM ''' + @path + '-JobsScheduler.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[JobsScheduler_load]
SET 
	[Instance Name]			= REPLACE([Instance name],'"', '')
	,JobName				= REPLACE(JobName,'"', '')
	,TimeZone				= REPLACE(TimeZone,'"', '')
	,Schedule				= REPLACE(Schedule,'"', '')
	,JobOwner				= REPLACE(JobOwner,'"', '')
	,[Schedule Name]		= REPLACE([Schedule Name],'"', '')
	,[Schedule Enabled]		= REPLACE([Schedule Enabled],'"', '')
	,[Start date]			= REPLACE([Start date],'"', '')	
	,[End date]				= REPLACE([End date],'"', '')
	,[Recent Start date]	= REPLACE([Recent Start date],'"', '')	
FROM [LOAD].[JobsScheduler_load]

INSERT INTO  [dbo].[JobsScheduler]
SELECT 
	*
	,@client as [Client]
	,@timestamp AS [timestamp]
FROM [LOAD].[JobsScheduler_load]

--------
-- 22 -- 
--------
TRUNCATE TABLE [LOAD].[ifi_lim_load]
SET @tsql = 'BULK INSERT [LOAD].[ifi_lim_load] FROM ''' + @path + '-limifi.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[ifi_lim_load]
SET 
	[Host Name]= REPLACE([Host Name],'"', ''),
	[Service]= REPLACE([Service],'"', ''),
	[Name]= REPLACE([Name],'"', ''),
	[User]= REPLACE([User],'"', ''),
	[LockPages]= REPLACE([LockPages],'"', ''),
	[InstantInit]= REPLACE([InstantInit],'"', '')
FROM [LOAD].[ifi_lim_load]

INSERT INTO  [dbo].[ifi_lim]
SELECT 
	  *,
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[ifi_lim_load]


--select * from [LOAD].[ifi_lim_load]


--------
-- 23 -- 
--------
TRUNCATE TABLE [LOAD].[MaintenencePlans_load]
SET @tsql = 'BULK INSERT [LOAD].[MaintenencePlans_load] FROM ''' + @path + '-MaintenencePlans.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[MaintenencePlans_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Name]= REPLACE([Name],'"', ''),
	 [Owner]= REPLACE([Owner],'"', '')
FROM [LOAD].[MaintenencePlans_load]

INSERT INTO  [dbo].[MaintenencePlans]
SELECT 
      [Instance Name],
      [Host Name],
      [Name],
      [Owner],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[MaintenencePlans_load]

--SELECT * FROM [dbo].[MaintenencePlans]

--------
-- 24 -- 
--------
TRUNCATE TABLE [LOAD].[MSDB_load]
SET @tsql = 'BULK INSERT [LOAD].[MSDB_load] FROM ''' + @path + '-msdb.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[MSDB_load]
SET 
	  [ServerName]= REPLACE([ServerName],'"', ''),
	  [name]= REPLACE([name],'"', ''),
	  [DataFileSizeMB]= REPLACE([DataFileSizeMB],'"', ''),
	  [MSDB_used]= REPLACE([MSDB_used],'"', ''),
	  [LogFileSizeMB]= REPLACE([LogFileSizeMB],'"', ''),
	  [LS_history]= REPLACE([LS_history],'"', ''),
	  [LS_errors]= REPLACE([LS_errors],'"', ''),
	  [Job_History]= REPLACE([Job_History],'"', ''),
	  [Backup_Files]= REPLACE([Backup_Files],'"', ''),
	  [Backup_Set]= REPLACE([Backup_Set],'"', ''),
	  [backupmediafamily]= REPLACE([backupmediafamily],'"', ''),
	  [logmarkhistory]= REPLACE([logmarkhistory],'"', ''),
	  [sysmail_attachments]= REPLACE([sysmail_attachments],'"', ''),
	  [sysmail_log]= REPLACE([sysmail_log],'"', ''),
	  [sysmail_send_retries]= REPLACE([sysmail_send_retries],'"', ''),
	  [sysmail_allitems]= REPLACE([sysmail_allitems],'"', ''),
	  [transmission_queue]= REPLACE([transmission_queue],'"', ''),
	  [sysdtslog90]= REPLACE([sysdtslog90],'"', ''),
	  [sysmaintplan_log]= REPLACE([sysmaintplan_log],'"', ''),
	  [sysmaintplan_logdetail]= REPLACE([sysmaintplan_logdetail],'"', '')
FROM [LOAD].[MSDB_load]

INSERT INTO  [dbo].[MSDB]
SELECT 
	[ServerName],
      [name],
      [DataFileSizeMB],
      [MSDB_used],
      [LogFileSizeMB],
      [LS_history],
      [LS_errors],
      [Job_History],
      [Backup_Files],
      [Backup_Set],
      [backupmediafamily],
      [logmarkhistory],
      [sysmail_attachments],
      [sysmail_log],
      [sysmail_send_retries],
      [sysmail_allitems],
      [transmission_queue],
      [sysdtslog90],
      [sysmaintplan_log],
      [sysmaintplan_logdetail],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[MSDB_load]

--SELECT * FROM [dbo].[MSDB]

--------
-- 25 -- 
--------
TRUNCATE TABLE [LOAD].[OperationSystem_load]
SET @tsql = 'BULK INSERT [LOAD].[OperationSystem_load] FROM ''' + @path + '-os.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[OperationSystem_load]
SET 
	ID = REPLACE(ID,'"', ''),
	[Host Name]= REPLACE([Host Name],'"', ''),
	[Type]= REPLACE([Type],'"', ''),
	[Value]= REPLACE([Value],'"', '')
	--,
	--[Client]= REPLACE([Client],'"', ''),
	--[timestamp]= REPLACE([timestamp],'"', '')
FROM [LOAD].[OperationSystem_load]

INSERT INTO  [dbo].[OperationSystem]
SELECT [ID],
      [Host Name],
      [Type],
      [Value],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[OperationSystem_load]

--SELECT * FROM[dbo].[OperationSystem]

--------
-- 26 -- 
--------
TRUNCATE TABLE [LOAD].[OrphanUsers_load]
SET @tsql = 'BULK INSERT [LOAD].[OrphanUsers_load] FROM ''' + @path + '-OrphanUsers.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[OrphanUsers_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [User Name]= REPLACE([User Name],'"', ''),
	 [Status]= REPLACE([Status],'"', ''),
	 [Type]= REPLACE([Type],'"', '')
FROM [LOAD].[OrphanUsers_load]

INSERT INTO  [dbo].[OrphanUsers]
SELECT 
       [Instance Name],
      [Host Name],
      [Database Name],
      [User Name],
      [Status],
      [Type],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[OrphanUsers_load]


--------
-- 27 -- 
--------
TRUNCATE TABLE [LOAD].[ServerRoles_load]
SET @tsql = 'BULK INSERT [LOAD].[ServerRoles_load] FROM ''' + @path + '-ServerRoles.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[ServerRoles_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Role]= REPLACE([Role],'"', ''),
	 [User name]= REPLACE([User name],'"', ''),
	 [Type]= REPLACE([Type],'"', '')
FROM [LOAD].[ServerRoles_load]

INSERT INTO  [dbo].[ServerRoles]
SELECT 
	[Instance Name],
      [Host Name],
      [Role],
      [User name],
      [Type],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[ServerRoles_load]

--------
-- 28 -- 
--------
TRUNCATE TABLE [LOAD].[Services_load]
SET @tsql = 'BULK INSERT [LOAD].[Services_load] FROM ''' + @path + '-service.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[Services_load]
SET 
	[Host Name]= REPLACE([Host Name],'"', ''),
	[Service Name]= REPLACE([Service Name],'"', ''),
	[Account]= REPLACE([Account],'"', ''),
	[Startup]= REPLACE([Startup],'"', ''),
	[Status]= REPLACE([Status],'"', ''),
	[PathName]= REPLACE([PathName],'"', '')
	--,
	--[Client]= REPLACE([Client],'"', ''),
	--[timestamp]= REPLACE([timestamp],'"', '')
FROM [LOAD].[Services_load]

INSERT INTO  [dbo].[Services]
SELECT [Host Name],
      [Service Name],
      [Account],
      [Startup],
      [Status],
      [PathName],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[Services_load]

--------
-- 28 -- 
--------
TRUNCATE TABLE [LOAD].[Hardware_load]
SET @tsql = 'BULK INSERT [LOAD].[Hardware_load] FROM ''' + @path + '-system.csv'' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[Hardware_load]
SET 
	ID = REPLACE([ID],'"', ''),
	[Host Name]= REPLACE([Host Name],'"', ''),
	[Instance Name]= REPLACE([Instance Name],'"', ''),
	[Type]= REPLACE([Type],'"', ''),
	[Value]= REPLACE([Value],'"', '')
	--,
	--[Client]= REPLACE([Client],'"', ''),
	--[timestamp]= REPLACE([timestamp],'"', '')
FROM [LOAD].[Hardware_load]

INSERT INTO  [dbo].[Hardware]
SELECT
	[ID],
      [Host Name],
      [Type],
      [Value],
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[Hardware_load]

--------
-- 29 -- 
--------
TRUNCATE TABLE [LOAD].[UpdateStatistics_load]
SET @tsql = 'BULK INSERT [LOAD].[UpdateStatistics_load] FROM ''' + @path + '-UpdateStatistics.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[UpdateStatistics_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [Last Executed]= REPLACE([Last Executed],'"', '')
FROM [LOAD].[UpdateStatistics_load]

INSERT INTO  [dbo].[UpdateStatistics]
SELECT 
      *,
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[UpdateStatistics_load]


--------
-- 30 -- 
--------
TRUNCATE TABLE [LOAD].[VirtualLogFile_load]
SET @tsql = 'BULK INSERT [LOAD].[VirtualLogFile_load] FROM ''' + @path + '-VirtualLogFile.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[VirtualLogFile_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [Count]= REPLACE([Count],'"', ''),
	 [Total Size (MB)]= REPLACE([Total Size (MB)],'"', ''),
	 [Average Size (MB)]= REPLACE([Average Size (MB)],'"', ''),
	 [Auto-growth]= REPLACE([Auto-growth],'"', '')
FROM [LOAD].[VirtualLogFile_load]

INSERT INTO  [dbo].[VirtualLogFile]
SELECT 
      *,
	  @client as [Client],
	  @timestamp AS [timestamp]
FROM [LOAD].[VirtualLogFile_load]

--------
-- 31 -- 
--------
TRUNCATE TABLE [LOAD].[MissedIndexes_load]
SET @tsql = 'BULK INSERT [LOAD].[MissedIndexes_load] FROM ''' + @path + '-MissedIndexes.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[MissedIndexes_load]
SET 
	   [Instance Name]			= REPLACE([Instance Name],'"', '')
      ,[DatabaseName]			= REPLACE([DatabaseName],'"', '')
      ,[TableName]				= REPLACE([TableName],'"', '')
      ,[improvement_measure]	= REPLACE([improvement_measure],'"', '')
      ,[create_index_statement]	= REPLACE([create_index_statement],'"', '')
  FROM [LOAD].[MissedIndexes_load]

INSERT INTO  [dbo].[MissedIndexes]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[MissedIndexes_load]

--------
-- 32 -- 
--------
TRUNCATE TABLE [LOAD].[QueryStore_load]
SET @tsql = 'BULK INSERT [LOAD].[QueryStore_load] FROM ''' + @path + '-QueryStore.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[QueryStore_load]
SET 
  	InstanceName			= REPLACE(InstanceName,'"', '')
	,DatabaseName			= REPLACE(DatabaseName,'"', '')
	,desired_state_desc		= REPLACE(desired_state_desc,'"', '')
	,actual_state_desc		= REPLACE(actual_state_desc,'"', '')
	,max_storage_size_mb	= REPLACE(max_storage_size_mb,'"', '')
FROM [LOAD].[QueryStore_load]

INSERT INTO  [dbo].[QueryStore]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[QueryStore_load]

--------
-- 33 -- 
--------

TRUNCATE TABLE [LOAD].[SSIScatalogue_load]
/*
SET @tsql = 'BULK INSERT [LOAD].[SSIScatalogue_load] FROM ''' + @path + '-SSIScatalogue.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[SSIScatalogue_load]
SET 
	InstanceName			= REPLACE(InstanceName,'"', '')
	,NAME					= REPLACE(NAME,'"', '')
	,RETENTION_WINDOW		= REPLACE(RETENTION_WINDOW,'"', '')
	,MAX_PROJECT_VERSIONS	= REPLACE(MAX_PROJECT_VERSIONS,'"', '')	
	,SERVER_LOGGING_LEVEL	= REPLACE(SERVER_LOGGING_LEVEL,'"', '')	
	,Location				= REPLACE(Location,'"', '')
	,DatabaseSize			= REPLACE(DatabaseSize,'"', '')
FROM [LOAD].[SSIScatalogue_load]

INSERT INTO  [dbo].[SSIScatalogue]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[SSIScatalogue_load]
*/
--------
-- 34 -- 
--------
TRUNCATE TABLE [LOAD].[StartupProcedures_load]
SET @tsql = 'BULK INSERT [LOAD].[StartupProcedures_load] FROM ''' + @path + '-StartupProcedures.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[StartupProcedures_load]
SET 
	InstanceName		= REPLACE(InstanceName,'"', '')	
	,StartupProcedure	= REPLACE(StartupProcedure,'"', '')
FROM [LOAD].[StartupProcedures_load]

INSERT INTO  [dbo].[StartupProcedures]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[StartupProcedures_load]

--------
-- 35 -- 
--------
TRUNCATE TABLE [LOAD].[TDEencryption_load]
/*
SET @tsql = 'BULK INSERT [LOAD].[TDEencryption_load] FROM ''' + @path + '-TDEencryption.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[TDEencryption_load]
SET 
	InstanceName			= REPLACE(InstanceName,'"', '')	
	,database_name			= REPLACE(database_name,'"', '')	
	,encryption_state		= REPLACE(encryption_state,'"', '')	
	,encryption_state_desc	= REPLACE(encryption_state_desc,'"', '')		
	,create_date			= REPLACE(create_date,'"', '')		
	,set_date				= REPLACE(set_date,'"', '')	
FROM [LOAD].[TDEencryption_load]

INSERT INTO  [dbo].[TDEencryption]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[TDEencryption_load]
*/
--------
-- 36 -- 
--------
TRUNCATE TABLE [LOAD].[Traces_load]
SET @tsql = 'BULK INSERT [LOAD].[Traces_load] FROM ''' + @path + '-Traces.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[Traces_load]
SET 
	InstanceName	= REPLACE(InstanceName,'"', ''), 
	id				= REPLACE(id,'"', ''),
	status			= REPLACE(status,'"', ''),
	Path			= REPLACE(Path,'"', ''),
	start_time		= REPLACE(start_time,'"', ''),
	last_event_time = REPLACE(last_event_time,'"', '')
FROM [LOAD].[Traces_load]

INSERT INTO  [dbo].[Traces]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[Traces_load]

--------
-- 37 -- 
--------
TRUNCATE TABLE [LOAD].[UnusedIndexes_load]
SET @tsql = 'BULK INSERT [LOAD].[UnusedIndexes_load] FROM ''' + @path + '-UnusedIndexes.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[UnusedIndexes_load]
SET 
	InstanceName	= REPLACE(InstanceName,'"', '')
	,DatabaseName	= REPLACE(DatabaseName,'"', '')
	,SchemaName		= REPLACE(SchemaName,'"', '')
	,ObjectName		= REPLACE(ObjectName,'"', '')
	,IndexName		= REPLACE(IndexName,'"', '')
FROM [LOAD].[UnusedIndexes_load]

INSERT INTO  [dbo].[UnusedIndexes]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[UnusedIndexes_load]


--------
-- 38 -- 
--------
TRUNCATE TABLE [LOAD].[Backups_load]
SET @tsql = 'BULK INSERT [LOAD].[Backups_load] FROM ''' + @path + '-Backups.csv''' + ' WITH (FIRSTROW = 2, DATAFILETYPE = ''char'', FIELDTERMINATOR = ''","'');'
EXEC(@tsql)

UPDATE [LOAD].[Backups_load]
SET 
	 [Instance Name]= REPLACE([Instance Name],'"', ''),
	 [Host Name]= REPLACE([Host Name],'"', ''),
	 [Database Name]= REPLACE([Database Name],'"', ''),
	 [Recovery Model]= REPLACE([Recovery Model],'"', ''),
	 [Recent Full Database]= REPLACE([Recent Full Database],'"', ''),
	 [Recent Transaction Log]= REPLACE([Recent Transaction Log],'"', '')
FROM [LOAD].[Backups_load]

INSERT INTO  [dbo].[Backups]
  SELECT 
      *
	  ,@client as [Client]
	  ,@timestamp AS [timestamp]
  FROM [LOAD].[Backups_load]


--------------------

DECLARE @ts datetime	= (SELECT TOP 1 [timestamp] FROM [dbo].[Hardware] WHERE [timestamp] IS NOT NULL)

UPDATE [dbo].[Hardware] SET [timestamp] = @ts
UPDATE [dbo].[AAG] SET [timestamp] = @ts
UPDATE [dbo].[AAGbackup] SET [timestamp] = @ts
UPDATE [dbo].[Backups] SET [timestamp] = @ts
UPDATE [dbo].[ChangeTracking] SET [timestamp] = @ts
UPDATE [dbo].[Compression] SET [timestamp] = @ts
UPDATE [dbo].[Configuration] SET [timestamp] = @ts
UPDATE [dbo].[DatabaseDetails] SET [timestamp] = @ts
UPDATE [dbo].[DatabaseMasterKey] SET [timestamp] = @ts
UPDATE [dbo].[DatabasesRoles] SET [timestamp] = @ts
UPDATE [dbo].[DBoption] SET [timestamp] = @ts
UPDATE [dbo].[DiskSpace] SET [timestamp] = @ts
UPDATE [dbo].[EcryptionCertificates] SET [timestamp] = @ts
UPDATE [dbo].[ExtendedEvents] SET [timestamp] = @ts
UPDATE [dbo].[Hardware] SET [timestamp] = @ts
UPDATE [dbo].[IdleDatabases] SET [timestamp] = @ts
UPDATE [dbo].[ifi_lim] SET [timestamp] = @ts
UPDATE [dbo].[IndexFragmentation] SET [timestamp] = @ts
UPDATE [dbo].[IntegrityCheck] SET [timestamp] = @ts
UPDATE [dbo].[IPs] SET [timestamp] = @ts
UPDATE [dbo].[InstanceInformation] SET [timestamp] = @ts
UPDATE [dbo].[isolation_level] SET [timestamp] = @ts
UPDATE [dbo].[Jobs] SET [timestamp] = @ts
UPDATE [dbo].[JobsScheduler] SET [timestamp] = @ts
UPDATE [dbo].[MaintenencePlans] SET [timestamp] = @ts
UPDATE [dbo].[MissedIndexes] SET [timestamp] = @ts
UPDATE [dbo].[MSDB] SET [timestamp] = @ts
UPDATE [dbo].[OperationSystem] SET [timestamp] = @ts
UPDATE [dbo].[OrphanUsers] SET [timestamp] = @ts
UPDATE [dbo].[QueryStore] SET [timestamp] = @ts
UPDATE [dbo].[ServerRoles] SET [timestamp] = @ts
UPDATE [dbo].[Services] SET [timestamp] = @ts
UPDATE [dbo].[SSIScatalogue] SET [timestamp] = @ts
UPDATE [dbo].[StartupProcedures] SET [timestamp] = @ts
UPDATE [dbo].[TDEencryption] SET [timestamp] = @ts
UPDATE [dbo].[Traces] SET [timestamp] = @ts
UPDATE [dbo].[UnusedIndexes] SET [timestamp] = @ts
UPDATE [dbo].[UpdateStatistics] SET [timestamp] = @ts
UPDATE [dbo].[VirtualLogFile] SET [timestamp] = @ts













