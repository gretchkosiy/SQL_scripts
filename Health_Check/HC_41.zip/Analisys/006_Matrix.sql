--DECLARE @SQL1 VARCHAR(MAX) = 'SELECT '
--DECLARE @SQL2 VARCHAR(MAX) = '@@VERSION'

--EXEC(@SQL1 + @SQL2)





DECLARE @a VARCHAR(MAX) 
SET @a = 'CREATE PROC USP_MATRIX_PIVOT 
AS
BEGIN
	SET NOCOUNT ON

-- List of DB users that should be ignored for all instances
DECLARE @ListIgnoredUsers TABLE(Name VARCHAR(40))
INSERT INTO @ListIgnoredUsers VALUES (''MS_DataCollectorInternalUser'')

-- List of SQL Server versions - for SPs and CUs
-- Last check - 20/03/2024 - https://sqlserverbuilds.blogspot.com/
DECLARE @ListSQLVersions TABLE(ID int, Name VARCHAR(40), SP int, CU int)
INSERT INTO @ListSQLVersions VALUES (1,''2000'',2039,2305)
INSERT INTO @ListSQLVersions VALUES (2,''2005'',5000,5266)
INSERT INTO @ListSQLVersions VALUES (3,''2008'',6000,6000)
INSERT INTO @ListSQLVersions VALUES (4,''2008 R2'',6000,6000)
INSERT INTO @ListSQLVersions VALUES (5,''2012'',7001,7001)
INSERT INTO @ListSQLVersions VALUES (6,''2014'',6024,6329)
INSERT INTO @ListSQLVersions VALUES (7,''2016'',6300,6300)
INSERT INTO @ListSQLVersions VALUES (8,''2017'',1000,3456)
INSERT INTO @ListSQLVersions VALUES (9,''2019'',2000,4355)
INSERT INTO @ListSQLVersions VALUES (10,''2022'',1000,4115)

DECLARE @vlfs INT	= 500
DECLARE @free15 INT	= 15
DECLARE @free40 INT	= 40
--DECLARE @Domain varchar(max) = ''BRENCL-AU%''
DECLARE @Domain varchar(max) = ''RFDSCENTRAL''

DECLARE @ts datetime	= (SELECT TOP 1 [timestamp] FROM [dbo].[Hardware] WHERE [timestamp] IS NOT NULL)

DROP TABLE IF EXISTS #t 

SELECT DISTINCT 
	  CO.[Host Name]														AS [Host Name]
      ,CO.INS																AS [Instance Name]
	  ,VER.SPs																AS [SP Patching]
	  ,VER.CUs																AS [CU Patching]
	  ,TM2.MEM																AS [RAM Gb]
	  ,MinRAM.[MinRAM Mb]													AS [MinRAM Mb]
	  ,MaxRAM.[MaxRAM Gb]													AS [MaxRAM Gb]	
	  ,MaxRAM.[MaxRAM status]												AS [MaxRAM status]	
	  ,MinRAM.[MinRAM status]												AS [MinRAM status]
-- ?? 03  Maintenance jobs missing. Now done by manually assesments
	  ,CASE WHEN AutoClose.[Host Name] IS NULL THEN ''X'' ELSE '''' END		AS [AutoClose/shrink]
	  ,AutoGrow.[AutoGrow]													AS [AutoGrow]
	  ,LP.[LockInMemory InstantFile]										AS [LockInMemory InstantFile]
	  ,CASE WHEN AD.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [High SQL Server role]
	  ,CASE WHEN CHK.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [CHECKSUM]
	  ,TM2P.CPUs															AS [CPUs]
	  ,TM2P.TempDBcount														AS [TempDBcount]
	  ,CASE WHEN (TM2P.CPUs <> TM2P.TempDBcount) OR (TM2P.TempDBcount IS NULL) THEN CAST(TM2P.TempDBcount AS VARCHAR(MAX)) + '' DBs for '' + CAST(TM2P.CPUs AS VARCHAR(MAX)) + '' CPUs'' ELSE '' '' END	
																			AS [TempDBcount status]
      ,CASE WHEN AA.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [Administrator access]
	  ,CASE WHEN VLFs.[Host Name] IS NULL THEN '''' ELSE CAST(VLFs.[Count] AS VARCHAR(MAX)) END		AS [VLF]
	  ,SA.JobsWith_no_SA													AS [Jobs no SA]
	  ,CASE WHEN VC.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [Different Collation]
	  ,CASE WHEN LB.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [Tranlog Backup]
	  ,CASE WHEN FB.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [Full Backup]
	  ,CASE WHEN SR.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [SQL running]
	  ,CASE WHEN Free15.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [Free15]
	  ,CASE WHEN Comp.[Host Name] IS NULL THEN '''' ELSE ''X'' END			AS [Backup compression]
	  ,CASE WHEN BackupDrive.[Host Name] IS NULL THEN '''' ELSE ''X'' END 
																			AS [Backup DriveLetter]
	  ,CASE WHEN DBroleAdmin.[Host Name] IS NULL THEN '''' ELSE ''X'' END 
																			AS [DBroleAdmin]
	  ,SA.MaintenancePlansWith_no_SA										AS [MP no SA]	
	  ,CAST(ISNULL(DOP.Value,'''')	AS VARCHAR(MAX))						AS [DOP]
	  ,CASE WHEN ACC.Account IS NULL THEN ''X'' ELSE '''' END		    AS [AD service]
	  ,CASE WHEN DEF.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [Default Location]
	  ,CASE WHEN ORP.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [Orphan users]
	  ,CASE WHEN CMP.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [compatibility level]
	  ,CASE WHEN IDLE.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [Idle DBs]
	  ,CASE WHEN DBletter.[Host Name] IS NULL THEN ''X'' ELSE '''' END	AS [System letter]
	  ,CASE WHEN Free40.[Host Name] IS NULL THEN '''' ELSE ''X'' END	AS [Free40]
	  ,CASE WHEN UPD.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [Update Statistics]
	  ,CASE WHEN OFFLINE.[Host Name] IS NULL THEN '''' ELSE ''X'' END	AS [DB offline]
	  ,CASE WHEN MSDB.[Host Name] IS NULL THEN '''' ELSE ''X'' END		AS [MSDB]
	  ,CASE WHEN INTCHK.[Host Name] IS NULL THEN '''' ELSE ''X'' END	AS [Integrity Check]
	  ,CASE WHEN DEFRAG.[Host Name] IS NULL THEN '''' ELSE ''X'' END	AS [Index defrag]	  
-- 130202024
	  ,CASE WHEN CT.[InstanceName] IS NULL THEN '''' ELSE ''X'' END		AS [Change Tracking]
	  ,CASE WHEN TBLCOMP.[InstanceName] IS NULL THEN '''' ELSE ''X'' END AS [Compression]
	  ,CASE WHEN CONF.[DAC] = ''Disabled'' THEN '''' ELSE ''Ok'' END		AS [DAC]
	  ,CONF.[KERBEROS]												AS [KERBEROS]
	  ,CONF.[TCPport]												AS [TCPport]
	  ,CONF.[AuthentificationMode]									AS [AuthentificationMode]	  
	  ,CONF.[MailServer]											AS [MailServer]	
	  ,CONF.[MultiServerJobs]										AS [MultiServerJobs]	
	  ,CASE WHEN [DatabaseMasterKey].[InstanceName] is null THEN '''' ELSE ''Exists'' END AS [DatabaseMasterKey]
	  ,CASE WHEN [EcryptionCertificates].[InstanceName] is null THEN '''' ELSE ''Exists'' END AS [EcryptionCertificates]	  
	  ,CASE WHEN [ExtendedEvents].[InstanceName] is null THEN '''' ELSE ''Enabled'' END AS [ExtendedEvents]	  
	  ,CASE WHEN [isolation_level].[Instance Name] is null THEN '''' ELSE ''Set'' END AS [isolation_level]	  
	  ,CASE WHEN [QueryStore].[InstanceName] is null THEN '''' ELSE ''Yes'' END AS [QueryStore]	  
	  ,CASE WHEN [SSIScatalogue].[InstanceName] is null THEN '''' ELSE [SSIScatalogue].[Location] END AS [SSIScatalogue]	  
	  ,CASE WHEN [StartupProcedures].[InstanceName] is null THEN '''' ELSE ''Yes'' END AS [StartupProcedures]	  
	  ,CASE WHEN [TDEencryption].[InstanceName] is null THEN '''' ELSE ''Yes'' END AS [TDEencryption]	
	  ,CASE WHEN [Traces].[InstanceName] is null THEN '''' ELSE ''Yes'' END AS [Traces]	

	  ,CASE WHEN VLFs1.[Host Name] IS NULL THEN '''' ELSE CAST(VLFs1.[Count] AS VARCHAR(MAX)) END		AS [VLFs1]

INTO #t
FROM (SELECT DISTINCT UPPER([HostName]) AS [Host Name], 
			CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [InstanceName] END AS [Instance Name],
			CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [HostName] + ''\'' + [InstanceName] END AS INS 
		FROM  [dbo].[Configuration]) AS CO
	LEFT JOIN (SELECT DISTINCT [Host Name], CAST(ISNULL([Value],0) as numeric) AS MEM FROM [dbo].[Hardware] WHERE [Type] = ''TotalPhysicalMemory'') AS TM2 
		ON TM2.[Host Name] = CO.[Host Name] 
	LEFT JOIN (SELECT 
					InstI.[Host Name]
					,InstI.[Instance Name]
					--,MEM
					,InstI.[Value] / 1024 AS [MaxRAM Gb]
					--,CASE WHEN (InstI.[Value] <> 2147483647) AND (InstI.[Value]/ 1024 + 4 <= TFM.MEM)THEN '''' ELSE ''X'' END AS [MaxRAM status]		
					,CASE WHEN (InstI.[Value] <> 2147483647) AND (InstI.[Value]/ 1024 + 4 <= TFM.MEM)THEN CAST(InstI.[Value]/ 1024 AS VARCHAR(MAX)) + ''GB from '' + CAST(MEM AS VARCHAR(MAX))  ELSE '''' END AS [MaxRAM status]		
				FROM [dbo].[InstanceInformation] AS InstI
					LEFT JOIN (SELECT DISTINCT [Host Name], CAST(ISNULL([Value],0) as numeric) AS MEM FROM [dbo].[Hardware] WHERE [Type] = ''TotalPhysicalMemory'') AS TFM
						ON TFM.[Host Name] = InstI.[Host Name] 
				WHERE [Type]  = ''MaxRAM'') AS MaxRAM  
		ON CO.[Host Name] = MaxRAM.[Host Name]  AND MaxRAM.[Instance Name] = CO.INS
	LEFT JOIN (SELECT 
					InstI.[Host Name]
					,InstI.[Instance Name]
					--,MEM
					,InstI.[Value] AS [MinRAM Mb]
					-- ,CASE WHEN InstI.[Value] <= 16 THEN ''X'' ELSE '''' END AS [MinRAM status]		
					,CASE WHEN InstI.[Value] <= 16 THEN '''' ELSE CAST(InstI.[Value]/ 1024 AS VARCHAR(MAX))  + ''GB'' END AS [MinRAM status]
				FROM [dbo].[InstanceInformation] AS InstI
					LEFT JOIN (SELECT DISTINCT [Host Name], CAST(ISNULL([Value],0) as numeric) AS MEM FROM [dbo].[Hardware] WHERE [Type] = ''TotalPhysicalMemory'') AS TFM
						ON TFM.[Host Name] = InstI.[Host Name] 
				WHERE [Type]  = ''MinRAM'') AS MinRAM
		ON CO.[Host Name] = MinRAM.[Host Name] AND MinRAM.[Instance Name] = CO.INS



	LEFT JOIN (SELECT DISTINCT [Instance Name], [Host Name] FROM [dbo].[DBoption] WHERE [auto_close] <> ''N'' or [auto_shrink] <> ''N'') AS AutoClose
		ON AutoClose.[Host Name] = CO.[Host Name] AND AutoClose.[Instance Name] = CO.INS

	LEFT JOIN (SELECT 
					CO00.[Host Name]
					,CO00.INS AS [Instance Name]
					,CASE WHEN AutoGrow00.[Host Name] IS NULL THEN '''' ELSE ''Need review'' END AS [AutoGrow]
				FROM (SELECT DISTINCT UPPER([HostName]) AS [Host Name], 
							CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [HostName] + ''\'' + [InstanceName] END AS INS 
						FROM  [dbo].[Configuration]) AS CO00
					LEFT JOIN (SELECT DISTINCT [Instance Name]
								  ,[Host Name]
							  FROM [dbo].[DatabaseDetails]
							  WHERE [Auto-growth] like ''%percent%'') AS AutoGrow00
						ON  AutoGrow00.[Host Name] = CO00.[Host Name] AND AutoGrow00.[Instance Name] = CO00.INS) AutoGrow
		ON  AutoGrow.[Host Name] = CO.[Host Name] AND AutoGrow.[Instance Name] = CO.INS

	LEFT JOIN (SELECT DISTINCT [Instance Name]
				  ,[Host Name]
			  FROM [dbo].[ServerRoles]
			  WHERE [User name] <> ''sa''
				AND [User name] not like ''NT SERVICE\%''
				AND [User name] not like ''NT AUTHORITY\%'') AS AD
		ON  AD.[Host Name] = CO.[Host Name] AND AD.[Instance Name] = CO.INS


	LEFT JOIN (
				SELECT 
					CO00.[Host Name]
					,CO00.INS AS [Instance Name]
					,CASE WHEN LP00.[LockPages] = 1 THEN ''Lock'' + CASE WHEN LP00.[InstantInit] = 1 THEN '' + Init'' ELSE '''' END ELSE CASE WHEN LP00.[InstantInit] = 1 THEN ''Init'' ELSE '''' END END AS [LockInMemory InstantFile]
				FROM (SELECT DISTINCT UPPER([HostName]) AS [Host Name], 
							CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [HostName] + ''\'' + [InstanceName] END AS INS 
						FROM  [dbo].[Configuration]) AS CO00
					LEFT JOIN (SELECT DISTINCT [Host Name], [LockPages], [InstantInit], [Host Name] + CASE WHEN CHARINDEX(''$'',name) = 0 THEN '''' ELSE ''\'' + SUBSTRING(name,CHARINDEX(''$'',name)+1,LEN(name) - CHARINDEX(''$'',name)) END AS INS  FROM [dbo].[ifi_lim]) AS LP00
						ON  LP00.[Host Name] = CO00.[Host Name] AND LP00.INS = CO00.INS 
							
				--SELECT 
				--	CO00.[Host Name]
				--	,CO00.INS AS [Instance Name]
				--	,CASE WHEN LP00.[Host Name] IS NULL THEN ''X'' ELSE '''' END	AS [LockInMemory InstantFile]
				--FROM (SELECT DISTINCT UPPER([HostName]) AS [Host Name], 
				--			CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [HostName] + ''\'' + [InstanceName] END AS INS 
				--		FROM  [dbo].[Configuration]) AS CO00
				--	LEFT JOIN (SELECT DISTINCT [Host Name] FROM [dbo].[ifi_lim] WHERE [LockPages] = 1 OR [InstantInit] = 1) AS LP00
				--		ON  LP00.[Host Name] = CO00.[Host Name] 
						
						) AS LP
		ON LP.[Host Name] = CO.[Host Name] AND LP.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT
					II3.[Host Name]
				   ,II3.[Instance Name]
				   ,II3.[Value] CPUs
				   ,TM2.TempDBcount
				  FROM [dbo].[InstanceInformation] II3
				  LEFT JOIN ( SELECT 
								DD1.[Instance Name]
								,DD1.[Host Name]
								,COUNT(*) as [TempDBcount]
							 FROM [dbo].[DatabaseDetails] DD1
							 WHERE DD1.[Database Name] like ''temp%'' and DD1.type = 0
							 GROUP BY DD1.[Instance Name], DD1.[Host Name], DD1.[Database Name])  TM2 
						ON II3.[Host Name] = TM2.[Host Name] AND II3.[Instance Name] = TM2.[Instance Name] 
				 WHERE II3.[Type] = ''Processors'' )  AS TM2P
		ON TM2P.[Host Name] = CO.[Host Name] AND TM2P.[Instance Name] = CO.INS

	LEFT JOIN (SELECT DISTINCT [Host Name]
			  FROM [dbo].[OperationSystem]
			  WHERE [Type] = ''Local admin'' 
				AND [Value] <> [Host Name] + ''\Administrator''
				AND [Value] <> @Domain + ''\Domain Admins'') AS AA
		ON AA.[Host Name] = CO.[Host Name]	 


	LEFT JOIN ( SELECT [Instance Name]
					  ,[Host Name]
					  ,MAX(CAST([Count] AS INT)) AS [Count]
				  FROM [dbo].[VirtualLogFile]
				  GROUP BY [Instance Name],[Host Name]
				  HAVING MAX(CAST([Count] AS INT))  >  @vlfs
				  ) AS VLFs
		ON VLFs.[Host Name] = CO.[Host Name] AND VLFs.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT [Instance Name]
					  ,[Host Name]
					  ,MAX(CAST([Count] AS INT)) AS [Count]
				  FROM [dbo].[VirtualLogFile]
				  GROUP BY [Instance Name],[Host Name]
				  --HAVING MAX(CAST([Count] AS INT))  >  @vlfs
				  ) AS VLFs1
		ON VLFs1.[Host Name] = CO.[Host Name] AND VLFs1.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT [HostName] AS [Host Name] 
					  ,CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [InstanceName] END AS [Instance Name]
					  ,CASE WHEN [MaintenancePlansWith_no_SA] = 0 THEN '''' ELSE CAST([MaintenancePlansWith_no_SA] AS VARCHAR(20)) END [MaintenancePlansWith_no_SA]
					  ,CASE WHEN [JobsWith_no_SA] = 0 THEN '''' ELSE CAST([JobsWith_no_SA] AS VARCHAR(20)) END [JobsWith_no_SA]
				  FROM [dbo].[Configuration]
				) AS SA
		ON SA.[Host Name] = CO.[Host Name] AND SA.[Instance Name] = CO.[Instance Name]

	LEFT JOIN (SELECT DISTINCT
					   DO.[Instance Name]
					  ,DO.[Host Name]
				  FROM [dbo].[DBoption] DO 
				  LEFT JOIN (SELECT [Host Name]
					  ,[Instance Name]
					  ,[Value]
					 FROM [dbo].[InstanceInformation]
					 WHERE [Type] = ''Instance Collation'') IC 
				  ON  DO.[Instance Name] = IC.[Instance Name] 
				  AND DO.[Host Name] = IC.[Host Name]
				  AND DO.[Collation] = IC.[Value]
				  --INNER JOIN (SELECT [Host Name]
					 -- ,[Instance Name]
					 -- ,[Value]
					 --FROM [dbo].[InstanceInformation]
					 --WHERE [Type] = ''Instance Collation'') IJ 
				  --ON  DO.[Instance Name] = IJ.[Instance Name] 
				  --AND DO.[Host Name] = IJ.[Host Name]
				WHERE IC.[Value] IS NULL
				) AS VC
		ON VC.[Host Name] = CO.[Host Name] AND VC.[Instance Name] = CO.INS

	LEFT JOIN (  SELECT DISTINCT 
 					[Host Name]
					,[Instance Name]
			   FROM  [dbo].[Backups] --[dbo].[Backups]
			   WHERE [Recovery Model] <> ''SIMPLE''
				and [Recent Transaction Log] <= DATEADD(day,-1,@ts)  ) AS LB
		ON LB.[Host Name] = CO.[Host Name] AND LB.[Instance Name] = CO.INS

	LEFT JOIN (  SELECT DISTINCT 
					[Instance Name]
					,[Host Name]
			   FROM  [dbo].[Backups] --[dbo].[Backups]
			   WHERE  [Recent Full Database] <= DATEADD(day,-7,@ts) 
			   AND [Recent Full Database] <> '''') AS FB
		ON FB.[Host Name] = CO.[Host Name] AND FB.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT [Host Name]
				  ,[Service Name]
				  ,[Account]
				  ,[Status]
			  FROM [dbo].[Services]
			  WHERE [Service Name] IN (''MSSQLSERVER'', ''SQLSERVERAGENT'') AND [Status] <> ''Running'' ) AS SR
		ON SR.[Host Name] = CO.[Host Name] 
	LEFT JOIN ( SELECT DISTINCT [Host Name]
				FROM [dbo].[DiskSpace]
				WHERE CAST([FreeSpace] AS BIGINT) * 100 /CAST([Size] AS BIGINT) <= @free15 ) AS Free15
		ON Free15.[Host Name] = CO.[Host Name] 
	LEFT JOIN ( SELECT DISTINCT [Host Name]
				FROM [dbo].[DiskSpace]
				WHERE CAST([FreeSpace] AS BIGINT) * 100 /CAST([Size] AS BIGINT) <= @free40 ) AS Free40
		ON Free40.[Host Name] = CO.[Host Name] 
	LEFT JOIN ( SELECT DISTINCT [Host Name]
					  ,[Instance Name]
				  FROM [dbo].[InstanceInformation]
				  WHERE [Type] = ''DefaultBackupCompression'' AND [Value] <> ''Enabled'') AS Comp
		ON Comp.[Host Name] = CO.[Host Name] AND Comp.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT
					DD.[Host Name]
				   ,DD.[Instance Name]
				   --,DD.Drive
				   --,DB.Drive
				  FROM (
				  SELECT [Host Name]
					  ,[Instance Name]
				   ,SUBSTRING([Value],1,1) AS [Drive]
				  FROM [dbo].[InstanceInformation]
				  WHERE [Type] in (''DefaultLog'', ''DefaultFile'')) DD
				  LEFT JOIN (
				   SELECT [Host Name]
					 ,[Instance Name]
					 ,SUBSTRING([Value],1,1)  AS [Drive]
					FROM [dbo].[InstanceInformation]
					WHERE [Type] in (''BackupDirectory'')
				  ) DB ON DD.[Host Name] = DB.[Host Name] AND DD.[Instance Name] = DB.[Instance Name] AND DD.Drive = DB.Drive
				WHERE DB.Drive IS NOT NULL ) AS BackupDrive
		ON BackupDrive.[Host Name] = CO.[Host Name] AND BackupDrive.[Instance Name] = CO.INS

	LEFT JOIN (SELECT DISTINCT
					[Instance Name]
				   ,[Host Name]
			  FROM [dbo].[DatabasesRoles]
			  WHERE [Role] NOT IN (''db_datareader'', ''db_datawriter'', ''db_denydatawriter'', ''db_denydatareader'', ''db_backupoperator'')) AS DBroleAdmin
		ON DBroleAdmin.[Host Name] = CO.[Host Name] AND DBroleAdmin.[Instance Name] = CO.INS




	LEFT JOIN ( SELECT [Host Name]
					  ,[Instance Name]
					  ,[Value]
				  FROM [dbo].[InstanceInformation]
				  WHERE [Type] = ''MaxDegreeOfParallelism'' AND [Value] <> ''0'' ) AS DOP 
		ON DOP.[Host Name] = CO.[Host Name] AND DOP.[Instance Name] = CO.INS
 
	LEFT JOIN ( SELECT DISTINCT [Host Name]
					  ,[Instance Name]
					  --,[Value]
					  --,[Type]
				  FROM [dbo].[InstanceInformation]
				  WHERE [Type] in (''DefaultLog'', ''DefaultFile'',''BackupDirectory'')
					and SUBSTRING([Value],1,1) = ''C'') AS DEF  
		ON DEF.[Host Name] = CO.[Host Name] AND DEF.[Instance Name] = CO.INS

	LEFT JOIN ( 

	SELECT DISTINCT
	   [Instance Name]
      ,[Host Name]
	FROM [dbo].[OrphanUsers]
	WHERE [User Name] not in (SELECT Name FROM @ListIgnoredUsers)
	
				--SELECT DISTINCT
				--	  [Instance Name]
				--	  ,[Host Name]
				--	  --,[DBowner]
				--  FROM  [dbo].[DBoption]
				--  WHERE [DBowner] <> ''sa''
				  
				  ) AS ORP
		ON ORP.[Host Name] = CO.[Host Name] AND ORP.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT 
					DB.[Instance Name]
					  ,DB.[Host Name]
					  --,DB.[Database Name]
					  --,DB.[Compatibility]
				   --,IV1.DBversion
				  FROM [dbo].[DBoption] AS DB
				  LEFT JOIN 
				   (SELECT [Host Name]
					,[Instance Name]
					--,CAST(SUBSTRING([Value],1,2) as INT) * 10 AS [DBversion]
					,CASE 
						WHEN SUBSTRING([Value],2,1) = ''.'' THEN SUBSTRING([Value],1,1) 
						ELSE SUBSTRING([Value],1,2) 
					END * 10 AS [DBversion]
				   FROM [dbo].[InstanceInformation]
				   WHERE [Type] = ''Version'') IV ON IV.[Host Name] = DB.[Host Name] AND IV.[Instance Name] = DB.[Instance Name] AND iv.DBversion = db.Compatibility
				  INNER JOIN 
				   (SELECT [Host Name]
					,[Instance Name]
					--,CAST(SUBSTRING([Value],1,2) as INT) * 10 AS [DBversion]
					,CASE 
						WHEN SUBSTRING([Value],2,1) = ''.'' THEN SUBSTRING([Value],1,1) 
						ELSE SUBSTRING([Value],1,2) 
					END * 10 AS [DBversion]
				   FROM [dbo].[InstanceInformation]
				   WHERE [Type] = ''Version'') IV1 ON IV1.[Host Name] = DB.[Host Name] AND IV1.[Instance Name] = DB.[Instance Name] 
				WHERE IV.DBversion IS NULL) AS CMP
		ON CMP.[Host Name] = CO.[Host Name] AND CMP.[Instance Name] = CO.INS

	LEFT JOIN (SELECT DISTINCT [Instance Name]
				  ,[Host Name]
			  FROM [dbo].[IdleDatabases]) AS IDLE
		ON IDLE.[Host Name] = CO.[Host Name] AND IDLE.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT [Instance Name]
				  ,[Host Name]
			  FROM [dbo].[DatabaseDetails]
			  WHERE [Database Name] in (''master'', ''tempdb'', ''msdb'', ''model'', ''SSISDB'')
			  and SUBSTRING([File Name],1,1) = ''C'') AS DBletter
		ON DBletter.[Host Name] = CO.[Host Name] AND DBletter.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT  [Instance Name]
				  ,[Host Name]
				  --,[Database Name]
			  FROM [dbo].[DBoption]
			  WHERE [Page Verify] <> ''CHECKSUM'') AS CHK ON CHK.[Host Name] = CO.[Host Name] AND CHK.[Instance Name] = CO.INS
	LEFT JOIN ( 
				SELECT 
					CC.[Host Name]
					,CC.[Instance Name]
					--,BUILD
					--,SP
					--,CU
					,CASE 
						WHEN BUILD >= SP THEN ''''
						ELSE  CAST(BUILD AS VARCHAR(MAX)) + '' from '' +  CAST(SP AS VARCHAR(MAX)) --''X''
					END as SPs
					,CASE 
						WHEN BUILD >= CU THEN ''''
						ELSE   CAST(BUILD AS VARCHAR(MAX)) + '' from '' +  CAST(CU AS VARCHAR(MAX)) --''X''
					END as CUs					
				FROM ( SELECT DISTINCT
							UPPER([HostName]) AS [Host Name], 
							CASE 
								WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) 
								ELSE [InstanceName] 
							END AS [Instance Name]
							--,[ProductBuild] 
							,CASE 
								WHEN SUBSTRING([ProductVersion],2,1) = ''.'' THEN SUBSTRING([ProductVersion],1,1) -1
								ELSE 
									CASE 
										WHEN SUBSTRING([ProductVersion],1,2) = 10 THEN 
											CASE
												WHEN SUBSTRING([ProductVersion],4,2) = 50 THEN 4
												ELSE 3 
											END 
										ELSE SUBSTRING([ProductVersion],1,2) - 6
									END
							END AS BID
							,CASE 
								WHEN SUBSTRING([ProductVersion],2,1) = ''.'' THEN SUBSTRING([ProductVersion],6,4)
								ELSE 
									CASE 
										WHEN SUBSTRING([ProductVersion],1,2) = 10 THEN 
											CASE
												WHEN SUBSTRING([ProductVersion],4,2) = 50 THEN SUBSTRING([ProductVersion],7,4)
												ELSE 3 
											END 
										ELSE SUBSTRING([ProductVersion],6,4)
									END
							END AS BUILD
						FROM [dbo].[Configuration]) AS CC
						LEFT JOIN @ListSQLVersions ON ID = BID	
	
				--SELECT DISTINCT 
				--	UPPER([HostName]) AS [Host Name], 
				--	CASE WHEN UPPER([InstanceName]) = ''DEFAILT'' THEN UPPER([HostName]) ELSE [InstanceName] END AS [Instance Name], 
				--	[ProductBuild] 
				--FROM  [dbo].[Configuration]
				
				
				) AS VER
		ON VER.[Host Name] = CO.[Host Name] AND VER.[Instance Name] = CO.[Instance Name]
	LEFT JOIN ( SELECT [Host Name]
					  ,[Account]
				  FROM [dbo].[Services]
				  WHERE [Service Name] IN (''MSSQLSERVER'') AND [Account] like @Domain) AS ACC
		ON ACC.[Host Name] = CO.[Host Name] 

	LEFT JOIN ( SELECT DISTINCT 
				[Instance Name]
				  ,[Host Name]
				  --,[Database Name]
				  --,[Last Executed]
				  --,[Client]
				  --,[timestamp]
			  FROM [dbo].[UpdateStatistics]
			  WHERE 
				[Database Name] NOT IN (''master'', ''tempdb'', ''msdb'', ''model'', ''SSISDB'')
				and [Last Executed] <= DATEADD(day,-7,@ts) ) AS UPD
		ON UPD.[Host Name] = CO.[Host Name]  AND UPD.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT [Instance Name]
				  ,[Host Name]
			  FROM [dbo].[DBoption]
			  WHERE [State] = ''OFFLINE'') AS OFFLINE
		ON OFFLINE.[Host Name] = CO.[Host Name]  AND OFFLINE.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT [ServerName] AS [Instance Name]
					,CASE 
						WHEN CHARINDEX(''\'',[ServerName]) = 0 THEN [ServerName]
						ELSE SUBSTRING([ServerName], 1, CHARINDEX(''\'',[ServerName])-1)
					END AS [Host Name]
			  FROM [dbo].[MSDB]
			  WHERE [DataFileSizeMB] > 1000
				OR [LogFileSizeMB] > [DataFileSizeMB]
				OR [sysmail_log] > 100
				OR [sysmail_allitems] > 100
				OR [sysmaintplan_log] > 1000
				OR [sysmaintplan_logdetail] > 1000
				OR [sysdtslog90] > 100
				OR [sysmail_attachments] > 100) AS MSDB
		ON MSDB.[Host Name] = CO.[Host Name]  AND MSDB.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT 
				[Instance Name]
				  ,[Host Name]
			  FROM [dbo].[IntegrityCheck]
			  WHERE 
				[Database Name] NOT IN (''master'', ''tempdb'', ''msdb'', ''model'', ''SSISDB'')
				and [Last Executed] <= DATEADD(day,-7,@ts) ) AS INTCHK
		ON INTCHK.[Host Name] = CO.[Host Name]  AND INTCHK.[Instance Name] = CO.INS

	LEFT JOIN ( SELECT DISTINCT [Instance Name]
					  ,[Host Name]
					  --,[Database Name]
					  --,[Table Name]
					  --,[Index Size (MB)]
					  --,[Max Percentage]
					  --,[Average Percentage]
					  ----,[Client]
					  ----,[timestamp]
				  FROM [dbo].[IndexFragmentation]
				  WHERE [Index Size (MB)] <> 0
					AND ([Max Percentage] > 10.0 OR [Average Percentage] > 10.0)
					) AS DEFRAG
		ON DEFRAG.[Host Name] = CO.[Host Name]  AND DEFRAG.[Instance Name] = CO.INS
-- 13022024
LEFT JOIN [dbo].[ChangeTracking] CT ON CT.[InstanceName] = CO.INS
LEFT JOIN (SELECT DISTINCT [InstanceName] FROM [dbo].[Compression] WHERE [Compression] <> ''NONE'') TBLCOMP ON TBLCOMP.[InstanceName] = CO.INS
LEFT JOIN (SELECT [HostName]
      ,CASE WHEN [InstanceName] = ''defailt'' THEN [HostName] ELSE [InstanceName] END AS [InstanceName]
      --,[StartUpFlags]
      ,[DAC]
      --,[net_transport]
      --,[protocol_type]
      ,CASE WHEN [auth_scheme] = ''KERBEROS'' THEN ''Yes'' ELSE '''' END [KERBEROS]
      --,[ActiveNode]
      --,[ListNodes]
      --,[client_net_address]
      --,[local_net_address]
      ,CASE 
			WHEN [local_tcp_port] >= 49152 AND [local_tcp_port] <= 65535 AND [InstanceName] <> ''defailt'' THEN ''''  --''Dynamic'' 
			WHEN  [local_tcp_port] < 49152 AND [local_tcp_port] <> 1433  THEN ''Static '' + CAST([local_tcp_port] AS VARCHAR(max))
			ELSE 
				CASE WHEN [InstanceName] = ''defailt'' AND [local_tcp_port] = 1433 THEN ''''
					ELSE ''Static '' + CAST([local_tcp_port] AS VARCHAR(max))
				END
       END AS [TCPport]
      --,[ServiceAccount]
      --,[ServiceAccountStatus]
      --,[ServiceAccountStartup]
      --,[AgentAccount]
      --,[AgentAccountStatus]
      --,[AgentAccountStartup]
       ,CASE WHEN [AuthentificationMode] = ''Windows Authentication'' THEN ''Only Windows'' ELSE '''' END AS [AuthentificationMode]
      --,[BackupCompression]
      --,[DOP]
      --,[OSmemoryGB]
      --,[MinRAM]
      --,[MaxRAM]
      --,[CPUs]
      --,[GrowthFile_Master]
      --,[GrowthFile_Msdb]
      --,[GrowthFile_Model]
      --,[NumberTempDB]
      --,[ListSharedDrives]
      --,[DataFileSizeMB]
      --,[MSDB_used]
      --,[MASTER_file_location]
      --,[MODEL_file_location]
      --,[MSDB_file_location]
      --,[InitialSizeTempDB]
      --,[GrowthFileTempDB]
      --,[SizeDataTempDB]
      --,[SizeLogTempDB]
      --,[TempDB_fileLocation]
      --,[TempDB_LogLocation]
      --,[DB_FileLocation]
      --,[DB_LogLocation]
      --,[DB_BackupLocation]
      --,[BIN_Location]
      ,CASE WHEN [MailServer] <> '''' THEN ''Enabled'' ELSE '''' END AS [MailServer]
      --,[ProductLevel]
      --,[ProductUpdateLevel]
      --,[ProductBuildType]
      --,[ProductUpdateReference]
      --,[ProductVersion]
      --,[ProductMajorVersion]
      --,[ProductMinorVersion]
      --,[ProductBuild]
      --,[ProductCollation]
      --,[Edition]
      --,[MaintenancePlansWith_no_SA]
      --,[JobsWith_no_SA]
      --,[ErrorLogLocation]
      --,[AgentErrorLogLocation]
      ,CASE WHEN [MultiServerJobs] <> '''' THEN ''Enabled'' ELSE '''' END AS [MultiServerJobs]
      --,[OsName]
      --,[NumberErrorLog_files]
      --,[MSDB_DatabaseMailUserRole]
      --,[Client]
      --,[timestamp]
	FROM [dbo].[Configuration]) AS CONF ON CONF.[HostName] = CO.[Host Name]  AND CONF.[InstanceName] = CO.[Instance Name]
LEFT JOIN (SELECT DISTINCT[InstanceName]  FROM [dbo].[DatabaseMasterKey]) AS DatabaseMasterKey ON DatabaseMasterKey.[InstanceName] = CO.INS
LEFT JOIN (SELECT DISTINCT [InstanceName]  FROM [dbo].[EcryptionCertificates]) AS [EcryptionCertificates] ON [EcryptionCertificates].[InstanceName] = CO.INS
LEFT JOIN (SELECT DISTINCT [InstanceName] FROM [dbo].[ExtendedEvents] WHERE [Name] NOT IN (''AlwaysOn_health'', ''system_health'')) AS [ExtendedEvents] ON [ExtendedEvents].[InstanceName] = CO.INS
LEFT JOIN (SELECT DISTINCT [Instance name] FROM [dbo].[isolation_level] WHERE [TRANSACTION_ISOLATION_LEVEL] LIKE ''%SNAPSHOT%'') AS [isolation_level] ON [isolation_level].[Instance name] = CO.INS

LEFT JOIN (SELECT DISTINCT [InstanceName]
      --,[DatabaseName]
      --,[desired_state_desc]
      --,[actual_state_desc]

  FROM [dbo].[QueryStore]) AS [QueryStore] ON [QueryStore].[InstanceName] = CO.INS

LEFT JOIN (SELECT DISTINCT [InstanceName], [Location] FROM [dbo].[SSIScatalogue]) AS [SSIScatalogue] ON [SSIScatalogue].[InstanceName] = CO.INS
LEFT JOIN (SELECT  [InstanceName] FROM [dbo].[StartupProcedures]) AS [StartupProcedures] ON [StartupProcedures].[InstanceName] = CO.INS

LEFT JOIN (SELECT DISTINCT [InstanceName]
      --,[database_name]
      --,[encryption_state]
      --,[encryption_state_desc]
      --,[create_date]
      --,[set_date]

  FROM [dbo].[TDEencryption]) AS [TDEencryption] ON [TDEencryption].[InstanceName] = CO.INS

LEFT JOIN (SELECT [InstanceName] FROM [dbo].[Traces] GROUP BY [InstanceName] HAVING COUNT(*)>1) AS [Traces] ON [Traces].[InstanceName] = CO.INS 

--ORDER BY 1,2
select ''0'' AS ''Issue #'', ''Host name'' AS ''Issue name'', * from(select [Instance Name], [Host Name] from #t) src
pivot
(
  MAX([Host Name]) 
--***REPLACE***
) piv
UNION ALL
select ''1'' AS ''Issue #'', ''Max memory'' AS ''Issue name'', * from(select [Instance Name], [MaxRAM status] from #t) src
pivot
(
  MAX([MaxRAM status]) 
--***REPLACE***
) piv
UNION ALL
select ''2'', ''Min memory'' , * from(select [Instance Name], [MinRAM status] from #t) src
pivot
(
  MAX([MinRAM status]) 
--***REPLACE***
) piv1
UNION ALL
select ''3'', ''Maintenance jobs missing'' , * from(select [Instance Name], ''?'' AS AAA from #t) src
pivot
(
  MAX(AAA) 
--***REPLACE***
) piv
UNION ALL
select ''4'', ''Databases default auto-growth setting'' , * from(select [Instance Name], [AutoGrow] from #t) src
pivot
(
  MAX([AutoGrow]) 
--***REPLACE***
) piv
UNION ALL
select ''5'', ''Perform Volume Maintenance Task or Lock Pages in Memory not configured'' , * from(select [Instance Name], [LockInMemory InstantFile] from #t) src
pivot
(
  MAX([LockInMemory InstantFile]) 
--***REPLACE***
) piv
UNION ALL
select ''6'', ''Accounts with high SQL Server role'' , * from(select [Instance Name], [High SQL Server role] from #t) src
pivot
(
  MAX([High SQL Server role]) 
--***REPLACE***
) piv
UNION ALL
select  ''7'', ''Page Verification not  set to CHECKSUM'', * from(select [Instance Name], [CHECKSUM] from #t) src
pivot
(
  MAX([CHECKSUM]) 
--***REPLACE***
) piv
UNION ALL
select  ''8'', ''SP Patching'', * from(select [Instance Name], [SP Patching] from #t) src
pivot
(
  MAX([SP Patching]) 
--***REPLACE***
) piv
UNION ALL
select  ''9'', ''TempDB not optimally configured'', * from(select [Instance Name], [TempDBcount status] from #t) src
pivot
(
  MAX([TempDBcount status]) 
--***REPLACE***
) piv
UNION ALL
select  ''10'', ''Review Local Administrator access'', * from(select [Instance Name], [Administrator access] from #t) src
pivot
(
  MAX([Administrator access]) 
--***REPLACE***
) piv
UNION ALL
select  ''11'', ''Databases with high VLFs'', * from(select [Instance Name], [VLF] from #t) src
pivot
(
  MAX([VLF]) 
--***REPLACE***
) piv
UNION ALL
select  ''12'', ''Job owner not set to sa'', * from(select [Instance Name], [Jobs no SA] from #t) src
pivot
(
  MAX([Jobs no SA])
--***REPLACE***
) piv
UNION ALL
select  ''13'', ''Database Collation differs from SQL instance collation'', * from(select [Instance Name], [Different Collation] from #t) src
pivot
(
  MAX([Different Collation])
--***REPLACE***
) piv
UNION ALL
select  ''14'', ''Transaction Log Backups not run in last 24 hours'', * from(select [Instance Name], [Tranlog Backup] from #t) src
pivot
(
  MAX([Tranlog Backup])
--***REPLACE***
) piv
UNION ALL
select  ''15'', ''Database backups have not been run recently'', * from(select [Instance Name], [Full Backup] from #t) src
pivot
(
  MAX([Full Backup])
--***REPLACE***
) piv
UNION ALL
select  ''16'', ''SQL Server Service Not Running'', * from(select [Instance Name], [SQL running]  from #t) src
pivot
(
  MAX([SQL running])
--***REPLACE***
) piv
UNION ALL
select  ''17'', ''Disk Drive Free Space less than 15%'', * from(select [Instance Name],  [Free15]  from #t) src
pivot
(
  MAX([Free15])
--***REPLACE***
) piv
UNION ALL
select  ''18'', ''Database backup compression hasn�t been enabled'', * from(select [Instance Name], [Backup compression]    from #t) src
pivot
(
  MAX([Backup compression])
--***REPLACE***
) piv
UNION ALL
select  ''19'', ''Separate backup drives'', * from(select [Instance Name], [Backup DriveLetter]   from #t) src
pivot
(
  MAX([Backup DriveLetter])
--***REPLACE***
) piv
UNION ALL
select  ''20'', ''Review AD and SQL Authenticated account with high database role'', * from(select [Instance Name],  [DBroleAdmin]   from #t) src
pivot
(
  MAX([DBroleAdmin])
--***REPLACE***
) piv
UNION ALL
select  ''21'', ''Change maintenance plan owner to sa.'', * from(select [Instance Name], [MP no SA]   from #t) src
pivot
(
  MAX([MP no SA])
--***REPLACE***
) piv
UNION ALL
select  ''22'', ''Review Max Degree of Parallelism.'', * from(select [Instance Name], [DOP]   from #t) src
pivot
(
  MAX([DOP])
--***REPLACE***
) piv
UNION ALL
select ''23'',''CU Patching'' AS ''Issue'', * from(select [Instance Name], [CU Patching] from #t) src
pivot
(
  MAX([CU Patching]) 
--***REPLACE***
) piv
UNION ALL
select  ''24'', ''SQL Server service isn�t running as an AD service account'', * from(select [Instance Name],  [AD service]     from #t) src
pivot
(
  MAX([AD service])
--***REPLACE***
) piv
UNION ALL
select  ''25'', ''Default Data files, Log files or Backups configured to C:\'', * from(select [Instance Name],  [Default Location]   from #t) src
pivot
(
  MAX([Default Location])
--***REPLACE***
) piv
UNION ALL
select  ''26'', ''Review orphaned database users with no SQL login.'', * from(select [Instance Name], [Orphan users]    from #t) src
pivot
(
  MAX([Orphan users])
--***REPLACE***
) piv
UNION ALL
select  ''27'', ''Change database compatibility level to version of SQL Server'', * from(select [Instance Name], [compatibility level]     from #t) src
pivot
(
  MAX([compatibility level])
--***REPLACE***
) piv
UNION ALL
select  ''28'', ''Idle databases may be candidates for removal'', * from(select [Instance Name], [Idle DBs]    from #t) src
pivot
(
  MAX([Idle DBs])
--***REPLACE***
) piv
UNION ALL
select  ''29'', ''Disk Free Space less than 40%'', * from(select [Instance Name], [Free40]    from #t) src
pivot
(
  MAX([Free40])
--***REPLACE***
) piv
UNION ALL
select  ''30'', ''SQL Instance System or User Databases on C:\'', * from(select [Instance Name],  [System letter]   from #t) src
pivot
(
  MAX([System letter])
--***REPLACE***
) piv
UNION ALL
select  ''31'', ''Log Fragmentation exists'', * from(select [Instance Name],  [VLFs1] from #t) src
pivot
(
  MAX(VLFs1)
--***REPLACE***
) piv
UNION ALL
select  ''32'', ''Databases Offline'', * from(select [Instance Name], [DB offline]      from #t) src
pivot
(
  MAX([DB offline])
--***REPLACE***
) piv
UNION ALL
select  ''33'', ''AutoClose/shrink'', * from(select [Instance Name], [AutoClose/shrink] from #t) src
pivot
(
  MAX([AutoClose/shrink])
--***REPLACE***
) piv
UNION ALL
select  ''34'', ''Update statistics'', * from(select [Instance Name], [Update Statistics] from #t) src
pivot
(
  MAX([Update Statistics])
--***REPLACE***
) piv
UNION ALL
select  ''35'', ''MSDB need attention'', * from(select [Instance Name], [MSDB] from #t) src
pivot
(
  MAX([MSDB])
--***REPLACE***
) piv
UNION ALL
select  ''36'', ''Integrity check'', * from(select [Instance Name], [Integrity Check] from #t) src
pivot
(
  MAX([Integrity Check])
--***REPLACE***
) pi
UNION ALL
select  ''37'', ''Index defragmentation'', * from(select [Instance Name], [Index defrag] from #t) src
pivot
(
  MAX([Index defrag])
--***REPLACE***
) pi
-- Added 13022024
UNION ALL
select  ''38'', ''Change tracking'', * from(select [Instance Name], [Change Tracking] from #t) src
pivot
(
  MAX([Change Tracking])
--***REPLACE***
) pi
UNION ALL
select  ''39'', ''Table or index compression'', * from(select [Instance Name], [Compression] from #t) src
pivot
(
  MAX([Compression])
--***REPLACE***
) pi
UNION ALL
select  ''40'', ''DAC'', * from(select [Instance Name], [DAC] from #t) src
pivot
(
  MAX([DAC])
--***REPLACE***
) pi
UNION ALL
select  ''41'', ''KERBEROS'', * from(select [Instance Name], [KERBEROS] from #t) src
pivot
(
  MAX([KERBEROS])
--***REPLACE***
) pi
UNION ALL
select  ''42'', ''TCP port'', * from(select [Instance Name], [TCPport] from #t) src
pivot
(
  MAX([TCPport])
--***REPLACE***
) pi
UNION ALL
select  ''43'', ''Authentification Mode'', * from(select [Instance Name], [AuthentificationMode] from #t) src
pivot
(
  MAX([AuthentificationMode])
--***REPLACE***
) pi
UNION ALL
select  ''44'', ''Mail Server'', * from(select [Instance Name], [MailServer] from #t) src
pivot
(
  MAX([MailServer])
--***REPLACE***
) pi
UNION ALL
select  ''45'', ''Multi Server Jobs'', * from(select [Instance Name], [MultiServerJobs] from #t) src
pivot
(
  MAX([MultiServerJobs])
--***REPLACE***
) pi
UNION ALL
select  ''46'', ''Database Master Key'', * from(select [Instance Name], [DatabaseMasterKey] from #t) src
pivot
(
  MAX([DatabaseMasterKey])
--***REPLACE***
) pi
UNION ALL
select  ''47'', ''Ecryption Certificates'', * from(select [Instance Name], [EcryptionCertificates] from #t) src
pivot
(
  MAX([EcryptionCertificates])
--***REPLACE***
) pi
UNION ALL
select  ''48'', ''Extended Events'', * from(select [Instance Name], [ExtendedEvents] from #t) src
pivot
(
  MAX([ExtendedEvents])
--***REPLACE***
) pi
UNION ALL
select  ''49'', ''Snapshot'', * from(select [Instance Name], [isolation_level] from #t) src
pivot
(
  MAX([isolation_level])
--***REPLACE***
) pi
UNION ALL
select  ''50'', ''QueryStore enabled'', * from(select [Instance Name], [QueryStore] from #t) src
pivot
(
  MAX([QueryStore])
--***REPLACE***
) pi
UNION ALL
select  ''51'', ''SSIS catalogue'', * from(select [Instance Name], [SSIScatalogue] from #t) src
pivot
(
  MAX([SSIScatalogue])
--***REPLACE***
) pi
UNION ALL
select  ''52'', ''Startup Procedures'', * from(select [Instance Name], [StartupProcedures] from #t) src
pivot
(
  MAX([StartupProcedures])
--***REPLACE***
) pi
UNION ALL
select  ''53'', ''TDE encryption'', * from(select [Instance Name], [TDEencryption] from #t) src
pivot
(
  MAX([TDEencryption])
--***REPLACE***
) pi
UNION ALL
select  ''54'', ''User Traces'', * from(select [Instance Name], [Traces] from #t) src
pivot
(
  MAX([Traces])
--***REPLACE***
) pi


DROP TABLE IF EXISTS #t 
END'

DECLARE @replacement VARCHAR(MAX) 

SELECT @replacement = COALESCE(@replacement+', ' ,'') + A.[Name]
FROM (SELECT DISTINCT REPLACE(REPLACE('['+ [Instance Name] + ']','[[','['),']]',']') AS [Name] FROM [dbo].[InstanceInformation]) AS A
--FROM (SELECT DISTINCT REPLACE(REPLACE('['+ REPLACE([Instance Name],'\',']\[') + ']','[[','['),']]',']') AS [Name] FROM [dbo].[InstanceInformation]) AS A
SET @replacement = 'for [Instance Name] in (' + @replacement + ')'

--SET @replacement = 'for [Instance Name] in ([a])'


SET @a = REPLACE(@a,'--***REPLACE***',@replacement)
--SELECT @replacement, @a

EXEC ('DROP PROC IF EXISTS USP_MATRIX_PIVOT;')
EXEC (@a)



--PRINT @a

exec USP_MATRIX_PIVOT




