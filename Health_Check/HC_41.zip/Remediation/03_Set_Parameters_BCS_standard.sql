
Use master
GO
/* 0 = Allow Local Connection, 1 = Allow Remote Connections*/ 
sp_configure 'remote admin connections', 1 
GO
RECONFIGURE
GO


USE [master]
GO 
ALTER DATABASE [master] MODIFY FILE ( NAME = N'master', FILEGROWTH = 16384KB )
GO
ALTER DATABASE [model] MODIFY FILE ( NAME = N'modeldev', FILEGROWTH = 262144KB )
GO
ALTER DATABASE [msdb] MODIFY FILE ( NAME = N'MSDBData', FILEGROWTH = 32768KB )
GO
EXEC sys.sp_configure N'backup compression default', N'1'
GO
RECONFIGURE WITH OVERRIDE
GO
USE [msdb]
GO
-- set job hisory unlimited
EXEC msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows=-1, @jobhistory_max_rows_per_job=-1
GO
USE [master]
GO
-- Set number of error logs to 40
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs', REG_DWORD, 40
GO


--------------  Create_Job_BCS SQL Server Errorlog Cycle  -------------------------

--USE [msdb]
--GO

--/****** Object:  Job [BCS SQL Server Errorlog Cycle]    Script Date: 5/12/2017 12:34:11 PM ******/
--BEGIN TRANSACTION
--DECLARE @ReturnCode INT
--SELECT @ReturnCode = 0
--/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 5/12/2017 12:34:11 PM ******/
--IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
--BEGIN
--EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

--END

--DECLARE @jobId BINARY(16)
--EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BCS SQL Server Errorlog Cycle', 
--		@enabled=1, 
--		@notify_level_eventlog=0, 
--		@notify_level_email=0, 
--		@notify_level_netsend=0, 
--		@notify_level_page=0, 
--		@delete_level=0, 
--		@description=N'BCS created job to cycle errorlog every day.', 
--		@category_name=N'[Uncategorized (Local)]', 
--		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--/****** Object:  Step [SQL Server Errorlog Cycle]    Script Date: 5/12/2017 12:34:11 PM ******/
--EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SQL Server Errorlog Cycle', 
--		@step_id=1, 
--		@cmdexec_success_code=0, 
--		@on_success_action=1, 
--		@on_success_step_id=0, 
--		@on_fail_action=2, 
--		@on_fail_step_id=0, 
--		@retry_attempts=5, 
--		@retry_interval=1, 
--		@os_run_priority=0, @subsystem=N'TSQL', 
--		@command=N'exec dbo.sp_cycle_errorlog', 
--		@database_name=N'master', 
--		@flags=0
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily at 0:00', 
--		@enabled=1, 
--		@freq_type=4, 
--		@freq_interval=1, 
--		@freq_subday_type=1, 
--		@freq_subday_interval=0, 
--		@freq_relative_interval=0, 
--		@freq_recurrence_factor=0, 
--		@active_start_date=20100823, 
--		@active_end_date=99991231, 
--		@active_start_time=0, 
--		@active_end_time=235959, 
--		@schedule_uid=N'ed840b27-b4ac-45e9-ad17-fbf9f133effd'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
--IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
--COMMIT TRANSACTION
--GOTO EndSave
--QuitWithRollback:
--    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
--EndSave:

--GO

-- MultiServer administration

declare @dirBIN nvarchar(4000)
declare @InstanceID nvarchar(4000)
DECLARE @value VARCHAR(20)
DECLARE @key VARCHAR(100)

exec master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE',N'Software\Microsoft\MSSQLServer\Setup',N'SQLBinRoot', @dirBIN output, 'no_output'
Select @InstanceID = SUBSTRING(@dirBIN,CHARINDEX('SQL Server\', @dirBIN)+11,CHARINDEX('\MSSQL\Binn', @dirBIN) -  CHARINDEX('SQL Server\', @dirBIN)-11) 

SET @key = 'SOFTWARE\Microsoft\Microsoft SQL Server\' + @InstanceID + '\SQLServerAgent'

EXEC master..xp_regread
   @rootkey = 'HKEY_LOCAL_MACHINE',
   @key = @key,
   @value_name = 'MsxEncryptChannelOptions',
   @value = @value OUTPUT

SELECT @InstanceID, CASE WHEN @value = 0x0 THEN 'MSX ready' ELSE '' END


EXEC xp_regwrite N'HKEY_LOCAL_MACHINE', @key, 'MsxEncryptChannelOptions', REG_DWORD, 0
GO