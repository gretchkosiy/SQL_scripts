-- Querying system views to see if the changes are applied
DECLARE @SQL VARCHAR(max), @sname VARCHAR(max)
SET @SQL=' USE [?]
SELECT 
	''[?]'' [Dbname]
	,[name] [Filename]
	,CASE is_percent_growth
			WHEN 1 THEN CONVERT(VARCHAR(MAX),growth)+''%''
			ELSE CONVERT(VARCHAR(MAX),(growth/128))+'' MB''
	END [Autogrow_Value]
	, CASE [type]
			WHEN 1 THEN ''LOG''
			ELSE ''DATA''
	END as [Filetype]
	,CASE max_size
			WHEN -1 THEN 
				CASE growth
					WHEN 0 THEN CONVERT(VARCHAR(MAX),''Restricted'')
					ELSE CONVERT(VARCHAR(MAX),''Unlimited'') 
				END
		ELSE CONVERT(VARCHAR(MAX),max_size/128)
	END [Max_Size]
	,''ALTER DATABASE [?] MODIFY FILE (NAME = [''+[name]+''],FILEGROWTH =64MB)'' [AlterQuery]
FROM [?].sys.database_files'
 
IF EXISTS(SELECT 1 FROM tempdb..sysobjects WHERE name='##Fdetails') DROP TABLE ##Fdetails

CREATE TABLE ##Fdetails(
	Dbname VARCHAR(max)
	,Filename VARCHAR(max)
	,Autogrow_Value VARCHAR(max)
	,FileType VARCHAR(max)
	,Max_Size VARCHAR(MAX)
	,AlterQuery VARCHAR(MAX) NULL
	)

INSERT INTO ##Fdetails
EXEC sp_msforeachdb @SQL

SELECT distinct * FROM ##Fdetails 
WHERE Dbname not in ('[master]','[msdb]','[tempdb]', '[model]')
--AND FileType = 'LOG'
and Autogrow_Value like '%[%]%'
ORDER BY Dbname

DROP TABLE ##Fdetails
GO