-- https://www.brentozar.com/archive/2014/06/performance-tuning-sql-server-change-tracking/

SELECT
	@@SERVERNAME AS InstanceName,
	db.name AS change_tracking_db,
	is_auto_cleanup_on,
	retention_period,
	retention_period_units_desc
FROM sys.change_tracking_databases ct
JOIN sys.databases db on
ct.database_id=db.database_id;

/*


CREATE TABLE ##ctTables
(
    TableName Varchar(100)
);
 
EXEC sp_MSforeachdb 'USE [?];
INSERT INTO ##ctTables
 SELECT ''[?].['' + s.name + ''].['' + t.name + '']'' AS Table_name
  FROM sys.change_tracking_tables tr
INNER JOIN sys.tables t on t.object_id = tr.object_id
INNER JOIN sys.schemas s on s.schema_id = t.schema_id
' ;
 
select * FROM ##ctTables;
drop table ##ctTables;


*/