SELECT @@SERVERNAME AS InstanceName, Name, pvt_key_encryption_type_desc, start_date, expiry_date,pvt_key_last_backup_date 
FROM master.sys.certificates 
where pvt_key_encryption_type != 'NA'

-- ??? 2019 _##PDW_SmDetachSigningCertificate## and _##PDW_PolyBaseAuthorizeSigningCertificate## 