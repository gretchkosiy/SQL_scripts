SELECT 
	@@SERVERNAME as InstanceName
	,name
	
FROM sys.server_event_sessions