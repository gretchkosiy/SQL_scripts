DECLARE @v varchar(10)
SELECT @v = LEFT(CAST(SERVERPROPERTY('productversion') AS VARCHAR(MAX)) COLLATE DATABASE_DEFAULT, 2)
DECLARE @SQLtxt varchar(512)

IF @v = '9.'
BEGIN
       -- 2005
       SET @SQLtxt = '
			--INSERT INTO ##MP_owners
			select CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY(''MachineName'')
				ELSE @@SERVERNAME
			END  AS [Instance Name], SERVERPROPERTY(''MachineName'') AS [Host Name], S.name AS [Name], l.name  AS [Owner]
			from [msdb].[dbo].sysdtspackages90 S
			left join master.sys.syslogins l on S.ownersid = l.sid'
END
ELSE
BEGIN
       -- 2008 OR LATER
       SET @SQLtxt = '
			--INSERT INTO ##MP_owners
			select CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY(''MachineName'')
				ELSE @@SERVERNAME
			END  AS [Instance Name], SERVERPROPERTY(''MachineName'') AS [Host Name], S.name AS [Name], l.name  AS [Owner]
			--INTO MaintenencePlans
			from [msdb].[dbo].[sysssispackages] S
			left join master.sys.syslogins l on S.ownersid = l.sid'
END

EXEC(@SQLtxt)