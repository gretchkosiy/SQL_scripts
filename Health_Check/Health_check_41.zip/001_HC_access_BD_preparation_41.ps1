cls


$Login = "AD\LoginName"
$password = ConvertTo-SecureString "Password" -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential ($Login, $password)

$Cred = $null # run under current credentials

# Updates 34
# 04/04/2024 - joined with BD-preparation
# 11/07/2023 - Added "Windows Internal Database" into the reports, moved host check in the only one loop 
# 10/07/2023 - Added -and $_.Caption -ne "Windows Internal Database" 
# related to https://www.sqlshack.com/managing-the-windows-internal-database-wid/#:~:text=It%20is%20used%20to%20store,Windows%20system%20resource%20manager


<#

Usefull commad lines

- 01 list of accounts in AD group
net group AD_group_name /domain

- 02 All AD permissiosn for current login 
gpresult /V


===========
$password = ConvertTo-SecureString "vWDf2zb6=4SRK%r55*UzefYZN/JQT3" -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential ("ADL-APT\svc_bluecrystal", $password)

        $HostName = 'APISV216'
        $A = @()
        $B = @()
		$admins = Gwmi win32_groupuser  �computer $HostName  -Credential $Cred 
		$admins = $admins |? {$_.groupcomponent �like '*"Administrators"'}  
 		$admins |% {  
			$_.partcomponent �match �.+Domain\=(.+)\,Name\=(.+)$� > $nul  
           $A +=   $matches[1].trim('"') + �\� + $matches[2].trim('"') 
           $B += 'net group ''' + $matches[2].trim('"')  + ''' /domain'  
			#$OSTable.Rows.Add(19, $HostName, $Server, 'Local admin', $matches[1].trim('"') + �\� + $matches[2].trim('"'), $Client, $RunTime) | Out-Null
		} 
        
        $A  
        $B
===========

#>


# https://learn.microsoft.com/en-us/sql/relational-databases/security/sql-server-security-best-practices?view=sql-server-ver16

# https://learn.microsoft.com/en-us/sql/relational-databases/security/choose-an-authentication-mode?view=sql-server-ver16
# When possible, use Windows authentication.

# This script will identify and collect list of instances installed on hosts and local admin permissions for host ans sysadmin for instances

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
    { Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"; Break }

$SMO = [reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo").ImageRuntimeVersion
if ($SMO -eq $null )
 { Write-Warning "SMO library is not installed on local host"; Break } 
else 
 { if ($SMO.Substring(1,1) -lt 2) { Write-Warning "SMO version less 2 is not supported"; Break } }


# Path where report will be stored. The file names are "-hosts.txt" and "-permissions.csv"
$Path = split-path -parent $MyInvocation.MyCommand.Definition 
if ((Test-Path -Path $Path ) -ne $true) { Write-Warning "The folder '$Path' doesn't exists!"; Break }
if ((Test-Path $Path\hosts.txt) -ne $true) { Write-Warning "The file 'hosts.txt' doesn't exists in the folder $Path!"; Break } 
$Path = $Path + "\"

$Hosts = @()

try { $Hosts = Get-Content $Path\hosts.txt 
    } catch { Write-Warning "$Path\hosts.txt is not readable"; Break }

#$Hosts = Get-Content $Path\hosts.txt   


                                      # list of hosts for checking
if (Test-Path $Path\instances.txt) { Remove-Item $Path\instances.txt }       # created list of discovered instances for the hosts
if (Test-Path $Path-clusternodes.txt) { Remove-Item $Path-clusternodes.txt } # created list of discovered cluster nodes (if any discovered) 
#if (Test-Path $Path\-permissions.csv) { Remove-Item $Path\-permissions.csv } # created windows local admin and SQL Server sysadmin checks (should be moved to -instances.csv from BD_preparation) 

# for BD preparation
if (Test-Path $Path\-instances.csv)    { Remove-Item $Path\-BD_helper.csv }  # REDANDANT - will go to -permissions.csv
#if (Test-Path $Path\-services.csv)     { Remove-Item $Path\-services.csv }   # created list of discovered services
if (Test-Path $Path\-IPs.csv)          { Remove-Item $Path\-IPs.csv }        # created list of IP interfaces available on host(?)

# DUPLICATES if (Test-Path $Path\-clusternodes.csv) { Remove-Item $Path\-clusternodes.csv }

$InstancesArray = @()

#Instances
$InstancesTable = New-Object System.Data.DataTable
$InstancesTable.Columns.Add("Host",     "System.String")    | Out-Null   
$InstancesTable.Columns.Add("Instance", "System.String")    | Out-Null 
$InstancesTable.Columns.Add("Named",    "System.String")    | Out-Null 
$InstancesTable.Columns.Add("VsName",   "System.String")    | Out-Null 
$InstancesTable.Columns.Add("PortFixed","System.String")    | Out-Null 
$InstancesTable.Columns.Add("InstReg",  "System.String")    | Out-Null 
$InstancesTable.Columns.Add("OS",       "System.String")    | Out-Null 
$InstancesTable.Columns.Add("OSAdmin",  "System.String")    | Out-Null 


# Main BD Report - $Path\-instances.csv 
$TableBD = New-Object System.Data.DataTable
$TableBD.Columns.Add("Type",      "System.String")   | Out-Null
$TableBD.Columns.Add("Name",      "System.String")   | Out-Null
$TableBD.Columns.Add("ActiveNode","System.String")   | Out-Null
$TableBD.Columns.Add("ListNodes", "System.String")   | Out-Null  # ? AAG
$TableBD.Columns.Add("SQL sysadmin","System.String") | Out-Null  # sysadmin for SQL
$TableBD.Columns.Add("LocalAdmin"   ,"System.String")| Out-Null  # OS local admin
$TableBD.Columns.Add("ErrorLogAcces","System.String")| Out-Null  # permissions for ERRORLOG file
$TableBD.Columns.Add("Account",   "System.String")   | Out-Null
$TableBD.Columns.Add("SQL Version","System.String")  | Out-Null
$TableBD.Columns.Add("SP",        "System.String")   | Out-Null
$TableBD.Columns.Add("CU",        "System.String")   | Out-Null
$TableBD.Columns.Add("KB",        "System.String")   | Out-Null
$TableBD.Columns.Add("Edition",   "System.String")   | Out-Null
$TableBD.Columns.Add("IP",        "System.String")   | Out-Null
$TableBD.Columns.Add("Port",      "System.String")   | Out-Null
$TableBD.Columns.Add("PortFixed", "System.String")   | Out-Null
$TableBD.Columns.Add("ErrorLog",  "System.String")   | Out-Null
$TableBD.Columns.Add("Clustered", "System.String")   | Out-Null
$TableBD.Columns.Add("AAG (any)", "System.String")   | Out-Null
$TableBD.Columns.Add("LogShipping","System.String")  | Out-Null
$TableBD.Columns.Add("SSAS",      "System.String")   | Out-Null
$TableBD.Columns.Add("SSRS",      "System.String")   | Out-Null
$TableBD.Columns.Add("SSIS",      "System.String")   | Out-Null
$TableBD.Columns.Add("FulTextSerach","System.String")| Out-Null
$TableBD.Columns.Add("LastRestart"  ,"System.String")| Out-Null

$TableBD.Columns.Add("OSversion"    ,"System.String")| Out-Null

#Services
#$serviceTable = New-Object System.Data.DataTable
#$serviceTable.Columns.Add("Host Name",     "System.String")    | Out-Null   
#$serviceTable.Columns.Add("Service Name",  "System.String")    | Out-Null  
#$serviceTable.Columns.Add("Display Name",  "System.String")    | Out-Null  
#$serviceTable.Columns.Add("Startup",       "System.String")    | Out-Null 
#$serviceTable.Columns.Add("Status",        "System.String")    | Out-Null

#IPs
$IPTable = New-Object System.Data.DataTable
$IPTable.Columns.Add("InstanceName", "System.String")    | Out-Null 
$IPTable.Columns.Add("IPname",       "System.String")    | Out-Null    
$IPTable.Columns.Add("Active",       "System.String")    | Out-Null  
$IPTable.Columns.Add("Enabled",      "System.String")    | Out-Null  
$IPTable.Columns.Add("IPaddress",    "System.String")    | Out-Null  
$IPTable.Columns.Add("Dynamic",      "System.String")    | Out-Null  
$IPTable.Columns.Add("port",         "System.String")    | Out-Null  
$IPTable.Columns.Add("DisplayName",  "System.String")    | Out-Null  

$QueryTXTBD = "
Declare @aag VARCHAR(50)
Set @aag = 'No'
Declare @logShipping VARCHAR(50)
Set @logShipping = 'No'


IF (SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)),1,CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)))-1) > 10)
	IF EXISTS( select distinct 1
				from sys.dm_hadr_availability_replica_states ars
				inner join sys.availability_groups ag on ag.group_id = ars.group_id 
				where ars.role_desc = 'PRIMARY'  
                ) Set @aag = 'PRIMARY'
        ELSE Set @aag = 'SECONDARY'

IF EXISTS(	SELECT 1
			FROM msdb.dbo.log_shipping_primary_databases pd
			JOIN msdb.dbo.log_shipping_primary_secondaries ps ON pd.primary_id = ps.primary_id
			JOIN msdb.dbo.log_shipping_monitor_primary mp ON mp.primary_id = pd.primary_id)
  OR EXISTS(SELECT 1
			FROM msdb.dbo.log_shipping_secondary_databases sd
			JOIN msdb.dbo.log_shipping_secondary s ON sd.secondary_id = s.secondary_id
			JOIN msdb.dbo.log_shipping_monitor_secondary ms ON ms.secondary_id = sd.secondary_id)
	Set @logShipping = 'Yes'			

Declare @a varchar(max)
SET @a = ''
SELECT @a = @a + NodeName + ','   FROM sys.dm_os_cluster_nodes

Declare @startTime varchar(max)
SELECT @startTime = create_date FROM sys.databases WHERE name = 'tempdb'
				
SELECT 
  'SQL instance' AS [Type]
, CAST(@@SERVERNAME AS VARCHAR(20)) AS [Name]
, CAST(CASE WHEN IS_SRVROLEMEMBER('sysadmin') = 1 THEN 'True' else 'False' end AS VARCHAR(50)) as [Admin]
, suser_name() AS [Account], Cast(SERVERPROPERTY('Edition') as varchar(max))  + ' ('+ Cast(SERVERPROPERTY('ProductVersion') as varchar(50)) +')' AS [Edition]

, ISNULL(CONNECTIONPROPERTY('local_net_address'),'please run remotely') AS [IP]
, REPLACE(CAST(SERVERPROPERTY('ErrorLogFileName') AS VARCHAR(500)),':','$') as [ErrorLog]
, CASE WHEN SERVERPROPERTY('IsClustered') = 0 THEN 'No' ELSE 'Yes' END AS [Clustered]
, @aag AS [AAG]
, @logShipping AS [LogShipping]
, CONNECTIONPROPERTY('local_tcp_port') AS [local_tcp_port]
--, CAST(CONNECTIONPROPERTY('local_net_address') AS [local_net_address]
,SERVERPROPERTY('ProductLevel') AS SP
,SERVERPROPERTY('ProductUpdateLevel') AS CU
,SERVERPROPERTY('ProductUpdateReference') AS KB
,CASE 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,1) = '8' THEN 'SQL 2000' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,1) = '9' THEN 'SQL 2005' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = '10' THEN 
		CASE WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,4) = '10.0' THEN 'SQL 2008'
		ELSE 'SQL 2008 R2' END
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 11 THEN 'SQL 2012' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 12 THEN 'SQL 2014' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 13 THEN 'SQL 2016' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 14 THEN 'SQL 2017' 
	WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 15 THEN 'SQL 2019' 
    WHEN SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') as varchar(50)),1,2) = 16 THEN 'SQL 2022' 
END AS SQLversion
,SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS ActiveNode
,CASE 
                WHEN @a is NULL OR LTRIM(RTRIM(@a)) = '' THEN ''
                ELSE SUBSTRING(@a,1,len(@a)-1) 
	END AS ListNodes
, @startTime AS [LastRestart]
"
$RunTime = Get-Date  
$RunningHost = [System.Net.Dns]::GetHostName()
Write-Host "Hosts and SQL Server access check and BD helper script running from $RunningHost" -ForegroundColor Green
if ($Cred -eq $null) { Write-Host "Using credentials $Env:UserDomain\$Env:UserName" -ForegroundColor Green } else { Write-Host "Using credentials $Login" -ForegroundColor Green }
Write-Host "Reports location: $Path" -fore Green
#Write-Host "$RunTime - Getting list of instances on each host" -ForegroundColor Green

foreach ($HostName in $Hosts)
{  if (($HostName -eq '') -or ($HostName.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string 

   try { if ($HostName -ne $env:COMPUTERNAME) { (Test-Connection -ComputerName $HostName -Quiet) | Out-Null } } catch { Write-Warning "$HostName host is not accesable"; MoveNext }
#$HostName
   try {   
        $ClusterNodes = Get-ClusterNode -Cluster $HostName -ErrorAction SilentlyContinue  -WarningAction silentlyContinue | SELECT Cluster, State, Id, Name, NodeName
        # fill up cluster nodes - if cluster exists
        $ClusterNodes | Export-Csv -Path $Path\-clusternodes.csv -append -NoTypeInformation 

#$ClusterNodes

        # but installed instances on all cluster nodes! (from hosts.txt file)
        $arrINST = Get-Clusterresource -Cluster $HostName -ErrorAction SilentlyContinue  -WarningAction silentlyContinue `
        | Where-Object {$_.resourcetype -like 'sql server'} `
        | Get-Clusterparameter "instancename" `
        | Sort-Object objectname `
        | Select-Object -expandproperty value
 
        $arrVSN = Get-Clusterresource -Cluster $HostName -ErrorAction SilentlyContinue  -WarningAction silentlyContinue `
        | Where-Object {$_.resourcetype -like 'sql server'} `
        | Get-Clusterparameter "virtualservername" `
        | Sort-Object objectname `
        | Select-Object -expandproperty value

        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $HostName)

        $regKey= $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL" )
        $values = $regkey.GetValueNames()

        foreach ($i in 0..($arrINST.count-1)) 
            {
                $Instance = $arrVSN[$i] + "\" + $arrINST[$i]
                $InstMatch = $values | where { $_ -eq $arrINST[$i] }

                # check - if instance is alive for this node
                if ($InstMatch -ne $null)
                {
                    $Inst = $regkey.GetValue($InstMatch)
                    #$h = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $Inst +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\IPAll" #+ $f[1].PSChildName
                    #$TcpPort = $reg.OpenSubKey($h).GetValue("TcpPort")
                    $TcpPort = $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $Inst +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\IPAll").GetValue("TcpPort")
                    if ($TcpPort -ne "" ) {  $PortFixed = $TcpPort   } else { $PortFixed = "" }
                    $InstancesTable.Rows.Add($HostName, $Instance, $arrINST[$i], $arrVSN[$i] , $PortFixed , $Inst) | out-null 
                } else { $InstancesTable.Rows.Add($HostName, $Instance, $arrINST[$i], $arrVSN[$i] , "Not live on this node" ) | out-null }
            }
        Write-Host  "Host processing: $HostName - clustered" -fore Gray

    } catch 
    {
       # this part will be for non-clusterd hosts

        Write-Host  "Host processing: $HostName" -fore Gray

        $AdminAccess = "Not identified yet" 
        try { 
           #$hardware = gwmi Win32_bios -computername $HostName | Out-Null; 
           $os = gwmi  Win32_OperatingSystem -computername $HostName 
           $AdminAccess = "True" 
        } catch { $AdminAccess = "False" }

        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $HostName)

        $regKey= $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL" )
        $values = $regkey.GetValueNames()

        $values | ForEach-Object {
             
             $h = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $regKey.GetValue($_) +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\IPAll" #+ $f[1].PSChildName
             $o = $reg.OpenSubKey($h).GetValue("TcpPort")

             if ($o -ne "" ) {  $PortFixed = $o   } else { $PortFixed = "" }

             if($_ -eq "MSSQLSERVER") {$Instance = "$HostName"; $Named = "$HostName"} else {$Instance = "$HostName\$_" ; $Named = "$_"}
             #$HostTable.Rows.Add($HostName, $Instance, $version) | Out-Null 
             $InstancesTable.Rows.Add($HostName, $Instance, $Named ,$HostName, $PortFixed, $regKey.GetValue($_) , $os.Caption + " (" + $os.Version + ")", $AdminAccess) | out-null

            }
    }
}

<#

        If (!(Test-Connection -ComputerName $HostName -Count 1 -Quiet )) { 
              Write-Warning "$HostName no ping on network."
              # Move to next computer 
              Continue }

        Write-Host "$HostName `t`t- checking host access and getting list of SQL instances"

# replacement from last loop 
#    Write-Host "$HostName - checking server access"
    try { if ($HostName -ne $env:COMPUTERNAME) { (Test-Connection -ComputerName $HostName -Quiet) | Out-Null  }
        } catch { Write-Warning "$HostName host is not accesible"; MoveNext }

    try { gwmi Win32_bios -computername $HostName | Out-Null
        try { if ($HostName -ne $env:COMPUTERNAME) { Invoke-Command -ComputerName $HostName -ScriptBlock { $Host } | Out-Null }
            $res = "" 
            try { 
                $hardware = gwmi Win32_bios -computername $HostName | Out-Null; 
                $os = gwmi  Win32_OperatingSystem -computername $HostName 
                $res = "Ok" 
            } catch { $res = "!!! NOT ok" }
            
            #$TableBD.Rows.Add("Host", $HostName, $res, [System.Security.Principal.WindowsIdentity]::GetCurrent().Name, $os.Caption + " (" + $os.Version + ")") | Out-Null

        } catch { Write-Warning "WinRM is not enabled on $HostName" }
    } catch { 
        #Write-Warning "WMI is not accesible on $HostName" 
        }
    try {
          [array]$captions = gwmi win32_service -computerName $HostName | ?{$_.Name -match "mssqls*" -and $_.Caption -ne "Windows Internal Database"  -and $_.PathName -match "sqlservr.exe"} | %{$_.Caption}
          foreach ($caption in $captions) {
            $temp = $caption | %{$_.split(" ")[-1]} | %{$_.trimStart("(")} | %{$_.trimEnd(")")}
            if ($temp -eq "MSSQLSERVER") {
              $InstancesArray =  $InstancesArray + "$HostName"
            } else {
              $InstancesArray =  $InstancesArray + "$HostName\$temp"
            }
          }

          [array]$captions = gwmi win32_service -computerName $HostName | ?{$_.Caption -eq "Windows Internal Database"} | %{$_.Caption}
          if ($captions.Count -ne 0) { 
                Write-Host "Windows Internal Database is installed on $HostName" -ForegroundColor Cyan
                $TableBD.Rows.Add("Windows Internal Database", $HostName, "Windows Internal Database is installed on $HostName", "","") | Out-Null
          }
    } Catch { Write-Warning "$HostName - WMI is not accesible"; #$Hosts.SetValue($HostName) = "WMI error on $HostName" 
            }
    }

#>

#Write-Host "$RunTime `t`t`t- Checking SQL instances access" -ForegroundColor Green

[reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | out-null

foreach($Instance in $InstancesTable)
    {  
    
    $Server = $Instance.Instance
    $Server | Out-File -append $Path\instances.txt 
    
    try {
 
                $m = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\" + $Instance.InstReg + "\\MSSQLServer\\SuperSocketNetLib\\Tcp\\"  
                $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $Instance.Host)
                $regKey= $reg.OpenSubKey($m)
                $f = $regkey.GetSubKeyNames()

                 foreach ($d in $f){
                    $n = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $Instance.InstReg +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\" + $d
                    $IPTable.Rows.Add($Instance.Instance, $d,  $reg.OpenSubKey($n).GetValue("Active"),  $reg.OpenSubKey($n).GetValue("Enabled") ,  $reg.OpenSubKey($n).GetValue("IpAddress") ,  $reg.OpenSubKey($n).GetValue("TcpDynamicPorts") ,  $reg.OpenSubKey($n).GetValue("TcpPort"),  $reg.OpenSubKey($n).GetValue("DisplayName")) | Out-Null 
                }

        } catch {  $e = "No IP entries in registry for " + $Instance.Instance + " on host " + $Instance.Host +". Try to run the script against another cluster node"; Write-Host $e -fore red; }

    try {

    Write-Host "Instance processing: $Server" -fore DarkYellow

    $strConn = "server='tcp:$Server';Integrated Security=SSPI;Initial Catalog='master';Connection Timeout=30;"
#    Write-Host $strConn -fore blue


#        $Connection = New-Object System.Data.SQLClient.SQLConnection("server='tcp:$Server';Integrated Security=SSPI;Initial Catalog='master';Connection Timeout=30;");
#        $Connection = New-Object System.Data.SQLClient.SQLConnection("Data Source=(local);Integrated Security=SSPI;Initial Catalog=master;Connection Timeout=30;");

        $Connection = New-Object System.Data.SQLClient.SQLConnection($strConn)
        $Connection.Open() 
        $Command = New-Object System.Data.SQLClient.SQLCommand
        $Command.Connection = $Connection
        $Command.CommandTimeout = 30
        $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $Command
        $dataset = New-Object System.Data.DataSet

        $Command.CommandText = $QueryTXTBD
        $adapter.SelectCommand = $Command
        $dataset.Reset()
        $adapter.Fill($dataset) | out-null  

        
        $SSAS = Get-WmiObject Win32_Service -ComputerName $Instance.Host | Where-Object -Property DisplayName -EQ "SQL Server Analysis Services ($($Instance.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
        $SSRS = Get-WmiObject Win32_Service -ComputerName $instance.Host | Where-Object -Property DisplayName -EQ "SQL Server Reporting Services ($($instance.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
        $FTS  = Get-WmiObject Win32_Service -ComputerName $instance.Host | Where-Object -Property DisplayName -EQ "SQL Full-text Filter Daemon Launcher ($($instance.Named))" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, StartName, State, StartMode       
        IF ($SSAS -eq $null) { $AS = "No" } else { $AS = "Yes" }
        IF ($SSRS -eq $null) { $RS = "No" } else { $RS = "Yes" }
        IF ($FTS -eq $null)  { $FS = "No" } else { $FS = "Yes" }

        $SSISinstances = Get-WmiObject Win32_Service -ComputerName $instance.Host | Where-Object -Property DisplayName -Like "SQL Server Integration Services*" | Where-Object -Property DisplayName -NotLike "*CEIP*" | Select-Object DisplayName, PathName, StartName, State, StartMode       
        $IS = "No"                 

        try {       
            foreach($SSIS in $SSISinstances)       
            {          
                $ConfigXMLPath = ($SSIS.PathName.Substring(0,$SSIS.PathName.IndexOf('MsDtsSrvr.exe')) + 'MsDtsSrvr.ini.xml') -replace '"', ''       
                $ConfigXMLPath = "\\$($instance.Host)\" + $SSIS.PathName.Substring(1,1) + '$\' + $ConfigXMLPath.Substring(3)       
                [xml]$ConfigXML = Get-Content -Path $ConfigXMLPath              

                if ($ConfigXML.DtsServiceConfiguration.TopLevelFolders.Folder.ServerName -like "*$($instance.Named)*")       
                    { IF ($SSIS -eq $null) { $IS = "No" } else { $IS = "Yes" } }       
                elseif (($ConfigXML.DtsServiceConfiguration.TopLevelFolders.Folder.ServerName -EQ ".") -and ($instance.Named -eq 'MSSQLSERVER'))       
                    { IF ($SSIS -eq $null) { $IS = "No" } else { $IS = "Yes" } }       
            }       
        } catch { $IS = "No" }      


        foreach($recs in $dataset.Tables[0]) { 
            
        $A = $Instance.VsName
        $B = $recs.ErrorLog
        $C = "\\$A\$B"

        # Checking access to ERRORLOG
        if ($Cred -eq $null) { 
            try {
                $Login = $Env:UserDomain + '\' + $Env:UserName
                $PathOk = Test-Path -Path $C  -ErrorAction SilentlyContinue
            } catch {$PathOk = $false}      
         } else {
            try {
                $PathOk = Invoke-Command -ComputerName $HostName -Credential $Cred -Scriptblock {param($p1) Test-Path -Path $p1 } -ArgumentList $C -ErrorAction SilentlyContinue
            } catch {$PathOk = $false}
         }

        IF ($Instance.PortFixed -eq "") { $port = $recs.local_tcp_port } else { $port = "" } 
        $TableBD.Rows.Add("SQL instance", $Server, $recs.ActiveNode, $recs.ListNodes, $recs.Admin, $Instance.OSAdmin, $PathOk, $recs.Account, $recs.SQLversion, $recs.SP, $recs.CU, $recs.KB, $recs.Edition, $recs.IP, $port, $Instance.PortFixed , $C, $recs.Clustered, $recs.AAG, $recs.LogShipping, $AS, $RS, $IS, $FS, $recs.LastRestart, $Instance.Os ) | Out-Null }

        $Connection.Close()
        $Connection.Dispose()
        } catch { #$TableBD.Rows.Add("SQL instance", $Server, "!!! NOT ok - connection", [System.Security.Principal.WindowsIdentity]::GetCurrent().Name , "No", "No", "No", "No", "No", "No") | out-null 
            Write-Host "Sql connection error - $Server" -fore red
        }
    }

$TableBD      | Export-Csv -Path $Path\-BD_helper.csv -NoTypeInformation 
#$serviceTable | Export-Csv -Path $Path\-services.csv -NoTypeInformation 
$IPTable      | Export-Csv -Path $Path\-IPs.csv -NoTypeInformation 

$RunTime = Get-Date  
Write-Host "$RunTime - End testing connections"  -ForegroundColor Green

#">>> Done <<<" !!!