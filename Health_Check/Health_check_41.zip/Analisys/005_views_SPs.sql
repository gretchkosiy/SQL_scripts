/****** Object:  UserDefinedFunction [dbo].[SpaceBeforeCap]    Script Date: 2/08/2023 4:34:23 PM ******/
DROP FUNCTION [dbo].[SpaceBeforeCap]
GO
DROP FUNCTION [dbo].[ConvertScheduleToStraing]
GO
DROP VIEW [dbo].[vw_VirtualLogFile]
GO
DROP VIEW [dbo].[vw_UpdateStatistics]
GO
DROP VIEW [dbo].[vw_Services]
GO
DROP VIEW [dbo].[vw_ServerRoles]
GO
DROP VIEW [dbo].[vw_OrphanUsers]
GO
DROP VIEW [dbo].[vw_OperatingSystem]
GO
DROP VIEW [dbo].[vw_MaintenancePlans]
GO
DROP VIEW [dbo].[vw_Jobs]
GO
DROP VIEW [dbo].[vw_IntegrityCheck]
GO
DROP VIEW [dbo].[vw_InstanceDetails]
GO
DROP VIEW [dbo].[vw_IndexFragmentation]
GO
DROP VIEW [dbo].[vw_IdleDatabases]
GO
DROP VIEW [dbo].[vw_Hardware]
GO
DROP VIEW [dbo].[vw_GetListServers]
GO
DROP VIEW [dbo].[vw_GetListDates]
GO
DROP VIEW [dbo].[vw_GetListClients]
GO
DROP VIEW [dbo].[vw_Drives]
GO
DROP VIEW [dbo].[vw_DatabasesRoles]
GO
DROP VIEW [dbo].[vw_DatabaseOptions]
GO
DROP VIEW [dbo].[vw_DatabaseDetails]
GO
DROP VIEW [dbo].[vw_DatabaseBackups]
GO
DROP PROCEDURE [dbo].[SP_ServiceTable]
GO
DROP PROCEDURE [dbo].[SP_OS]
GO
DROP PROCEDURE [dbo].[SP_InstanceInfo]
GO
DROP PROCEDURE [dbo].[SP_Hardware]
GO
DROP PROCEDURE [dbo].[SP_GetWordData]
GO
DROP PROCEDURE [dbo].[SP_GetVLF_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetVLF]
GO
DROP PROCEDURE [dbo].[SP_GetUpdateStatistics_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetUpdateStatistics]
GO
DROP PROCEDURE [dbo].[SP_GetServices_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetServices]
GO
DROP PROCEDURE [dbo].[SP_GetServerRoles_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetServerRoles]
GO
DROP PROCEDURE [dbo].[SP_GetOS_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetOS]
GO
DROP PROCEDURE [dbo].[SP_GetOrphanUsers_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetOrphanUsers]
GO
DROP PROCEDURE [dbo].[SP_GetMaintenancePlans_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetMaintenancePlans]
GO
DROP PROCEDURE [dbo].[SP_GetLoadsDates]
GO
DROP PROCEDURE [dbo].[SP_GetListServers]
GO
DROP PROCEDURE [dbo].[SP_GetListClients]
GO
DROP PROCEDURE [dbo].[SP_GetJobs_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetJobs]
GO
DROP PROCEDURE [dbo].[SP_GetIntegrityCheck_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetIntegrityCheck]
GO
DROP PROCEDURE [dbo].[SP_GetInstanceDetails_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetInstanceDetails]
GO
DROP PROCEDURE [dbo].[SP_GetIndexFragmentation_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetIndexFragmentation]
GO
DROP PROCEDURE [dbo].[SP_GetIdleDatabases_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetIdleDatabases]
GO
DROP PROCEDURE [dbo].[SP_GetHardware_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetHardware]
GO
DROP PROCEDURE [dbo].[SP_GetDiskSpace_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetDiskSpace]
GO
DROP PROCEDURE [dbo].[SP_GetDatabasesRoles_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetDatabasesRoles]
GO
DROP PROCEDURE [dbo].[SP_GetDatabaseOptions_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetDatabaseOptions]
GO
DROP PROCEDURE [dbo].[SP_GetDatabaseDetails_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetDatabaseDetails]
GO
DROP PROCEDURE [dbo].[SP_GetDatabaseBackups_COLOR]
GO
DROP PROCEDURE [dbo].[SP_GetDatabaseBackups]
GO
DROP PROCEDURE [dbo].[SP_DiskSpace]
GO
DROP PROCEDURE [dbo].[SP_DeleteAll]
GO
DROP TYPE [dbo].[ServiceTable]
GO
DROP TYPE [dbo].[InstanceInfo]
GO
DROP TYPE [dbo].[DisksTable]
GO


/****** Object:  UserDefinedFunction [dbo].[ConvertScheduleToStraing]    Script Date: 2/08/2023 4:34:23 PM ******/
CREATE FUNCTION [dbo].[ConvertScheduleToStraing](
	
	@enabled as tinyint, 
	@job_id as uniqueidentifier , 
	@freq_type as int,
	@freq_recurrence_factor as int ,

	@active_start_date as int ,
	@freq_interval as int ,
	@freq_relative_interval as int ,
	@freq_subday_type as int ,
	@active_start_time as int ,
	@active_end_time as int ,
	@freq_subday_interval as int 
	) RETURNS  varchar(2000)
AS
BEGIN
 --dim @a as varchar(2000)

RETURN
 CASE
       WHEN @enabled = 0 THEN 'Disabled'
       WHEN @job_id IS NULL THEN 'Unscheduled'
       WHEN @freq_type = 0x1 
           THEN
               'Once on '
             + CONVERT(
                          CHAR(10)
                        , CAST( CAST( @active_start_date AS VARCHAR ) AS DATETIME )
                        , 102 
                       )
       WHEN @freq_type = 0x4 
           THEN 'Daily'
       WHEN @freq_type = 0x8 
           THEN
               CASE
                   WHEN @freq_recurrence_factor = 1
                       THEN 'Weekly on '
                   WHEN @freq_recurrence_factor > 1
                       THEN 'Every '
                          + CAST( @freq_recurrence_factor AS VARCHAR )
                          + ' weeks on '
               END
             + LEFT(
                         CASE WHEN @freq_interval &  1 =  1 THEN 'Sunday, '    ELSE '' END
                       + CASE WHEN @freq_interval &  2 =  2 THEN 'Monday, '    ELSE '' END
                       + CASE WHEN @freq_interval &  4 =  4 THEN 'Tuesday, '   ELSE '' END
                       + CASE WHEN @freq_interval &  8 =  8 THEN 'Wednesday, ' ELSE '' END
                       + CASE WHEN @freq_interval & 16 = 16 THEN 'Thursday, '  ELSE '' END
                       + CASE WHEN @freq_interval & 32 = 32 THEN 'Friday, '    ELSE '' END
                       + CASE WHEN @freq_interval & 64 = 64 THEN 'Saturday, '  ELSE '' END
                     , LEN(
                                CASE WHEN @freq_interval &  1 =  1 THEN 'Sunday, '    ELSE '' END
                              + CASE WHEN @freq_interval &  2 =  2 THEN 'Monday, '    ELSE '' END
                              + CASE WHEN @freq_interval &  4 =  4 THEN 'Tuesday, '   ELSE '' END
                              + CASE WHEN @freq_interval &  8 =  8 THEN 'Wednesday, ' ELSE '' END
                              + CASE WHEN @freq_interval & 16 = 16 THEN 'Thursday, '  ELSE '' END
                              + CASE WHEN @freq_interval & 32 = 32 THEN 'Friday, '    ELSE '' END
                              + CASE WHEN @freq_interval & 64 = 64 THEN 'Saturday, '  ELSE '' END
                           )  - 1  
                   )
       WHEN @freq_type = 0x10 
           THEN
               CASE
                   WHEN @freq_recurrence_factor = 1
                       THEN 'Monthly on the '
                   WHEN @freq_recurrence_factor > 1
                       THEN 'Every '
                          + CAST( @freq_recurrence_factor AS VARCHAR )
                          + ' months on the '
               END
             + CAST( @freq_interval AS VARCHAR )
             + CASE
                   WHEN @freq_interval IN ( 1, 21, 31 ) THEN 'st'
                   WHEN @freq_interval IN ( 2, 22     ) THEN 'nd'
                   WHEN @freq_interval IN ( 3, 23     ) THEN 'rd'
                   ELSE 'th'
               END
       WHEN @freq_type = 0x20
           THEN
               CASE
                   WHEN @freq_recurrence_factor = 1
                       THEN 'Monthly on the '
                   WHEN @freq_recurrence_factor > 1
                       THEN 'Every '
                          + CAST( @freq_recurrence_factor AS VARCHAR )
                          + ' months on the '
               END
             + CASE @freq_relative_interval
                   WHEN 0x01 THEN 'first '
                   WHEN 0x02 THEN 'second '
                   WHEN 0x04 THEN 'third '
                   WHEN 0x08 THEN 'fourth '
                   WHEN 0x10 THEN 'last '
               END
             + CASE @freq_interval
                   WHEN  1 THEN 'Sunday'
                   WHEN  2 THEN 'Monday'
                   WHEN  3 THEN 'Tuesday'
                   WHEN  4 THEN 'Wednesday'
                   WHEN  5 THEN 'Thursday'
                   WHEN  6 THEN 'Friday'
                   WHEN  7 THEN 'Saturday'
                   WHEN  8 THEN 'day'
                   WHEN  9 THEN 'week day'
                   WHEN 10 THEN 'weekend day'
               END
       WHEN @freq_type = 0x40
           THEN 'Automatically starts when SQLServerAgent starts.'
       WHEN @freq_type = 0x80
           THEN 'Starts whenever the CPUs become idle'
       ELSE ''
   END
+ CASE
       WHEN @enabled = 0 THEN ''
       WHEN @job_id IS NULL THEN ''
       WHEN @freq_subday_type = 0x1 OR @freq_type = 0x1
           THEN ' at '
                        + Case  
                                when(@active_start_time % 1000000)/10000 = 0 then 
                                                  '12'
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100)))
                                                + convert(char(2),(@active_start_time % 10000)/100) 
                                                + ' AM'
                                when (@active_start_time % 1000000)/10000< 10 then
                                                convert(char(1),(@active_start_time % 1000000)/10000) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + convert(char(2),(@active_start_time % 10000)/100) 
                                                + ' AM'
                                when (@active_start_time % 1000000)/10000 < 12 then
                                                convert(char(2),(@active_start_time % 1000000)/10000) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + convert(char(2),(@active_start_time % 10000)/100) 
                                                + ' AM'
                                when (@active_start_time % 1000000)/10000< 22 then
                                                convert(char(1),((@active_start_time % 1000000)/10000) - 12) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + convert(char(2),(@active_start_time % 10000)/100) 
                                                + ' PM'
                                else        convert(char(2),((@active_start_time % 1000000)/10000) - 12)
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + convert(char(2),(@active_start_time % 10000)/100) 
                                                + ' PM'
                        end
       WHEN @freq_subday_type IN ( 0x2, 0x4, 0x8 )
           THEN ' every '
             + CAST( @freq_subday_interval AS VARCHAR )
             + CASE @freq_subday_type
                   WHEN 0x2 THEN ' second'
                   WHEN 0x4 THEN ' minute'
                   WHEN 0x8 THEN ' hour'
               END
             + CASE
                   WHEN @freq_subday_interval > 1 THEN 's'
                                   ELSE '' 
               END
       ELSE ''
   END
+ CASE
       WHEN @enabled = 0 THEN ''
       WHEN @job_id IS NULL THEN ''
       WHEN @freq_subday_type IN ( 0x2, 0x4, 0x8 )
           THEN ' between '
                        + Case  
                                when(@active_start_time % 1000000)/10000 = 0 then 
                                                  '12'
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100)))
                                                + rtrim(convert(char(2),(@active_start_time % 10000)/100))
                                                + ' AM'
                                when (@active_start_time % 1000000)/10000< 10 then
                                                convert(char(1),(@active_start_time % 1000000)/10000) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_start_time % 10000)/100))
                                                + ' AM'
                                when (@active_start_time % 1000000)/10000 < 12 then
                                                convert(char(2),(@active_start_time % 1000000)/10000) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_start_time % 10000)/100)) 
                                                + ' AM'
                                when (@active_start_time % 1000000)/10000< 22 then
                                                convert(char(1),((@active_start_time % 1000000)/10000) - 12) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_start_time % 10000)/100)) 
                                                + ' PM'
                                else        convert(char(2),((@active_start_time % 1000000)/10000) - 12)
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_start_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_start_time % 10000)/100))
                                                + ' PM'
                        end
             + ' and '
                        + Case  
                                when(@active_end_time % 1000000)/10000 = 0 then 
                                                '12'
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_end_time % 10000)/100)))
                                                + rtrim(convert(char(2),(@active_end_time % 10000)/100))
                                                + ' AM'
                                when (@active_end_time % 1000000)/10000< 10 then
                                                convert(char(1),(@active_end_time % 1000000)/10000) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_end_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_end_time % 10000)/100))
                                                + ' AM'
                                when (@active_end_time % 1000000)/10000 < 12 then
                                                convert(char(2),(@active_end_time % 1000000)/10000) 
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_end_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_end_time % 10000)/100))
                                                + ' AM'
                                when (@active_end_time % 1000000)/10000< 22 then
                                                convert(char(1),((@active_end_time % 1000000)/10000) - 12)
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_end_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_end_time % 10000)/100)) 
                                                + ' PM'
                                else        convert(char(2),((@active_end_time % 1000000)/10000) - 12)
                                                + ':'  
                                                +Replicate('0',2 - len(convert(char(2),(@active_end_time % 10000)/100))) 
                                                + rtrim(convert(char(2),(@active_end_time % 10000)/100)) 
                                                + ' PM'
                        end
       ELSE ''
   END 

END

GO

/****** Object:  UserDefinedFunction [dbo].[SpaceBeforeCap]    Script Date: 2/08/2023 4:34:23 PM ******/

GO


GO



CREATE FUNCTION [dbo].[SpaceBeforeCap] (
    @str nvarchar(max)
)
returns nvarchar(max)
as
begin

declare
    @i int, @j int
,   @cp nchar, @c0 nchar, @c1 nchar
,   @result nvarchar(max)

select
    @i = 1
,   @j = len(@str)
,   @result = ''

while @i <= @j
begin
    select
        @cp = substring(@str,@i-1,1)
    ,   @c0 = substring(@str,@i+0,1)
    ,   @c1 = substring(@str,@i+1,1)

    if @c0 = UPPER(@c0) collate Latin1_General_CS_AS
    begin
        -- Add space if Current is UPPER 
        -- and either Previous or Next is lower
        -- and Previous or Current is not already a space
        if @c0 = UPPER(@c0) collate Latin1_General_CS_AS
        and (
                @cp <> UPPER(@cp) collate Latin1_General_CS_AS
            or  @c1 <> UPPER(@c1) collate Latin1_General_CS_AS
        )
        and @cp <> ' '
        and @c0 <> ' '
            set @result = @result + ' '
    end -- if @co

    set @result = @result + @c0
    set @i = @i + 1
end -- while

return @result
end


GO



CREATE VIEW [dbo].[vw_DatabaseBackups]
AS 
SELECT 
	[Client]					AS [Client],
	[Host Name]					AS [Host Name],
	[Instance Name]				AS [Instance Name],
	[Database Name]				AS [Database Name],
	[Recovery Model]			AS [Recovery Model],
	[Recent Full Database]		AS [Recent Full Database],
	[Recent Transaction Log]	AS [Recent Transaction Log]
	 ,[timestamp]
FROM [dbo].[Backups]

GO

/****** Object:  View [dbo].[vw_DatabaseDetails]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO




CREATE VIEW [dbo].[vw_DatabaseDetails]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]		AS [Host Name],
	[Instance Name]	AS [Instance Name],
	[Database Name]	AS [Database Name],
	[File Name]		AS [File Name],
	[Type]			AS [Type],
	[Total Size (MB)] AS [Total Size (MB)],
	[Used Size (MB)] AS [Used Size (MB)],
	[Auto-growth]	AS [Auto-growth]
	 ,[timestamp]
FROM [dbo].[DatabaseDetails]

GO

/****** Object:  View [dbo].[vw_DatabaseOptions]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO






CREATE VIEW [dbo].[vw_DatabaseOptions]
AS 
SELECT 
	[Client]			AS [Client],
	[Host Name]			AS [Host Name],
	[Instance Name]		AS [Instance Name],
	[Database Name]		AS [Database Name],
	[State]				AS [State],
	[Compatibility]		AS [Compatibility],
	[Collation]			AS [Collation],
	[Page Verify]		AS [Page Verify]
	 ,[timestamp]
FROM [dbo].[DBoption]

GO

/****** Object:  View [dbo].[vw_DatabasesRoles]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO





CREATE VIEW [dbo].[vw_DatabasesRoles]
AS 
SELECT 
	[Client]			AS [Client],
	[Host Name]			AS [Host Name],
	[Instance Name]		AS [Instance Name],
	[Database Name]		AS [Database Name],
	[Role]				AS [Role],
	[User name]			AS [User Name]
	 ,[timestamp]
FROM [dbo].[DatabasesRoles]

GO

/****** Object:  View [dbo].[vw_Drives]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO





CREATE VIEW [dbo].[vw_Drives]
AS 
SELECT 
	[Client]			AS [Client],
	[Host Name]			AS [Host Name],
	'Doesn''t matter'	AS [Instance Name],
	[DeviceID]			AS [Caption],
	''					AS [Description],
	[VolumeName]		AS [Volume Name],
	''					AS [File System],
	[Size]			AS [Total Size (MB)],
	[FreeSpace]			AS [Free Size (MB)]
	 , [timestamp]
FROM [dbo].[DiskSpace]

GO

/****** Object:  View [dbo].[vw_GetListClients]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO

CREATE VIEW [dbo].[vw_GetListClients] 
AS 
SELECT DISTINCT [Client] FROM [dbo].[DBoption] -- ORDER BY 1

GO

/****** Object:  View [dbo].[vw_GetListDates]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO

CREATE VIEW [dbo].[vw_GetListDates]
AS 
SELECT DISTINCT 
	[Instance Name], 
	[Host Name] as [Host Name], 
	[Client] as [Client],
	[timestamp] 
FROM [dbo].[DBoption]

GO

/****** Object:  View [dbo].[vw_GetListServers]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO



CREATE VIEW [dbo].[vw_GetListServers]
AS 
SELECT DISTINCT 
	[Instance Name], 
	[Host Name] as [Host Name], 
	[Client] as [Client] 
FROM [dbo].[DBoption]

GO

/****** Object:  View [dbo].[vw_Hardware]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO







CREATE VIEW [dbo].[vw_Hardware]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]		AS [Host Name],
	'DOesn''t matter'			AS [Instance Name],
	[Type]			AS [Type],
	[Value]			AS [Value],
	[timestamp]
FROM [dbo].[Hardware]

GO

/****** Object:  View [dbo].[vw_IdleDatabases]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO








CREATE VIEW [dbo].[vw_IdleDatabases]
AS 
SELECT 
	[Client]				AS [Client],
	[Host Name]				AS [Host Name],
	[Instance Name]			AS [Instance Name],
	[Database Name]			AS [Database Name],
	[timestamp]
FROM [dbo].[IdleDatabases]

GO

/****** Object:  View [dbo].[vw_IndexFragmentation]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO




CREATE VIEW [dbo].[vw_IndexFragmentation]
AS 
SELECT 
	[Client]			AS [Client],
	[Host Name]			AS [Host Name],
	[Instance Name]		AS [Instance Name],
	[Database Name]		AS [Database Name],
	[Table Name]		AS [Table Name],
	[Index Size (MB)]	AS [Index Size (MB)],
	[Max Percentage]	AS [Max Percentage],
	[Average Percentage] AS [Average Percentage]
	 ,[timestamp]
FROM [dbo].[IndexFragmentation]
WHERE [Index Size (MB)]	 > 5

GO

/****** Object:  View [dbo].[vw_InstanceDetails]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO






CREATE VIEW [dbo].[vw_InstanceDetails]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]		AS [Host Name],
	'Doesn''t matter'			AS [Instance Name],
	[Type]			AS [Type],
	[Value]			AS [Value],
	[timestamp]

FROM [dbo].[InstanceInformation]

GO

/****** Object:  View [dbo].[vw_IntegrityCheck]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO






CREATE VIEW [dbo].[vw_IntegrityCheck]
AS 
SELECT 
	[Client]				AS [Client],
	[Host Name]				AS [Host Name],
	[Instance Name]			AS [Instance Name],
	[Database Name]			AS [Database Name],
	[Last Executed]			AS [Last Executed]
	 ,[timestamp]
FROM [dbo].[IntegrityCheck]
where [Database Name] <> 'tempdb'

GO

/****** Object:  View [dbo].[vw_Jobs]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO







CREATE VIEW [dbo].[vw_Jobs]
AS 
SELECT 
	CAST([Host Name] AS VARCHAR(MAX)) AS [Host Name],
	[Instance Name],
	[Job Name] AS [Name],

	dbo.ConvertScheduleToStraing(
		enabled,
		job_id,
		freq_type,
		freq_recurrence_factor,
		active_start_date,
		freq_interval,
		freq_relative_interval,
		freq_subday_type,
		active_start_time,
		active_end_time,
		freq_subday_interval
		) AS [Schedule]

	,
	[Owner],
	[Client] AS [Client]
	 ,[timestamp]
FROM [dbo].[Jobs]

GO

/****** Object:  View [dbo].[vw_MaintenancePlans]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO






CREATE VIEW [dbo].[vw_MaintenancePlans]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]		AS [Host Name],
	[Instance Name]	AS [Instance Name],
	[Name]			AS [Name],
	[Owner]			AS [Owner]
	 ,[timestamp]
FROM [dbo].[MaintenencePlans]

GO

/****** Object:  View [dbo].[vw_OperatingSystem]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO







CREATE VIEW [dbo].[vw_OperatingSystem]
AS 
SELECT 
	[ID],
	[Client]		AS [Client],
	[Host Name]		AS [Host Name],
	'Doesn''t matter'			AS [Instance Name],
	[Type]			AS [Type],
	[Value]			AS [Value],
	[timestamp]
FROM [dbo].[OperationSystem]

GO

/****** Object:  View [dbo].[vw_OrphanUsers]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO





CREATE VIEW [dbo].[vw_OrphanUsers]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]			AS [Host Name],
	[Instance Name]			AS [Instance Name],
	[Database Name]			AS [Database Name],
	[User Name]			AS [User Name],
	[Status]			AS [Status],
	[Type]			AS [Type]
	 , [timestamp]
FROM [dbo].[OrphanUsers]

GO

/****** Object:  View [dbo].[vw_ServerRoles]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO






CREATE VIEW [dbo].[vw_ServerRoles]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]		AS [Host Name],
	[Instance Name]	AS [Instance Name],
	[Role]			AS [Role],
	[User name]		AS [User Name],
	[Type]			AS [Type]
	 ,[timestamp]
FROM [dbo].[ServerRoles]

GO

/****** Object:  View [dbo].[vw_Services]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO





CREATE VIEW [dbo].[vw_Services]
AS 
SELECT 
	[Client]		AS [Client],
	[Host Name]			AS [Host Name],
	'Doesn''t matter'			AS [Instance Name],
	[Service Name]			AS [Service Name],
	[Status]			AS [Status],
	[Startup]			AS [Startup],
	[Account]			AS [Account]
	 , [timestamp]
FROM [dbo].[Services]

GO

/****** Object:  View [dbo].[vw_UpdateStatistics]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO






CREATE VIEW [dbo].[vw_UpdateStatistics]
AS 
SELECT 
	[Client]			AS [Client],
	[Host Name]			AS [Host Name],
	[Instance Name]		AS [Instance Name],
	[Database Name]		AS [Database Name],
	[Last Executed]		AS [Last Executed]
	 ,[timestamp]
FROM [dbo].[UpdateStatistics]
WHERE [Database Name] <> 'tempdb'

GO

/****** Object:  View [dbo].[vw_VirtualLogFile]    Script Date: 2/08/2023 4:34:51 PM ******/

GO


GO





CREATE VIEW [dbo].[vw_VirtualLogFile]
AS 
SELECT 
	[Client]			AS [Client],
	[Host Name]			AS [Host Name],
	[Instance Name]		AS [Instance Name],
	[Database Name]		AS [Database Name],
	[Count]				AS [Count],
	[Total Size (MB)]	AS [Total Size (MB)],
	[Average Size (MB)]	AS [Average Size (MB)],
	[Auto-growth]		AS [Auto-growth]
	 ,[timestamp]
FROM [dbo].[VirtualLogFile]
WHERE [Database Name] not in ('master', 'model', 'msdb', 'tempdb')

GO




/****** Object:  StoredProcedure [dbo].[SP_DeleteAll]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO



/****** Object:  UserDefinedTableType [dbo].[DisksTable]    Script Date: 2/08/2023 4:44:19 PM ******/
CREATE TYPE [dbo].[DisksTable] AS TABLE(
	[Host Name] [varchar](max) NULL,
	[DeviceID] [varchar](max) NULL,
	[VolumeName] [varchar](max) NULL,
	[Size] [bigint] NULL,
	[FreeSpace] [bigint] NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
)
GO

/****** Object:  UserDefinedTableType [dbo].[InstanceInfo]    Script Date: 2/08/2023 4:44:19 PM ******/
CREATE TYPE [dbo].[InstanceInfo] AS TABLE(
	[ID] [int] NULL,
	[Host Name] [varchar](max) NULL,
	[Instance Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
)
GO

/****** Object:  UserDefinedTableType [dbo].[ServiceTable]    Script Date: 2/08/2023 4:44:19 PM ******/
CREATE TYPE [dbo].[ServiceTable] AS TABLE(
	[Host Name] [varchar](200) NULL,
	[Service Name] [varchar](200) NULL,
	[Account] [varchar](200) NULL,
	[Startup] [varchar](200) NULL,
	[Status] [varchar](200) NULL,
	[PathName] [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
)
GO


CREATE PROC [dbo].[SP_DeleteAll]
AS 

	truncate table [dbo].[Backups]
	truncate table [dbo].[DatabaseDetails]
	truncate table [dbo].[DatabasesRoles]
	truncate table [dbo].[DBoption]
	truncate table [dbo].[DiskSpace]
	truncate table [dbo].[Hardware]
	truncate table [dbo].[IndexFragmentation]
	truncate table [dbo].[InstanceInformation]
	truncate table [dbo].[IntegrityCheck]
	truncate table [dbo].[Jobs]
	truncate table [dbo].[MaintenencePlans]
	truncate table [dbo].[OperationSystem]
	truncate table [dbo].[OrphanUsers]
	truncate table [dbo].[ServerRoles]
	truncate table [dbo].[Services]
	truncate table [dbo].[UpdateStatistics]
	truncate table [dbo].[VirtualLogFile]

	--truncate table [dbo].[Instances]
	--truncate table [dbo].[Queries]
	truncate table [dbo].[IdleDatabases]

GO

/****** Object:  StoredProcedure [dbo].[SP_DiskSpace]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO








CREATE PROCEDURE [dbo].[SP_DiskSpace]
@DSUdisks dbo.DisksTable READONLY
AS
BEGIN

SET NOCOUNT ON;

INSERT INTO [dbo].[DiskSpace]
(
[Host Name]
,[DeviceID]
,[VolumeName]
,[Size]
,[FreeSpace]
,[Client]
,[timestamp]
)
SELECT 
[Host Name]
,[DeviceID]
,[VolumeName]
,[Size]
,[FreeSpace]
,[Client]
,dateadd(millisecond, -datepart(millisecond, [timestamp]), [timestamp])  -- rid off milliseconds
FROM @DSUdisks

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabaseBackups]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetDatabaseBackups]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	[Recovery Model],
	[Recent Full Database],
	[Recent Transaction Log]

FROM [dbo].[vw_DatabaseBackups] D
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
ORDER BY D.[Database Name]

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabaseBackups_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO







CREATE PROCEDURE [dbo].[SP_GetDatabaseBackups_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name] = 0,
	[Recovery Model] = 0,
	[Recent Full Database] = 
		CASE 
			WHEN 
				DATEDIFF(dd,[Recent Full Database],CONVERT(datetime, @timestamp ,103)) > 7 
			THEN 3
			ELSE 0
		END ,

	[Recent Transaction Log] = 
	CASE 
		WHEN [Recovery Model] <> 'SIMPLE' THEN 
				CASE 
					WHEN 
						DATEDIFF(dd,[Recent Transaction Log],CONVERT(datetime, @timestamp ,103)) > 1 
						--AND [Database Name] NOT IN ('model', 'tempdb') 
					THEN 3
					ELSE 0
				END 
			ELSE 0
	END
	--[Database Name],
	--[Recovery Model],
	--[Recent Full Database],
	--[Recent Transaction Log]

FROM [dbo].[vw_DatabaseBackups] D
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
ORDER BY D.[Database Name]


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabaseDetails]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetDatabaseDetails]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	[File Name],
	CASE WHEN [Type] = 0 THEN 'Data' ELSE 'LOG' END [Type],
	[Total Size (MB)],
	[Used Size (MB)],
	[Auto-growth]
FROM [dbo].[vw_DatabaseDetails]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabaseDetails_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO











CREATE PROCEDURE [dbo].[SP_GetDatabaseDetails_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;

DECLARE @CPUs integer
DECLARE @tempdbs integer

SELECT @tempdbs = COUNT(*) 
FROM [dbo].[vw_DatabaseDetails] 
  WHERE [Database Name] = 'tempdb'
    AND [Type] = 0
	AND [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName

SELECT @CPUs = [Value]
FROM [dbo].[vw_InstanceDetails] 
WHERE [Type] = 'Processors'
	AND [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

SELECT

	[Database Name] = 
		CASE 
			WHEN 
				[Database Name] = 'tempdb' AND @CPUs != @tempdbs
 			THEN 3
			ELSE 0
		END,
	[File Name] = 
		CASE 
			WHEN 
				[Database Name] = 'tempdb' AND [File Name] like 'C:\%'
 			THEN 3
 			WHEN [File Name] like 'C:\%' AND [Database Name] NOT IN ('master', 'msdb', 'model')
 			THEN 1
			ELSE 0
		END,
	[Type] = 0,
	[Total Size (MB)] = 0,
	[Used Size (MB)] = 0,
	[Auto-growth] =
		CASE 
			WHEN 
				charindex('percent',DD.[Auto-growth], 1) <> 0
			THEN 3
			WHEN
				charindex('1 mb ',DD.[Auto-growth], 1) <> 0
			THEN 3
			ELSE 0
		END
	--, @CPUs, @tempdbs	
FROM [dbo].[vw_DatabaseDetails] DD
WHERE DD.[Client] = @Client
	AND DD.[Host Name] = @HostName
	--AND DD.[timestamp] = CONVERT(datetime, @timestamp ,103)
	AND DD.[Instance Name] = @InstanceName


END





GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabaseOptions]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetDatabaseOptions]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	[State],
	[Compatibility],
	[Collation],
	[Page Verify]

FROM [dbo].[vw_DatabaseOptions]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
ORDER BY [Database Name]


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabaseOptions_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO








CREATE PROCEDURE [dbo].[SP_GetDatabaseOptions_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;

DECLARE @SrvCol varchar(max)
DECLARE @SrvVer Integer

SELECT @SrvVer = CAST(SUBSTRING(Value, 0, 3) + '0' AS Integer) 
FROM [dbo].[InstanceInformation]
WHERE  Type= 'Version'
	AND [Instance Name] = @InstanceName
	AND [Client] = @Client
	--AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

PRINT @SrvVer

SELECT @SrvCol = [Value]
FROM [dbo].[InstanceInformation] 
WHERE [Type] = 'Instance Collation'
	AND [Client] = @Client
	--AND [Host Name] = @HostName
	AND [Instance Name] = @InstanceName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

PRINT @SrvCol

SELECT
	[Database Name]=0,
	[State]= 
		CASE 
			WHEN 
				[State] != 'ONLINE' 
			THEN 1
			ELSE 0
		END,
	[Compatibility]= 
		CASE 
			WHEN 
				[Compatibility] != @SrvVer
			THEN 1
			ELSE 0
		END,
	[Collation]= 
		CASE 
			WHEN 
				[Collation] != @SrvCol 
			THEN 3
			ELSE 0
		END,
	[Page Verify] = 
		CASE 
			WHEN 
				[Page Verify] != 'CHECKSUM'
			THEN 3
			ELSE 0
		END
FROM [dbo].[vw_DatabaseOptions]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
ORDER BY [Database Name]


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabasesRoles]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO



CREATE PROCEDURE [dbo].[SP_GetDatabasesRoles]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	[Database Name],
	[Role],
	[User name]
FROM [dbo].[DatabasesRoles]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDatabasesRoles_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetDatabasesRoles_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	[Database Name] = 0,
	[Role] =
		CASE 
			WHEN 
				[Role] IN ( 'db_accessadmin',
							'db_backupoperator', 
							'db_ddladmin', 
							'db_owner', 
							'db_securityadmin')
			THEN 2
			WHEN 
				[Role] NOT IN ( 'db_accessadmin',
								'db_backupoperator', 
								'db_datareader', 
								'db_datawriter', 
								'db_ddladmin', 
								'db_denydatareader',
								'db_denydatawriter', 
								'db_owner', 
								'db_securityadmin',
								'public')
			THEN 1
			ELSE 0
		END,
	[User name] = 
		CASE 
			WHEN 
				[Role] IN ( 'db_accessadmin',
							'db_backupoperator', 
							'db_ddladmin', 
							'db_owner', 
							'db_securityadmin')
			THEN 2
			WHEN 
				[Role] NOT IN ( 'db_accessadmin',
								'db_backupoperator', 
								'db_datareader', 
								'db_datawriter', 
								'db_ddladmin', 
								'db_denydatareader',
								'db_denydatawriter', 
								'db_owner', 
								'db_securityadmin',
								'public')
			THEN 1
			ELSE 0
		END
FROM [dbo].[DatabasesRoles]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDiskSpace]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetDiskSpace]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	[Caption]			AS [Caption]
	,[Description] 		AS [Description]
	,[Volume Name]		AS [Volume Name]
	,[File System]		AS [File System]
	, CAST(CAST([Total Size (MB)] AS BIGINT) / (1024 * 1024) AS VARCHAR(MAX)) + ' MB'	AS [Total Size (MB)]
	, CAST(CAST([Free Size (MB)] AS BIGINT) / (1024 * 1024) AS VARCHAR(MAX)) + ' MB'	AS [Free Size (MB)]
FROM [dbo].[vw_Drives]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetDiskSpace_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetDiskSpace_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	0	AS [Caption]
	,0	AS [Description]
	,0	AS [Volume Name]
	,0	AS [File System]
	,0	AS [Total Size (MB)]
	,	CASE
		WHEN CAST([Total Size (MB)] as numeric) = 0 THEN 3
		ELSE
			CASE 
				WHEN CAST([Free Size (MB)] as numeric)*100 / CAST([Total Size (MB)] as numeric) < 20 THEN 2
				WHEN CAST([Free Size (MB)] as numeric)*100 / CAST([Total Size (MB)] as numeric) < 40 THEN 1
				ELSE 0
			END
		END	AS [Free Size (MB)]
FROM [dbo].[vw_Drives]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetHardware]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO









CREATE PROC [dbo].[SP_GetHardware] 
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS 
SELECT
	--[Host Name],
	dbo.SpaceBeforeCap([Type]) [Type]
	,[Value] = replace(replace(replace(cast(coalesce(CASE 
			WHEN [Type] = 'TotalPhysicalMemory'
			THEN SUBSTRING(Value, 1, CHARINDEX('.', value)-1) + ' GB'
			ELSE [Value]
		END ,'') as VARCHAR(200)),' ','<>'),'><',''),'<>',' ') 
		
FROM [dbo].[vw_Hardware] 
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)



GO

/****** Object:  StoredProcedure [dbo].[SP_GetHardware_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO


CREATE PROC [dbo].[SP_GetHardware_COLOR] 
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS 
--- Not clear:
--- CPU NumberOfCores
--- and 
--- NumberOfLogicalProcessors

SELECT 	0,0
FROM [dbo].[vw_Hardware] 
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

GO

/****** Object:  StoredProcedure [dbo].[SP_GetIdleDatabases]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO







CREATE PROCEDURE [dbo].[SP_GetIdleDatabases]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name]

FROM [dbo].[vw_IdleDatabases] D
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
	AND [Database Name] NOT IN ('master', 'msdb', 'model', 'tempdb')
ORDER BY D.[Database Name]

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetIdleDatabases_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO







CREATE PROCEDURE [dbo].[SP_GetIdleDatabases_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	1

FROM [dbo].[vw_IdleDatabases] D
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
	AND [Database Name] NOT IN ('master', 'msdb', 'model', 'tempdb')
ORDER BY D.[Database Name]
END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetIndexFragmentation]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO








CREATE PROCEDURE [dbo].[SP_GetIndexFragmentation]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	[Table Name],
	[Index Size (MB)],
	[Max Percentage],
	[Average Percentage]
FROM [dbo].[vw_IndexFragmentation]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
	AND CAST([Index Size (MB)] AS int) >= 20
	AND (CAST([Average Percentage] AS decimal) >= 50.0 OR CAST([Max Percentage] AS decimal) >= 50.0)
	ORDER BY [Database Name] asc,
	CAST([Max Percentage] AS decimal) desc,
	CAST([Average Percentage] AS decimal) desc
	

END



GO

/****** Object:  StoredProcedure [dbo].[SP_GetIndexFragmentation_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO









CREATE PROCEDURE [dbo].[SP_GetIndexFragmentation_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	0,0,0,
	[Max Percentage] = 
		CASE 
			WHEN 
				CAST([Max Percentage] as numeric)> 70
			THEN 3
			ELSE 0
		END, 
	[Average Percentage] = 
		CASE 
			WHEN 
				CAST([Average Percentage] as numeric) > 70
			THEN 3
			ELSE 0
		END 
	--[Database Name],
	--[Table Name],
	--[Index Size (MB)],
	--[Max Percentage]
	--[Average Percentage]
FROM [dbo].[vw_IndexFragmentation]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
	AND CAST([Index Size (MB)] AS int) >= 20
	AND (CAST([Average Percentage] AS decimal) >= 50.0 OR CAST([Max Percentage] AS decimal) >= 50.0)
	ORDER BY [Database Name] asc,
	CAST([Max Percentage] AS decimal) desc,
	CAST([Average Percentage] AS decimal) desc


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetInstanceDetails]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO










CREATE PROCEDURE [dbo].[SP_GetInstanceDetails]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	CASE
	WHEN Type like 'SPs%' THEN Type
	ELSE dbo.SpaceBeforeCap([Type]) 
	END [Type],
	CASE
	WHEN Type like 'PhysicalMemoryUsageMB%' THEN SUBSTRING(Value, 1, CHARINDEX('.', value)-1)
	ELSE replace(replace(replace(cast(coalesce([Value],'') as VARCHAR(200)),' ','<>'),'><',''),'<>',' ') 
	END [Value]
 FROM [dbo].[InstanceInformation]
--FROM [dbo].[vw_InstanceDetails]
WHERE [Client] = @Client
	--AND [Host Name] = @HostName
	AND [Instance Name] = @InstanceName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
ORDER BY [ID]

END




GO

/****** Object:  StoredProcedure [dbo].[SP_GetInstanceDetails_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO








CREATE PROCEDURE [dbo].[SP_GetInstanceDetails_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;

DECLARE @minRAM integer
DECLARE @maxRAM integer
DECLARE @SystemDrive char(1)

SELECT @SystemDrive = SUBSTRING([Value],1,1)
FROM [dbo].[OperationSystem]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Type] = 'SystemDirectory'


SELECT @minRAM = [Value]
FROM [dbo].[InstanceInformation]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Type] = 'MinRAM'
-- 16

SELECT @maxRAM = [Value]
FROM [dbo].[InstanceInformation]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Type] = 'MaxRAM'
-- 2147483647

SELECT 
	[Type] = 0, 
	[Value] = 
		CASE 
			WHEN [Type] = 'MaxRAM' AND [Value] = 2147483647 THEN 3 
			WHEN [Type] = 'MinRAM' AND [Value] = 16 THEN 3 

			WHEN [Type] = 'LoginMode' AND [Value] != 'Mixed' THEN 2
			WHEN [Type] = 'DefaultLog' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 2
			WHEN [Type] = 'DefaultFile' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 2
			WHEN [Type] = 'BackupDirectory' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 2
			WHEN [Type] = 'DefaultBackupCompression' AND [Value] = 'Disabled' THEN 2
	

			WHEN [Type] = 'BackupDirectory' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 3 

			WHEN [Type] = 'MasterDBLogPath' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 1 
			WHEN [Type] = 'MasterDBPath' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 1 
			WHEN [Type] = 'ErrorLogPath' AND SUBSTRING([Value],1,1) = @SystemDrive THEN 1 
			WHEN [Type] = 'MaxDegreeOfParallelism' AND [Value] != 0 THEN 1 
			WHEN [Type] like 'Startup%' THEN 1 
			

			WHEN [Type] = 'Version' AND 
					(
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 7 
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 1063
					) OR
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 8 
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 2039
					) OR
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 9 
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 5000
					) OR
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 10 
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 6000
					) OR
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 11 
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 6020
					) OR
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 12 
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 5000
					) OR
					(SUBSTRING([Value],1,CHARINDEX('.',[Value])-1) = 13
					AND SUBSTRING([Value],LEN([Value]) - CHARINDEX('.',REVERSE([Value]))+2, CHARINDEX('.',REVERSE([Value]))-1) < 4001
					) 
					)
			 THEN 2

			

			ELSE 0
		END

FROM [dbo].[InstanceInformation]
WHERE [Client] = @Client
	--AND [Host Name] = @HostName
	AND [Instance Name] = @InstanceName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
ORDER BY [ID]


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetIntegrityCheck]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetIntegrityCheck]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	CASE
	WHEN CONVERT(varchar(4),[Last Executed],112) = '1900' THEN NULL
	ELSE [Last Executed]
	END [Last Executed]
FROM [dbo].[vw_IntegrityCheck]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetIntegrityCheck_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetIntegrityCheck_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name] = 0,
	[Last Executed] = 
		CASE 
			WHEN 
				DATEDIFF(dd,[Last Executed],CONVERT(datetime, @timestamp ,103)) > 7 
				--AND [Database Name] NOT IN ('model', 'tempdb') 
			THEN 3
			ELSE 0
		END 
	--[Database Name],
	--[Last Executed]
FROM [dbo].[vw_IntegrityCheck]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetJobs]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO



CREATE PROCEDURE [dbo].[SP_GetJobs]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Name],
	[Schedule],
	[Owner]

FROM [dbo].[vw_Jobs]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetJobs_COLOR]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetJobs_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Name] = 0,
	[Schedule] = 0,
	[Owner] =
		CASE 
			WHEN 
				[Owner] != 'sa' 
			THEN 3
			ELSE 0
		END
	--[Name],
	--[Schedule],
	--[Owner]

FROM [dbo].[vw_Jobs]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetListClients]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO

CREATE PROC [dbo].[SP_GetListClients]
AS 
SELECT DISTINCT [Client] FROM [dbo].[DBoption] ORDER BY 1
--SELECT DISTINCT [Client],timestamp FROM [dbo].[DBoption] ORDER BY 1
GO

/****** Object:  StoredProcedure [dbo].[SP_GetListServers]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO




CREATE PROC [dbo].[SP_GetListServers] 
	--@Client VARCHAR(200)
	--,@timestamp datetime

AS 
SELECT DISTINCT 
	COALESCE([Instance Name], [Host Name]) AS [Instance Name],
	[Host Name] as [Host Name], 
	[Client] as [Client] 
FROM [dbo].[DBoption]
--WHERE [Client] = @Client
	--AND [timestamp]  =CONVERT(datetime, @timestamp ,103)

GO

/****** Object:  StoredProcedure [dbo].[SP_GetLoadsDates]    Script Date: 2/08/2023 4:41:31 PM ******/

GO


GO


CREATE PROCEDURE [dbo].[SP_GetLoadsDates]
	--@InstanceName  varchar(2000),
	--@HostName varchar(2000),
	--@Client varchar(2000)
AS   
SET NOCOUNT ON;
SELECT DISTINCT
	--CAST(CONVERT(datetime, [timestamp] ,103) AS VARCHAR(50)) AS [timestamp]
	[timestamp] 
FROM [dbo].[DBoption]
--WHERE [Client] = @Client  
--	--AND [Host Name] = @HostName
--	--AND [Instance Name] = @InstanceName
--ORDER BY [timestamp]

--SELECT getdate() AS  [timestamp], @InstanceName as AAA

GO

/****** Object:  StoredProcedure [dbo].[SP_GetMaintenancePlans]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO



CREATE PROCEDURE [dbo].[SP_GetMaintenancePlans]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Name],
	[Owner]
FROM [dbo].[vw_MaintenancePlans]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetMaintenancePlans_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetMaintenancePlans_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Name] = 0,
	[Owner] = 
		CASE 
			WHEN 
				[Owner] != 'sa' 
			THEN 2
			ELSE 0
		END 
	--[Name],
	--[Owner]
FROM [dbo].[vw_MaintenancePlans]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetOrphanUsers]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO



CREATE PROCEDURE [dbo].[SP_GetOrphanUsers]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	[Database Name],
	[User Name],
	[Status],
	[Type]
FROM [dbo].[vw_OrphanUsers]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetOrphanUsers_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetOrphanUsers_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 

	[Database Name] = 
		CASE 
		WHEN 
			[User Name] NOT IN ('MS_DataCollectorInternalUser') 
		THEN 1
		ELSE 0
		END,
	[User Name] = 
		CASE 
		WHEN 
			[User Name] NOT IN ('MS_DataCollectorInternalUser') 
		THEN 1
		ELSE 0
		END,
	[Status] = 
		CASE 
		WHEN 
			[User Name] NOT IN ('MS_DataCollectorInternalUser') 
		THEN 1
		ELSE 0
		END,
	[Type] = 
		CASE 
		WHEN 
			[User Name] NOT IN ('MS_DataCollectorInternalUser') 
		THEN 1
		ELSE 0
		END
FROM [dbo].[vw_OrphanUsers]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetOS]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO








CREATE PROCEDURE [dbo].[SP_GetOS]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN

SET NOCOUNT ON;

DECLARE @name varchar(20), @i int

SET @name= @HostName
SET @i = CHARINDEX('\', @HostName)
IF @i > 0
SET @name= SUBSTRING(@HostName, 0, @i)

SELECT 
	CASE
	WHEN Type like 'Local admin%' THEN 'Local Admin'
	ELSE dbo.SpaceBeforeCap([Type]) 
	END [Type]
	,[Value]  = 
		CASE 
			WHEN [Type] IN ('FreePhysicalMemory', 'TotalVirtualMemorySize', 'TotalVisibleMemorySize', 'FreeVirtualMemory')
				THEN CAST(CAST([Value] AS BIGINT) / (1024) AS VARCHAR(MAX)) + ' MB'
			WHEN [Type] IN ('InstallDate', 'LastBootUpTime')
				THEN SUBSTRING([Value],7,2) + '/' + SUBSTRING([Value],5,2) + '/' + SUBSTRING([Value],1,4) + ' ' + SUBSTRING([Value],9,2)  + ':' + SUBSTRING([Value],11,2) + ':' + SUBSTRING([Value],13,2)  
				-- AS datetime) 
			ELSE replace(replace(replace(cast(coalesce([Value],'') as VARCHAR(200)),' ','<>'),'><',''),'<>',' ')
		END 
FROM [dbo].[vw_OperatingSystem]
WHERE [Client] = @Client
	AND [Host Name] = @name
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND Type NOT IN ('SizeStoredInPagingFiles', 'FreeSpaceInPagingFiles', 'ServicePackMinorVersion', 'OS SP')
ORDER BY [ID]

END




GO

/****** Object:  StoredProcedure [dbo].[SP_GetOS_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO










CREATE PROCEDURE [dbo].[SP_GetOS_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN

SET NOCOUNT ON;
DECLARE @name varchar(20), @i int
SET @name= @HostName
SET @i = CHARINDEX('\', @HostName)
IF @i > 0
SET @name= SUBSTRING(@HostName, 0, @i)

SELECT
	0,
	CASE 
		WHEN  [Type] = 'Local admin' THEN 3
		ELSE 0 
	END 
FROM [dbo].[vw_OperatingSystem]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND Type NOT IN ('SizeStoredInPagingFiles', 'FreeSpaceInPagingFiles', 'ServicePackMinorVersion', 'OS SP')
ORDER BY [ID]

END





GO

/****** Object:  StoredProcedure [dbo].[SP_GetServerRoles]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO



CREATE PROCEDURE [dbo].[SP_GetServerRoles]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	[Role],
	[User name],
	[Type]
FROM [dbo].[ServerRoles]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
	AND [User name] <> 'sa'
	AND [User name] not like 'NT SERVICE\%'
	AND [User name] not like 'NT AUTHORITY\%'



END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetServerRoles_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO





CREATE PROCEDURE [dbo].[SP_GetServerRoles_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	0,3,0
	--[Role],
	--[User name],
	--[Type]
FROM [dbo].[ServerRoles]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
	AND [User name] <> 'sa'
	AND [User name] not like 'NT SERVICE\%'
	AND [User name] not like 'NT AUTHORITY\%'


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetServices]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO



CREATE PROCEDURE [dbo].[SP_GetServices]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	[Service Name],
	[Status],
	[Startup],
	[Account]
FROM [dbo].[vw_Services]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetServices_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetServices_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT 
	0 AS [Service Name],
	CASE [Status]  
         WHEN 'Running' THEN 0
         WHEN 'Stopped' THEN 
			CASE [Service Name] 
			WHEN 'SQLAgent$SQLEXPRESS' THEN 0
			ELSE 3
			END
		 ELSE 3
		 END,
		CASE [Startup]  
         WHEN 'Auto' THEN 0
         WHEN 'Manual' THEN 2  
         ELSE 
			CASE [Service Name] 
			WHEN 'SQLAgent$SQLEXPRESS' THEN 0
			ELSE 3
			END
      END AS [Startup],
	CASE  
         WHEN SUBSTRING([Account],1,11) = 'NT Service\' THEN 2
         WHEN SUBSTRING([Account],1,13) = 'NT AUTHORITY\' THEN 2
         WHEN SUBSTRING([Account],1,11) = 'LocalSystem' THEN 2
         ELSE 0
      END AS [Account]
FROM [dbo].[vw_Services]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)

END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetUpdateStatistics]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetUpdateStatistics]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	CASE
	WHEN CONVERT(varchar(4),[Last Executed],112) = '1900' THEN NULL
	ELSE [Last Executed]
	END [Last Executed]
FROM [dbo].[vw_UpdateStatistics]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetUpdateStatistics_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO







CREATE PROCEDURE [dbo].[SP_GetUpdateStatistics_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name] = 0,
	[Last Executed] = 
		CASE 
			WHEN CONVERT(varchar(4),[Last Executed],112) <> '1900' AND DATEDIFF(dd,[Last Executed],CONVERT(datetime, @timestamp ,103)) > 7 
				AND [Database Name] NOT IN ('model', 'tempdb') THEN 3
			ELSE 0
		END 
	--, DATEDIFF(dd,[Last Executed],CONVERT(datetime, @timestamp ,103))
	--, [Last Executed]
	--, @timestamp
	--[Database Name],
	--[Last Executed]
FROM [dbo].[vw_UpdateStatistics]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName
END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetVLF]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO




CREATE PROCEDURE [dbo].[SP_GetVLF]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT
	[Database Name],
	[Count],
	[Total Size (MB)],
	[Average Size (MB)],
	[Auto-growth]

FROM [dbo].[vw_VirtualLogFile]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetVLF_COLOR]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO







CREATE PROCEDURE [dbo].[SP_GetVLF_COLOR]
	@Client VARCHAR(MAX),
	@HostName VARCHAR(MAX),
	@InstanceName VARCHAR(MAX),
	@timestamp datetime
AS
BEGIN
SET NOCOUNT ON;
SELECT

	[Database Name] = 0,
	[Count] = 
			CASE 
			WHEN 
				[Count] > 50 and [Count] < 150 
			THEN 1
			WHEN 
				[Count] >= 150 and [Count] < 500
			THEN 2
			WHEN 
				[Count] >= 500
			THEN 3
			ELSE 0
		END,
	[Total Size (MB)] = 0,
	[Average Size (MB)] = 0,
	[Auto-growth] =
		CASE 
			WHEN 
				charindex('percent',[Auto-growth], 1) <> 0
 
			THEN 3
			ELSE 0
		END

FROM [dbo].[vw_VirtualLogFile]
WHERE [Client] = @Client
	AND [Host Name] = @HostName
	--AND [timestamp] = CONVERT(datetime, @timestamp ,103)
	AND [Instance Name] = @InstanceName


END

GO

/****** Object:  StoredProcedure [dbo].[SP_GetWordData]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO




CREATE PROC [dbo].[SP_GetWordData](
 @DateCollection	datetime		= '2017-05-04 16:02:18.000'
,@ClientName		varchar(max)	= 'BCS'
,@SQLname			varchar(max)	= 'BCSADLNB26\SQL14'	
)
AS

declare @SQLVersion			varchar(max)
declare @OSVersion			varchar(max)
declare @ServerName			varchar(max)

SELECT DISTINCT 
	@ServerName = [Host Name], 
	@SQLVersion = [Value] 
FROM [dbo].[InstanceInformation]
WHERE [Client] = @ClientName
	--AND [timestamp]  =CONVERT(datetime, @DateCollection ,103)
	AND [Instance Name] = @SQLname
	AND [Type] = 'Edition'

SELECT DISTINCT
	@SQLVersion = 
		CASE
			WHEN SUBSTRING(	[Value],1,2) = '7.' THEN '7.0 '
			WHEN SUBSTRING(	[Value],1,2) = '8.' THEN '2000 '
			WHEN SUBSTRING(	[Value],1,2) = '9.' THEN '2005 '
			WHEN SUBSTRING(	[Value],1,4) = '10.5' THEN '2008R2 '
			WHEN SUBSTRING(	[Value],1,4) = '10.0' THEN '2008 '
			WHEN SUBSTRING(	[Value],1,2) = '11' THEN '2012 '
			WHEN SUBSTRING(	[Value],1,2) = '12' THEN '2014 '
			WHEN SUBSTRING(	[Value],1,2) = '13' THEN '2016 '
			WHEN SUBSTRING(	[Value],1,2) = '14' THEN '2017 '
			ELSE 'Unknown '
		END  + @SQLVersion
FROM [dbo].[InstanceInformation]
WHERE [Client] = @ClientName
	--AND [timestamp]  =CONVERT(datetime, @DateCollection ,103)
	AND [Instance Name] = @SQLname
	AND [Type] = 'Version'

DECLARE @name varchar(20), @i int
SET @name= @ServerName
SET @i = CHARINDEX('\', @ServerName)
IF @i > 0
SET @ServerName= SUBSTRING(@ServerName, 0, @i)


SELECT DISTINCT
	@OSVersion = [Value]
FROM [dbo].[OperationSystem]
where [Type] = 'OS Caption' 
	AND [Client]	= @ClientName
	--AND [timestamp] = CONVERT(datetime, @DateCollection ,103)
	AND [Host Name] = @ServerName

SELECT	@ClientName AS ClientName, 
		CASE
			WHEN @ServerName IS NULL THEN 'Unknown'
			ELSE @ServerName
		END AS ServerName, 
		@SQLname AS SQLname, 
		CASE
			WHEN @SQLVersion IS NULL THEN 'Unknown'
			ELSE @SQLVersion
		END  AS SQLVersion, 
		CASE
			WHEN @OSVersion IS NULL THEN 'Unknown'
			ELSE @OSVersion
		END  OSVersion,
		CAST(@DateCollection AS VARCHAR(MAX)) AS DateCollection



GO

/****** Object:  StoredProcedure [dbo].[SP_Hardware]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO


CREATE PROCEDURE [dbo].[SP_Hardware]
@DSUhdw InstanceInfo READONLY
AS
BEGIN

SET NOCOUNT ON;

INSERT INTO [dbo].[Hardware](
[ID]
,[Host Name]
,[Type]
,[Value]
,[Client]
,[timestamp]
)
SELECT 
[ID]
,[Host Name]
,[Type]
,[Value]
,[Client]
,dateadd(millisecond, -datepart(millisecond, [timestamp]), [timestamp])  -- rid off milliseconds
FROM @DSUhdw
ORDER BY [ID]

END

GO

/****** Object:  StoredProcedure [dbo].[SP_InstanceInfo]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO


CREATE PROCEDURE [dbo].[SP_InstanceInfo]
@DSUinst InstanceInfo READONLY
AS
BEGIN

SET NOCOUNT ON;

INSERT INTO [dbo].[InstanceInformation](
[ID]
,[Host Name]
,[Instance Name]
,[Type]
,[Value]
,[Client]
,[timestamp]
)
SELECT 
[ID]
,[Host Name]
,[Instance Name]
,[Type]
,[Value]
,[Client]
,dateadd(millisecond, -datepart(millisecond, [timestamp]), [timestamp])  -- rid off milliseconds
FROM @DSUinst
ORDER BY [ID]

END

GO

/****** Object:  StoredProcedure [dbo].[SP_OS]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO


CREATE PROCEDURE [dbo].[SP_OS]
@DSUos InstanceInfo READONLY
AS
BEGIN

SET NOCOUNT ON;

INSERT INTO [dbo].[OperationSystem](
[ID]
,[Host Name]
,[Type]
,[Value]
,[Client]
,[timestamp]
)
SELECT 
[ID]
,[Host Name]
,[Type]
,[Value]
,[Client]
,dateadd(millisecond, -datepart(millisecond, [timestamp]), [timestamp])  -- rid off milliseconds
FROM @DSUos
ORDER BY [ID]

END

GO

/****** Object:  StoredProcedure [dbo].[SP_ServiceTable]    Script Date: 2/08/2023 4:41:32 PM ******/

GO


GO






CREATE PROCEDURE [dbo].[SP_ServiceTable]
@DSUTable ServiceTable READONLY
AS
BEGIN

SET NOCOUNT ON;

INSERT INTO [dbo].[Services](
[Host Name]
,[Service Name]
,[Account]
,[Startup]
,[Status]
,[PathName]
,[Client]
,[timestamp]
)
SELECT 
[Host Name]
,[Service Name]
,[Account]
,[Startup]
,[Status]
,[PathName]
,[Client]
,dateadd(millisecond, -datepart(millisecond, [timestamp]), [timestamp])  -- rid off milliseconds
FROM @DSUTable
ORDER BY [Service Name]

END

GO


