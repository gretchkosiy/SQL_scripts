SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
SERVERPROPERTY('MachineName') AS [Host Name],
D.name AS [Database Name], 
--'ALTER DATABASE [' + D.name + '] SET PAGE_VERIFY CHECKSUM  WITH NO_WAIT',
--'use [' + D.name + '];exec sp_changedbowner ''sa''',

compatibility_level AS [Compatibility], 
CASE 
	WHEN CAST(SERVERPROPERTY('ProductMajorVersion') AS INT)*10 <> compatibility_level 
		THEN 'ALTER DATABASE [' + D.name + '] SET COMPATIBILITY_LEVEL = ' + CAST(CAST(SERVERPROPERTY('ProductMajorVersion') AS INT)*10 AS VARCHAR(3)) +'''' 
		ELSE '' 
END AS [COMPATIBILITY_LEVEL to INSTANCE update],
S.name DBowner,
CASE is_in_standby
WHEN 1 THEN 'STANDBY'
ELSE state_desc
END AS [State], 

collation_name AS [Collation], 
page_verify_option_desc AS [Page Verify],
CASE is_auto_close_on
WHEN 1 THEN 'Y'
ELSE 'N'
END AS [auto_close],
CASE is_auto_shrink_on
WHEN 1 THEN 'Y'
ELSE 'N'
END AS [auto_shrink],
CASE is_db_chaining_on
WHEN 1 THEN 'Y'
ELSE 'N'
END as [db_chaining],
CASE is_auto_create_stats_on
WHEN 1 THEN 'Y'
ELSE 'N'
END AS [auto_create_stats],
CASE is_auto_update_stats_on
WHEN 1 THEN 'Y'
ELSE 'N'
END AS [auto_update_stats]

--INTO DBoption
FROM master.sys.databases D 
	LEFT JOIN master.sys.syslogins S on D.owner_sid = s.sid  
--WHERE page_verify_option_desc <> 'CHECKSUM'
--WHERE S.name <> 'sa' AND S.name in (select name from master.dbo.syslogins)
ORDER BY D.name

-- 95 