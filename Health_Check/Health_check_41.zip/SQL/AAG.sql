IF (SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)),1,CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)))-1) > 10)
SELECT 
	HARS.role_desc				AS [Role]
	,HARCS.replica_server_name	AS [Server Name]
	--,HARS.operational_state_desc
	--,HARS.connected_state_desc
	--,HARS.synchronization_health_desc
	,AG.name					AS [AGG name]
	,ISNULL(AGL.dns_name,'')	AS [Listener DNS name]
	, ISNULL(AGL.port,'')		AS [Listener PORT]
	,CASE WHEN AGL.dns_name IS NOT NULL THEN ISNULL(AGL.[ip_configuration_string_from_cluster],'no virtual IP addresses') ELSE '' END
								AS [Cluster IP configuration string]
	,AARP.endpoint_url			AS [Endpoint]
	,AARP.availability_mode_desc AS [Availability Mode]
	,AARP.failover_mode_desc	AS [Failover Mode]
	--,AARP.seeding_mode		AS [Seeding Mode]    not for SQL 2012
	,DRS.operational_state_desc AS [Operational State]
	,DRS.connected_state_desc	AS [Connected State]
	,DRS.synchronization_health_desc AS [Health]
	,sp.name

FROM sys.dm_hadr_availability_replica_states AS HARS WITH (NOLOCK) 
	LEFT JOIN sys.availability_groups AS AG WITH (NOLOCK)
		ON HARS.group_id = AG.group_id --AND HARS.role = 2
	LEFT JOIN sys.availability_group_listeners AGL
		ON AG.group_id = AGL.group_id
	LEFT JOIN sys.dm_hadr_availability_replica_cluster_states AS HARCS 
		ON HARCS.replica_id = HARS.replica_id
	INNER JOIN sys.availability_replicas AARP WITH (NOLOCK)
		ON HARS.replica_id = AARP.replica_id
	INNER JOIN SYS.DM_HADR_AVAILABILITY_REPLICA_STATES DRS WITH (NOLOCK)
		ON HARS.replica_id = DRS.replica_id 
	LEFT JOIN sys.server_principals sp WITH (NOLOCK)
		ON sp.sid = AARP.owner_sid 
WHERE HARS.role_desc = 'PRIMARY'

ORDER BY AGL.dns_name DESC, name, HARS.role_desc