IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##database_role')			DROP TABLE ##database_role

CREATE TABLE ##database_role (
db_name sysname,
role sysname,
username sysname
)


INSERT INTO ##database_role 
	EXEC sp_MSforeachdb 'USE [?] SELECT DB_NAME(), b.name, a.name
					   FROM sysusers a
					   INNER JOIN sysmembers c on a.uid = c.memberuid
					   INNER JOIN sysusers b ON c.groupuid = b.uid
					   WHERE a.name <> ''dbo'' AND a.name not like ''##%''
					   AND b.name in (''db_accessadmin'',''db_backupoperator'',''db_datareader'',''db_datawriter'',''db_ddladmin'',''db_denydatareader'',''db_denydatawriter'',''db_owner'',''db_securityadmin'')
					   ORDER BY b.name, a.name'


SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
	SERVERPROPERTY('MachineName') AS [Host Name],
	db_name as [Database Name],
	role [Role],
	username as [User Name] 
FROM ##database_role