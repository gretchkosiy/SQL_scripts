Select 'Disabled' as Description

/*

IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##index_fragmentation_detail')			DROP TABLE ##index_fragmentation_detail
IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##TempFragmentation')						DROP TABLE ##TempFragmentation

CREATE TABLE ##index_fragmentation_detail(
	db_name sysname, 
	table_name sysname,
	index_size varchar(20), 
	max_fragment varchar(20), 
	avg_fragment varchar(20)
)

 --just for creating table structure
SELECT --#A
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  as Server_Name,
DB_NAME() AS Database_Name,
SCHEMA_NAME(o.Schema_ID) AS Schema_Name,
OBJECT_NAME(s.[object_id]) AS Table_Name,
i.name AS Index_Name,
ROUND(avg_fragmentation_in_percent,2) AS Fragmentation_Percent,
s.page_count AS Page_Count
INTO ##TempFragmentation
FROM sys.dm_db_index_physical_stats(DB_ID(),null, null, null, null) s
INNER JOIN sys.indexes i ON s.[object_id] = i.[object_id]
AND s.index_id = i.index_id
INNER JOIN sys.objects o ON i.object_id = o.object_id
WHERE 1=2

EXEC master.sys.sp_MSforeachdb '
DECLARE @vvchSQL VARCHAR(MAX);
SET @vvchSQL = ''

USE [?];
DECLARE @dbid int
SET @dbid= DB_ID(); 
INSERT INTO ##TempFragmentation
SELECT
CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY(''''MachineName'''')
				ELSE @@SERVERNAME
			END as Server_Name,
DB_NAME() AS Database_Name,
SCHEMA_NAME(o.Schema_ID) AS Schema_Name,
OBJECT_NAME(s.[object_id]) AS Table_Name,
i.name AS Index_Name,
ROUND(avg_fragmentation_in_percent,2) AS Fragmentation_Percent,
s.page_count AS Page_Count
FROM sys.dm_db_index_physical_stats(@dbid,null, null, null, null) s
INNER JOIN sys.indexes i ON s.object_id = i.object_id
AND s.index_id= i.index_id
INNER JOIN sys.objects o ON i.object_id = o.object_id
WHERE 
DB_NAME() <> ''''tempdb''''
AND i.name IS NOT NULL
--AND s.page_count > 1000 --indexes > 8000KB
AND OBJECTPROPERTY(s.object_id, ''''IsMsShipped'''') = 0''; --#C
EXECUTE(@vvchSQL)'



INSERT INTO ##index_fragmentation_detail 
	SELECT Database_Name, Table_Name,
	CONVERT (varchar(20), (SUM(Page_Count) * 8)/1024),
	CONVERT(varchar(20), max(Fragmentation_Percent)),
	CONVERT(varchar(20), avg(Fragmentation_Percent))
	FROM ##TempFragmentation
	--where Fragmentation_Percent >= 30
	group by Database_Name, Table_Name
	order by max(Fragmentation_Percent) DESC, avg(Fragmentation_Percent) DESC



SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
	SERVERPROPERTY('MachineName') AS [Host Name],
	db_name AS [Database Name],
	table_name AS [Table Name],
	index_size AS [Index Size (MB)],
	max_fragment AS [Max Percentage],
	avg_fragment AS [Average Percentage]
FROM ##index_fragmentation_detail


*/