SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
			SERVERPROPERTY('MachineName') AS [Host Name],
			r.name as [Role], 
			p.name AS [User name],
			p.type_desc AS [Type]
		FROM sys.server_principals r
			INNER JOIN sys.server_role_members m ON r.principal_id = m.role_principal_id
			INNER JOIN sys.server_principals p ON p.principal_id = m.member_principal_id
		ORDER BY r.name