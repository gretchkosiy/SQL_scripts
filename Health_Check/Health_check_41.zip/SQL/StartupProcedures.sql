SELECT 
	@@SERVERNAME AS [InstanceName],
	[name] AS [StartupProcedure]
FROM sysobjects
WHERE type = 'P'
AND OBJECTPROPERTY(id, 'ExecIsStartUp') = 1