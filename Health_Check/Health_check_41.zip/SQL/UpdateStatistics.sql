IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##last_updatestatistic')	DROP TABLE ##last_updatestatistic

CREATE TABLE ##last_updatestatistic (
	[Instance Name]  varchar(50),
	[Host Name] sql_variant,
	[Database Name] varchar(255),
	[Last Executed] datetime
)

EXEC sp_MSforeachdb 'USE [?] 
INSERT INTO ##last_updatestatistic 
SELECT CASE 
				WHEN @@SERVERNAME IS NULL THEN  CAST(SERVERPROPERTY(''MachineName'') AS VARCHAR(128))
				ELSE @@SERVERNAME
			END AS [Instance Name], SERVERPROPERTY(''MachineName'') AS [Host Name], DB_NAME() AS [Database Name]
			,
			MIN([Last Executed]) FROM (
SELECT al.name, MAX((STATS_DATE(al.object_id, st.stats_id))) AS [Last Executed], MAX(last_user_update) AS [Last Updated]
FROM sys.stats st
INNER JOIN sys.all_objects al
ON (st.object_id = al.object_id) AND al.name not in(''dtproperties'') AND al.type_desc= ''USER_TABLE''
INNER JOIN sys.dm_db_index_usage_stats iu
ON OBJECT_NAME(iu.OBJECT_ID) = al.name AND iu.database_id= DB_ID()
GROUP BY al.name
) t WHERE ([Last Updated] IS NOT NULL AND [Last Executed] IS NOT NULL)
AND (DATEDIFF(dd, [Last Updated], GETDATE()) >= 7 AND DATEDIFF(dd, [Last Executed], GETDATE()) >= 14)
AND [Last Executed] < [Last Updated]
'
UPDATE ##last_updatestatistic 
SET [Last Executed] = ''
WHERE [Last Executed] is NULL

Select * from ##last_updatestatistic