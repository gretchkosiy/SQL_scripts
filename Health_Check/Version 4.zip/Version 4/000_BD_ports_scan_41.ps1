cls

# 1/08/2023 - credentials added

# https://learn.microsoft.com/en-us/sql/sql-server/install/configure-the-windows-firewall-to-allow-sql-server-access?view=sql-server-ver16
# https://support.solarwinds.com/SuccessCenter/s/article/Use-PowerShell-to-test-that-a-port-is-open-on-a-server?language=en_US

#$Login = "AD\LoginName"
#$password = ConvertTo-SecureString "Password" -AsPlainText -Force
#$Cred = New-Object System.Management.Automation.PSCredential ($Login, $password)
#$Cred = $null # run under current credentials

$ScanType = 'Full' # 'Full' or 'NotFull'

If ($host.Version.Major -lt 5) { Write-Host "Powershell version 5 or higher is required!" -ForegroundColor Red;Break }

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator")) { Write-Host "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"  -ForegroundColor Red; Break }
    
$RunTime = Get-Date  
$ScanReport =  'Hosts_ports_' `
    + $RunTime.Year.ToString() `
    + ("0"+$RunTime.Month.ToString()).SUBSTRING(("0"+$RunTime.Month.ToString()).Length-2) `
    + ("0"+$RunTime.Day.ToString()).SUBSTRING(("0"+$RunTime.Day.ToString()).Length-2) + "_" `
    + ("0"+$RunTime.Hour.ToString()).SUBSTRING(("0"+$RunTime.Hour.ToString()).Length-2) `
    + ("0"+$RunTime.Minute.ToString()).SUBSTRING(("0"+$RunTime.Minute.ToString()).Length-2) `
    + ("0"+$RunTime.Second.ToString()).SUBSTRING(("0"+$RunTime.Second.ToString()).Length-2) `
    + ".txt"

$PathReport = split-path -parent $MyInvocation.MyCommand.Definition 

if ((Test-Path -Path $PathReport ) -ne $true) { Write-Warning "The folder '$PathReport' doesn't exists!"; Break }
if ((Test-Path $PathReport\hosts.txt) -ne $true) { Write-Warning "The file 'hosts.txt' doesn't exists in the folder $Path!"; Break } 

# list of hosts for checking
$Hosts = Get-Content $PathReport\hosts.txt
#$Hosts = @('PCNSHADOW-TEST')


# List of ports to scan
if ($ScanType -eq 'Full') {
    $Ports = @(
                # SET 1 - full list of Ports for SQL Server 
                 1433      # SQL default port
                ,1434      # UDP SQL Server Browser Service  (dynamic ports 49152 to 65535)

                ,21        # not required for BD FTP - replication
                ,135       # inbound WMI port + Port 1024-65535 (inbound) if static ports haven't been configured and you are running Windows checks, Transact-SQL debugger, Microsoft remote procedure calls (MS RPC) 
                ,137,138,139 # not required for BD UDP,UDP,TCP - for replication 

                ,445       # Windows File Sharing
 
                ,80        # TCP for CLEAR_PORT traffic
                ,443       # TCP SSL_PORT traffic.
                ,4022      # not required for BD Service Broker
                ,5022      # not required for BD Database Mirroring
                ,7022      # not required for BD Database Mirroring

                ,5985      # HTTP - required for SQL Server FCI which use mount points. WinRM 
                ,5986      # HTTPs - required for SQL Server FCI which use mount points. 

                ,2383      # The standard port for the default instance of Analysis Services.
                ,2382      # Analysis Services named instance  
            
                ,500,4500  # UDP IPsec traffic

                ,3389      # RDP
                ) 
} else {
    $Ports = @(
                # SET 2 - minimum (?) for BD
                 1433      # SQL default port
                ,1434      # UDP SQL Server Browser Service  (dynamic ports 49152 to 65535)
                ,135       # RPC client-server communication, Transact-SQL debugger, Microsoft remote procedure calls (MS RPC)
                ,139       # used by SMB dialects that communicate over NetBIOS
                ,445       # Windows File Sharing
                ,3389      # RDP
                )

}

$HostNamePortScan = New-Object System.Data.DataTable
$HostNamePortScan.Columns.Add("ComputerName",   "System.String")      | Out-Null  
$HostNamePortScan.Columns.Add("RemotePort",   "System.String")        | Out-Null
$HostNamePortScan.Columns.Add("TcpTestSucceeded", "System.String")    | Out-Null  
#$HostNamePortScan.Columns.Add("AdminShare", "System.String")          | Out-Null   
#$HostNamePortScan.Columns.Add("Login", "System.String")               | Out-Null

Get-Date
$RunningHost = [System.Net.Dns]::GetHostName()
Write-Host "Ports and system shares check script running from $RunningHost" -ForegroundColor Green
Write-Host "Reports location: $PathReport\$ScanReport" -fore Green

$I = $Hosts.Count
$ii = 0 

$WarningPreference = 'SilentlyContinue'
foreach ($HostName in $Hosts) {
    $ii += 1
    if (($HostName -eq '') -or ($HostName.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string 
    Write-Host "Checking $ii of $I - $HostName" -fore Gray

    # Checking admin shares access

<# Path is ton checked

    if ($Cred -eq $null) { 
        try {
            $Login = $Env:UserDomain + '\' + $Env:UserName
            $PathOk = Test-Path -Path \\$HostName\C$  -ErrorAction SilentlyContinue
        } catch {$PathOk = $false}      
     } else {
        try {
            $PathOk = Invoke-Command -ComputerName $HostName -Credential $Cred -Scriptblock {param($p1) Test-Path -Path \\$p1\C$ } -ArgumentList $HostName  -ErrorAction SilentlyContinue
        } catch {$PathOk = $false}
     }

    if ($PathOk -eq $null) {$PathOk = $false}

#>

    foreach ($port in $Ports) {
        # future DEV if (($port -eq '') -or ($port.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string 
        try {
            # Probably some TELNET should be used rather than Test-NetConnection 
            $TestResult = Test-NetConnection -ComputerName $HostName -Port $port # -InformationLevel Quiet #| Out-Null
            $HostNamePortScan.Rows.Add($TestResult.ComputerName, $TestResult.RemotePort, $TestResult.TcpTestSucceeded) | Out-Null
            #$HostNamePortScan.Rows.Add($TestResult.ComputerName, $TestResult.RemotePort, $TestResult.TcpTestSucceeded, $PathOk, $Login) | Out-Null
        } catch {
            $HostNamePortScan.Rows.Add($TestResult.ComputerName, $TestResult.RemotePort, "False") | Out-Null
            #$HostNamePortScan.Rows.Add($TestResult.ComputerName, $TestResult.RemotePort, "False", $PathOk, $Login) | Out-Null
        }
    }
}

$HostNamePortScan | ft -AutoSize  
$HostNamePortScan | Export-Csv -Path $PathReport\$ScanReport -NoTypeInformation
Get-Date
