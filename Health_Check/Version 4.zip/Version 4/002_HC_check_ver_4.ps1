﻿cls 

# 20/07/2023

# Location 
# 471 - query list
# 1570 - query text

# 2150 - resultset population 
# 2600 - CSV

 $RunTime = Get-Date  
 $RunTime
 "Start HC"

# Get current Location
$MyPath = split-path -parent $MyInvocation.MyCommand.Definition 
#$MyPath = "C:\BCS_HC\Version 3\PowerShell_scripts\"

$ScriptsPath = "$MyPath\SQL\"
$CSVPath = "$MyPath\Reports\"

$Path = $MyPath
$Client = "AAL"

$RunIndexFragmentation = $false
$Instances  = Get-Content $Path\instances.txt
$ServerList = Get-Content $Path\hosts.txt

# $HostName = [System.Net.Dns]::GetHostName()

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
    [Security.Principal.WindowsBuiltInRole] "Administrator"))
    {
        Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
        Break
    }

if ((Test-Path $Path\hosts.txt) -ne $true)  {
        Write-Warning "The file 'hosts.txt' doesn't exists in the folder $Path!"
        Break
    } 

if ((Test-Path $Path\instances.txt) -ne $true)  {
        Write-Warning "The file 'hosts.txt' doesn't exists in the folder $Path!"
        Break
    } 

Write-Host "Script location: $MyPath" -fore Green

$LogFile = "$CSVPath\HC_log_" `
+ $RunTime.Year.ToString() `
+ ("0"+$RunTime.Month.ToString()).SUBSTRING(("0"+$RunTime.Month.ToString()).Length-2) `
+ ("0"+$RunTime.Day.ToString()).SUBSTRING(("0"+$RunTime.Day.ToString()).Length-2) + "_" `
+ ("0"+$RunTime.Hour.ToString()).SUBSTRING(("0"+$RunTime.Hour.ToString()).Length-2) `
+ ("0"+$RunTime.Minute.ToString()).SUBSTRING(("0"+$RunTime.Minute.ToString()).Length-2) `
+ ("0"+$RunTime.Second.ToString()).SUBSTRING(("0"+$RunTime.Second.ToString()).Length-2) `
+ ".txt"

"$RunTime - Start HC" | Out-File -append $LogFile 

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | Out-Null

##############

Function Invoke-Sqlcmd2 
{ 
    [CmdletBinding()] 
    param ( 
        [Parameter(Position=0, Mandatory=$true)] [string]$ServerInstance, 
        [Parameter(Position=1, Mandatory=$false)] [string]$Database, 
        [Parameter(Position=2, Mandatory=$false)] [string]$Query, 
        [Parameter(Position=3, Mandatory=$false)] [string]$Username, 
        [Parameter(Position=4, Mandatory=$false)] [string]$Password, 
        [Parameter(Position=5, Mandatory=$false)] [Int32]$QueryTimeout=600, 
        [Parameter(Position=6, Mandatory=$false)] [Int32]$ConnectionTimeout=15, 
        [Parameter(Position=7, Mandatory=$false)] [ValidateScript({test-path $_})] [string]$InputFile, 
        [Parameter(Position=8, Mandatory=$false)] [ValidateSet("DataSet", "DataTable", "DataRow", "DataValue")] [string]$As="DataRow" 
    )
 
    if ($InputFile) { 
        $filePath = $(resolve-path $InputFile).path 
        $Query =  [System.IO.File]::ReadAllText("$filePath") 
    } 
 
    $conn=new-object System.Data.SqlClient.SQLConnection 
      
    if ($Username) { 
        $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance,$Database,$Username,$Password,$ConnectionTimeout 
    } else { 
        $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout 
    }
    $conn.ConnectionString=$ConnectionString 
     
    #Following EventHandler is used for PRINT and RAISERROR T-SQL statements. Executed when -Verbose parameter specified by caller 
    if ($PSBoundParameters.Verbose) { 
        $conn.FireInfoMessageEventOnUserErrors=$true 
        $handler = [System.Data.SqlClient.SqlInfoMessageEventHandler] { 
            #Write-Verbose "$($_)"
        } 
        $conn.add_InfoMessage($handler) 
    } 

    try {      
        $conn.Open() 
        $cmd=new-object system.Data.SqlClient.SqlCommand($Query,$conn) 
        $cmd.CommandTimeout=$QueryTimeout 
        $ds=New-Object system.Data.DataSet 
        $da=New-Object system.Data.SqlClient.SqlDataAdapter($cmd) 
        [void]$da.fill($ds) 
        $conn.Close() 
        } catch { 
            throw $_.Exception
            continue 
        } 

        switch ($As) 
        { 
            'DataSet'   { Write-Output ($ds) } 
            'DataTable' { Write-Output ($ds.Tables) } 
            'DataRow'   { Write-Output ($ds.Tables[0]) } 
            'DataValue' { Write-Output ($ds.Tables[0].Rows[0].Column1) } 
        }
 
} #Invoke-Sqlcmd2

Function Write-DataTable 
{ 
    [CmdletBinding()] 
    param ( 
    [Parameter(Position=0, Mandatory=$true)] [string]$ServerInstance, 
    [Parameter(Position=1, Mandatory=$true)] [string]$Database, 
    [Parameter(Position=2, Mandatory=$true)] [string]$TableName, 
    [Parameter(Position=3, Mandatory=$true)] $Data, 
    [Parameter(Position=4, Mandatory=$false)] [string]$Username, 
    [Parameter(Position=5, Mandatory=$false)] [string]$Password, 
    [Parameter(Position=6, Mandatory=$false)] [Int32]$BatchSize=50000, 
    [Parameter(Position=7, Mandatory=$false)] [Int32]$QueryTimeout=0, 
    [Parameter(Position=8, Mandatory=$false)] [Int32]$ConnectionTimeout=15 
    ) 
     
    $conn=new-object System.Data.SqlClient.SQLConnection 
 
    if ($Username) { 
        $ConnectionString = "Server={0};Database={1};User ID={2};Password={3};Trusted_Connection=False;Connect Timeout={4}" -f $ServerInstance,$Database,$Username,$Password,$ConnectionTimeout 
    } else { 
        $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout 
    } 
    $conn.ConnectionString=$ConnectionString 
 
    try {  
        $conn.Open() 
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $connectionString 
        $bulkCopy.DestinationTableName = $tableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut 
        $bulkCopy.WriteToServer($Data) 
        $conn.Close() 
    } catch { 
        throw $_.Exception
        #Write-Error $_.Exception
        continue 
    } 
 
} #Write-DataTable

####################

 $Path = $Path + "\"

$AAG_A = @(
    (
    'AAG_Jobs',
    'AAG_credentials',
    'AAG_triggers',
    'AAG_procedures',
    'AAG_endpoints',
    'AAG_notifications',
    'AAG_EXproc',
	'AAG_logins',
    'AAG_CrossDatabaseQueries',
    'AAG_ServerOptions',
    'AAG_DBowner',
    'AAG_LS',
    'AAG_MSG',
    'AAG_Roles',
    'AAG_Permissions'

    ),
    (
    'SELECT @@SERVERNAME AS [InstanceName], name AS [JobName] FROM msdb.dbo.sysjobs WHERE category_id <> 100',
    "SELECT @@SERVERNAME AS [InstanceName], Name FROM master.sys.credentials WHERE name NOT LIKE '`%DBMKEY_`%'",
    'SELECT @@SERVERNAME AS [InstanceName], Name FROM master.sys.server_triggers',
    'SELECT @@SERVERNAME AS [InstanceName], Name FROM master.sys.sysobjects WHERE type = ''P'' AND OBJECTPROPERTY(id, ''ExecIsStartUp'') = 1',
    'SELECT @@SERVERNAME AS [InstanceName], Name FROM sys.endpoints',
    'SELECT @@SERVERNAME AS [InstanceName], Name FROM sys.server_event_notifications ',
    'SELECT @@SERVERNAME AS [InstanceName], Name FROM master.sys.extended_procedures',
	'SELECT @@SERVERNAME AS [InstanceName], SP.name AS [Name], SP.sid fROM sys.server_principals AS SP LEFT JOIN sys.sql_logins AS SL ON SP.principal_id = SL.principal_id WHERE SP.type_desc IN (''SQL_LOGIN'',''WINDOWS_GROUP'',''WINDOWS_LOGIN'') AND SP.name NOT LIKE ''##%##'' AND SP.name NOT LIKE ''NT SERVICE\%'' AND SP.name NOT LIKE ''NT AUTHORITY\%'' AND SP.name NOT IN (''SA'')',    
    'SELECT @@SERVERNAME AS [InstanceName], Name, is_trustworthy_on, is_db_chaining_on from sys.databases',
    'SELECT @@SERVERNAME AS [InstanceName], Name, value, minimum, maximum, value_in_use FROM sys.configurations',
    'SELECT @@SERVERNAME AS [InstanceName], Name, suser_sname(owner_sid) as [DBowner] from sys.databases',
    'SELECT @@SERVERNAME AS [InstanceName], Name, provider, data_source from sys.servers where is_linked = 1',
    'SELECT @@SERVERNAME AS [InstanceName], message_id, language_id, severity, is_event_logged, CAST(text as sysname) from sys.messages',
    'SELECT @@SERVERNAME AS [InstanceName], role.name AS RoleName, member.name AS MemberName FROM sys.server_role_members JOIN sys.server_principals AS role ON sys.server_role_members.role_principal_id = role.principal_id JOIN sys.server_principals AS member ON sys.server_role_members.member_principal_id = member.principal_id',
    'SELECT
	@@SERVERNAME AS [InstanceName],  
	SS.name,
	SP.class,
	SP.type,
	SP.permission_name,
	SP.state,
	SS.is_disabled
FROM sys.server_permissions SP INNER JOIN sys.server_principals SS on SS.principal_id = SP.grantee_principal_id'
    )
        ,
    (
    '',
    '',
    '',
    '',
    '',
    '',
    '',          
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_logins'') CREATE TABLE tempdb.dbo.AAG_logins([InstanceName] [sysname] NOT NULL,[Name] [sysname] NULL, sid varbinary(85) NULL);TRUNCATE TABLE tempdb.dbo.AAG_logins',
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_CrossDatabaseQueries'') CREATE TABLE tempdb.dbo.AAG_CrossDatabaseQueries([InstanceName] [sysname] NOT NULL,[Name] [sysname] NULL, is_trustworthy_on bit, is_db_chaining_on bit);TRUNCATE TABLE tempdb.dbo.AAG_CrossDatabaseQueries',
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_ServerOptions'') CREATE TABLE tempdb.dbo.AAG_ServerOptions([InstanceName] [sysname] NOT NULL,[Name] [sysname] NULL, value INT, minimum INT, maximum INT, value_in_use INT);TRUNCATE TABLE tempdb.dbo.AAG_ServerOptions',
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_DBowner'') CREATE TABLE tempdb.dbo.AAG_DBowner([InstanceName] [sysname] NOT NULL,[Name] [sysname] NULL, [DBowner] nvarchar(128) NULL);TRUNCATE TABLE tempdb.dbo.AAG_DBowner',
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_LS'') CREATE TABLE tempdb.dbo.AAG_LS([InstanceName] [sysname] NOT NULL,[Name] [sysname] NULL,provider [sysname] NULL, data_source nvarchar(4000) NULL);TRUNCATE TABLE tempdb.dbo.AAG_LS',
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_MSG'') CREATE TABLE tempdb.dbo.AAG_MSG([InstanceName] [sysname] NOT NULL, message_id  [int] NULL, language_id  [smallint] NULL, severity  [int] NULL, is_event_logged  [bit] NULL, text nvarchar(2048) NULL);TRUNCATE TABLE tempdb.dbo.AAG_MSG',
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_Roles'') CREATE TABLE tempdb.dbo.AAG_Roles([InstanceName] [sysname] NOT NULL, RoleName [sysname] NULL, MemberName [sysname] NULL);TRUNCATE TABLE tempdb.dbo.AAG_Roles', 
    'IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = ''AAG_Permissions'') CREATE TABLE tempdb.dbo.AAG_Permissions([InstanceName] [sysname] NOT NULL, name [sysname] NULL, class [tinyint] NULL, type char(4) NULL, [permission_name] nvarchar(128) NULL, state char(1) NULL, is_disabled [int] NULL);TRUNCATE TABLE tempdb.dbo.AAG_Permissions' 
    
    )
)

$SQL_BD_RS = "


select 'Jobs' AS ObjName, [InstanceName], name
from (	
    SELECT MAX([InstanceName]) AS InstanceName , name
    FROM tempdb.dbo.AAG_Jobs
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_Jobs) S)) U
UNION
select 'Linked Server' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_LS
    GROUP BY Name, 
        provider
        ,data_source
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_LS) S)) u

UNION
select 'Login' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name, sid
    FROM tempdb.dbo.AAG_logins
    GROUP BY Name, sid
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_logins) S)) u

UNION
select 'Notification' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_notifications
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_notifications) S)) u


UNION
select 'Extended Procedure' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_EXproc
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_EXproc) S)
  ) u

UNION
select DISTINCT 'Credential' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_credentials
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_credentials) S)) u


UNION
select 'Trigger' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_triggers
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_triggers) S)
  ) u

UNION
select 'Procedure' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_procedures
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_procedures) S)
  ) u

UNION
select 'End-point' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_endpoints
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_endpoints) S)
  ) u

UNION
select 'Cross-Database' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_CrossDatabaseQueries
    WHERE Name in (Select distinct dg.Database_name
					from master.sys.dm_hadr_database_replica_cluster_states dg
					INNER join master.sys.availability_replicas ar on ar.replica_id = dg.replica_id
					lEFT join master.sys.availability_groups ag on ag.group_id = ar.group_id
					WHERE ag.name IN (select distinct ag.name as [name]
									from sys.dm_hadr_availability_replica_states ars
									inner join sys.availability_groups ag on ag.group_id = ars.group_id 
									where ars.role_desc = 'PRIMARY'))
    GROUP BY Name, [is_trustworthy_on],[is_db_chaining_on]
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_CrossDatabaseQueries) S)
  ) u

UNION
select 'Server Option' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_ServerOptions
    GROUP BY Name, value, minimum, maximum, value_in_use
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_ServerOptions) S)
  ) u


UNION
select 'Database Owner' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_DBowner
    WHERE Name in (Select distinct dg.Database_name
					from master.sys.dm_hadr_database_replica_cluster_states dg
					INNER join master.sys.availability_replicas ar on ar.replica_id = dg.replica_id
					lEFT join master.sys.availability_groups ag on ag.group_id = ar.group_id
					WHERE ag.name IN (select distinct ag.name as [name]
									from sys.dm_hadr_availability_replica_states ars
									inner join sys.availability_groups ag on ag.group_id = ars.group_id 
									where ars.role_desc = 'PRIMARY'))

    GROUP BY Name, DBowner
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_DBowner) S)
  ) u


UNION
select 'Message' AS ObjName, InstanceName, CAST(message_id AS nVARCHAR(max)) AS Name
 from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName,  message_id 
    FROM tempdb.dbo.AAG_MSG
    GROUP BY message_id
	,language_id
	,severity
	,is_event_logged
	,text
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_MSG) S)
  ) u


UNION
select 'Role' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName,  RoleName + ' ' + MemberName AS Name 
    FROM tempdb.dbo.AAG_Roles
    GROUP BY RoleName, MemberName 
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_Roles) S)) u


UNION
select 'Permission' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName, [name]
    FROM tempdb.dbo.AAG_Permissions
    GROUP BY [name]
      ,[class]
      ,[type]
      ,[permission_name]
      ,[state]
      ,[is_disabled]
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_Permissions) S)
  ) u
"




####################

$tableName = "Last_Backup_Table"
$SQL_Temp_table_create = "IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = '$tableName') CREATE TABLE tempdb.dbo.$tableName([name] [sysname] NOT NULL,RM varchar(20),[AAGname] [sysname] NULL, [LastBackUpTime_FULL] [datetime] NULL, [LastBackUpTime_LOG] [datetime] NULL);TRUNCATE TABLE tempdb.dbo.$tableName"
$SQL_Temp_table_drop = "IF EXISTS (select 1 from tempdb.dbo.sysobjects where name = '$tableName') DROP TABLE tempdb.dbo.$tableName"

$SQL_Last_backup_NOAAG = "SELECT t1.name, databasepropertyex(t1.name, 'Recovery') as RM,
            '-' AS [AAGname],
	        DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus1.backup_finish_date)) AS LastBackUpTime_FULL,
	        DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus.backup_finish_date))  AS LastBackUpTime_LOG
            FROM master.dbo.sysdatabases t1 
	        LEFT OUTER JOIN msdb.dbo.backupset bus ON bus.database_name = t1.name AND bus.type= 'L' 
	        LEFT OUTER JOIN msdb.dbo.backupset bus1 ON bus1.database_name = t1.name AND (bus1.type= 'D' OR bus1.type= 'I')
            where t1.name not in ('tempdb') 
            AND t1.dbid not in (select database_id from  sys.dm_hadr_database_replica_states)
            AND databasepropertyex(t1.name,'status')= 'ONLINE'
            AND DATEDIFF(dd,t1.crdate,getdate()) >= 1 
            GROUP BY t1.name"

$SQL_Last_backup_SQL08 = "SELECT 
	        t1.name, 
	        databasepropertyex(t1.name, 'Recovery') as RM,
            '-' AS [AAGname],
	        DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus1.backup_finish_date)) AS LastBackUpTime_FULL,
	        DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus.backup_finish_date)) AS LastBackUpTime_LOG
            FROM master.dbo.sysdatabases t1 
	        LEFT OUTER JOIN msdb.dbo.backupset bus ON bus.database_name = t1.name AND bus.type= 'L' 
	        LEFT OUTER JOIN msdb.dbo.backupset bus1 ON bus1.database_name = t1.name AND (bus1.type= 'D' OR bus1.type= 'I')
            where t1.name not in ('tempdb') 
            AND databasepropertyex(t1.name,'status')= 'ONLINE'
            AND DATEDIFF(dd,t1.crdate,getdate()) >= 1
            GROUP BY t1.name"

# return list of availabe AAGs
<#
$SQL_List_AAGs = "select distinct ag.name as [name]
            from sys.dm_hadr_availability_replica_states ars
	        inner join sys.availability_groups ag on ag.group_id = ars.group_id 
            where ars.role_desc = 'PRIMARY'"
#>
$SQL_List_AAGs = "IF (SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)),1,CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)))-1) > 10)
	select distinct ag.name as [name]
    from sys.dm_hadr_availability_replica_states ars
	inner join sys.availability_groups ag on ag.group_id = ars.group_id 
    where ars.role_desc = 'PRIMARY'"

# final query for SQL 2012 and older
$SQL_Last_backup_ALL_REPLICAS = "
SELECT @@SERVERNAME AS InstaneName, 'Full' as [type], [name], RM, AAGname, MAX(LastBackUpTime_FULL) AS [Last Backup]
FROM tempdb.dbo.$tableName 
GROUP BY  [name],[AAGname], RM
UNION 
SELECT @@SERVERNAME AS InstaneName, 'Tran' as [type], [name], RM, AAGname, MAX(LastBackUpTime_LOG) AS [Last Backup]
FROM tempdb.dbo.$tableName 
WHERE RM <> 'SIMPLE'
GROUP BY  [name],[AAGname], RM"
 
# final query for SQL 2000-2008 
 $SQL_Last_backup_SQL2000 = "
SELECT @@SERVERNAME AS InstaneName, 'Full' as [type], [name], RM, AAGname, MAX(LastBackUpTime_FULL) AS [Last Backup]
FROM tempdb.dbo.$tableName 
GROUP BY  [name],[AAGname], RM
UNION 
--SELECT @dbListTL = @dbListTL  + ', ' + [name]
SELECT @@SERVERNAME AS InstaneName, 'Tran' as [type], [name], RM, AAGname, MAX(LastBackUpTime_LOG) AS [Last Backup]
FROM tempdb.dbo.$tableName 
WHERE RM <> 'SIMPLE'
GROUP BY  [name],[AAGname], RM"
  
##############

[reflection.assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | out-null
        $InstTable = New-Object System.Data.DataTable
        $InstTable.Columns.Add("ID",       "System.Int32")     | Out-Null   
        $InstTable.Columns.Add("Host Name","System.String")    | Out-Null  
	    $InstTable.Columns.Add("Instance Name","System.String")| Out-Null  
        $InstTable.Columns.Add("Type",     "System.String")    | Out-Null   
        $InstTable.Columns.Add("Value",    "System.String")    | Out-Null  
        $InstTable.Columns.Add("Client",    "System.String")   | Out-Null  
        $InstTable.Columns.Add("timestamp", "System.DateTime") | out-null

#AAG  -- Actually BAG only
       $AAG = New-Object System.Data.DataTable
        $AAG.Columns.Add("Role",			"System.String")     | Out-Null 
        $AAG.Columns.Add("Server Name",			"System.String")     | Out-Null 
        $AAG.Columns.Add("AAG name",			"System.String")     | Out-Null   
        $AAG.Columns.Add("Listener DNS name",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Listener PORT",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Cluster IP configuration string",	"System.String")    | Out-Null  
#        $AAG.Columns.Add("Primary node",	"System.String")    | Out-Null  
#        $AAG.Columns.Add("Secondary node",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Endpoint",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Availability Mode",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Failover Mode",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Seeding Mode",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Operational State",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Connected State",	"System.String")    | Out-Null  
        $AAG.Columns.Add("Health",	"System.String")    | Out-Null  

####################

#Drives
        $driveTable = New-Object System.Data.DataTable
        $driveTable.Columns.Add("Host Name",   "System.String")   | Out-Null
        $driveTable.Columns.Add("DeviceID",    "System.String")   | Out-Null
        $driveTable.Columns.Add("VolumeName",  "System.String")   | Out-Null
        $driveTable.Columns.Add("Size",        "System.Int64")    | Out-Null
        $driveTable.Columns.Add("FreeSpace",   "System.Int64")    | Out-Null
        $driveTable.Columns.Add("Client",      "System.String")   | Out-Null
        $driveTable.Columns.Add("timestamp",   "System.DateTime") | Out-Null
#OS
        $OSTable = New-Object System.Data.DataTable
        $OSTable.Columns.Add("ID",       "System.Int32")     | Out-Null   
        $OSTable.Columns.Add("Host Name","System.String")    | Out-Null  
	    $OSTable.Columns.Add("Instance Name","System.String")| Out-Null  
        $OSTable.Columns.Add("Type",     "System.String")    | Out-Null   
        $OSTable.Columns.Add("Value",    "System.String")    | Out-Null  
        $OSTable.Columns.Add("Client",    "System.String")   | Out-Null  
        $OSTable.Columns.Add("timestamp", "System.DateTime") | out-null
#Services
        $serviceTable = New-Object System.Data.DataTable
        $serviceTable.Columns.Add("Host Name",     "System.String")    | Out-Null   
        $serviceTable.Columns.Add("Service Name",  "System.String")    | Out-Null  
        $serviceTable.Columns.Add("Account",       "System.String")    | Out-Null
        $serviceTable.Columns.Add("Startup",       "System.String")    | Out-Null 
        $serviceTable.Columns.Add("Status",        "System.String")    | Out-Null
        $serviceTable.Columns.Add("PathName",      "System.String")    | Out-Null
        $serviceTable.Columns.Add("Client",        "System.String")    | Out-Null
        $serviceTable.Columns.Add("timestamp",     "System.DateTime")  | Out-Null
#System
        $InstanceTable = New-Object System.Data.DataTable
        $InstanceTable.Columns.Add("ID",       "System.Int32")     | Out-Null   
        $InstanceTable.Columns.Add("Host Name","System.String")    | Out-Null  
	    $InstanceTable.Columns.Add("Instance Name","System.String")| Out-Null  
        $InstanceTable.Columns.Add("Type",     "System.String")    | Out-Null   
        $InstanceTable.Columns.Add("Value",    "System.String")    | Out-Null  
        $InstanceTable.Columns.Add("Client",    "System.String")   | Out-Null  
        $InstanceTable.Columns.Add("timestamp", "System.DateTime") | out-null
#LIM_IFI

        $LimIfiTable = New-Object System.Data.DataTable
        $LimIfiTable.Columns.Add("Host Name", "System.String")     | Out-Null  
        $LimIfiTable.Columns.Add("Service", "System.String")       | Out-Null  
        $LimIfiTable.Columns.Add("Name", "System.String")          | Out-Null
        $LimIfiTable.Columns.Add("User", "System.String")          | Out-Null
        $LimIfiTable.Columns.Add("LockPages", "System.Int32")      | Out-Null
        $LimIfiTable.Columns.Add("InstantInit", "System.Int32")    | Out-Null
        #$LimIfiTable.Columns.Add("Client",    "System.String")     | Out-Null  
        #$LimIfiTable.Columns.Add("timestamp", "System.DateTime")   | out-null

#IPs
$IPTable = New-Object System.Data.DataTable
$IPTable.Columns.Add("InstanceName", "System.String")    | Out-Null 
$IPTable.Columns.Add("IPname",       "System.String")    | Out-Null    
$IPTable.Columns.Add("Active",       "System.String")    | Out-Null  
$IPTable.Columns.Add("Enabled",      "System.String")    | Out-Null  
$IPTable.Columns.Add("IPaddress",    "System.String")    | Out-Null  
$IPTable.Columns.Add("Dynamic",      "System.String")    | Out-Null  
$IPTable.Columns.Add("port",         "System.String")    | Out-Null  
$IPTable.Columns.Add("DisplayName",  "System.String")    | Out-Null  


 $newRunTime =  Get-Date 
 "$newRunTime - Start HOSTs loop" | Out-File -append $LogFile 

Write-Host  "Start HOSTs loop" -fore green


# Loop through HOSTs
foreach ($HostName in $ServerList)
{
    $Server = $HostName 

    if (($Server -eq '') -or ($Server.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string 

    Write-Host  "Host processing: $HostName" -fore green

#Drives
    $newRunTime =  Get-Date 
    "$newRunTime - Host '$Server' Drives processing" | Out-File -append $LogFile 
        # Get drive info from System

    if ($Server -eq [System.Net.Dns]::GetHostName()) {
        $drives = Get-WmiObject Win32_LogicalDisk | where {$_.DriveType -like 3 -or $_.DriveType -like 4 } | Select SystemName, DeviceID, VolumeName, Size, FreeSpace
    } else {
        $drives = Get-WmiObject Win32_LogicalDisk -computer $HostName | where {$_.DriveType -like 3 -or $_.DriveType -like 4 } | Select SystemName, DeviceID, VolumeName, Size, FreeSpace
    }

        # https://msdn.microsoft.com/en-us/library/aa394173(v=vs.85).aspx  - Local Disk (3), Network Drive (4)
 
        # Insert data for $drives into $driveTable - this is the RBAR bit
        foreach ($drive in $drives)
        {
            $txt = $drive.DeviceID
            Write-Host  "Instance '$Server' drive processing: '$txt'" -fore Gray

            # Test for Null Values
            if ($drive.SystemName -eq $null) { $drive.SystemName = "" }
            if ($drive.DeviceID -eq $null) { $drive.DeviceID = "" }
            if ($drive.VolumeName -eq $null) { $drive.VolumeName = "" }
            if ($drive.Size -eq $null) { $drive.Size = 0 }
            if ($drive.FreeSpace -eq $null) { $drive.FreeSpace = 0 }

            $driveTable.Rows.Add($drive.SystemName, $drive.DeviceID, $drive.VolumeName, $drive.Size, $drive.FreeSpace, $Client, $RunTime) | Out-Null
        }

#OS
    $newRunTime =  Get-Date 
    "$newRunTime - Host '$Server' OS processing" | Out-File -append $LogFile 
    Write-Host  "Instance '$Server' OS configuration" -fore Gray

    if ($Server -eq [System.Net.Dns]::GetHostName()) {
        $hardware = gwmi Win32_operatingSystem  
    } else {
        $hardware = gwmi Win32_operatingSystem  -computername $HostName 
    }
        
        $OSTable.Rows.Add(1, $HostName, $Server, 'SystemDirectory', $hardware.SystemDirectory, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(2, $HostName, $Server, 'OS Version', $hardware.Version, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(3, $HostName, $Server, 'OS Caption', $hardware.Caption, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(4, $HostName, $Server, 'OS Architecture', $hardware.OSArchitecture, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(5, $HostName, $Server, 'OS SP', $hardware.ServicePackMajorVersion, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(6, $HostName, $Server, 'ServicePackMinorVersion', $hardware.ServicePackMinorVersion, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(7, $HostName, $Server, 'FreePhysicalMemory', $hardware.FreePhysicalMemory, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(8, $HostName, $Server, 'TotalVirtualMemorySize', $hardware.TotalVirtualMemorySize, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(9, $HostName, $Server, 'TotalVisibleMemorySize', $hardware.TotalVisibleMemorySize, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(10, $HostName, $Server, 'FreeVirtualMemory', $hardware.FreeVirtualMemory, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(11, $HostName, $Server, 'CodeSet', $hardware.CodeSet, $Client, $RunTime) | Out-Null
        #$OSTable.Rows.Add(12, $HostName, $Server, 'CountryCode', $hardware.CountryCode, $Client, $RunTime) | Out-Null
        #$OSTable.Rows.Add(13, $HostName, $Server, 'CurrentTimeZone', $hardware.CurrentTimeZone, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(14, $HostName, $Server, 'InstallDate', $hardware.InstallDate, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(15, $HostName, $Server, 'LastBootUpTime', $hardware.LastBootUpTime, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(16, $HostName, $Server, 'SizeStoredInPagingFiles', $hardware.SizeStoredInPagingFiles, $Client, $RunTime) | Out-Null
        $OSTable.Rows.Add(17, $HostName, $Server, 'FreeSpaceInPagingFiles', $hardware.FreeSpaceInPagingFiles, $Client, $RunTime) | Out-Null

        $hardware = gwmi Win32_PageFileusage  -computername $HostName  | Select AllocatedBaseSize # ????
        $OSTable.Rows.Add(18, $HostName, $Server,'Page file size', $hardware.AllocatedBaseSize, $Client, $RunTime) | Out-Null

		# local admins
		$admins = Gwmi win32_groupuser –computer $HostName   
		$admins = $admins |? {$_.groupcomponent –like '*"Administrators"'}  
 		$admins |% {  
			$_.partcomponent –match “.+Domain\=(.+)\,Name\=(.+)$” > $nul  
			$OSTable.Rows.Add(19, $HostName, $Server, 'Local admin', $matches[1].trim('"') + “\” + $matches[2].trim('"'), $Client, $RunTime) | Out-Null
		} 
#Services
    $newRunTime =  Get-Date 
    "$newRunTime - Host '$Server' Services processing" | Out-File -append $LogFile 
    Write-Host  "Instance '$Server' Services" -fore Gray

    if ($Server -eq [System.Net.Dns]::GetHostName()) {
        $Services=gwmi win32_service | where {($_.Name -like ‘*SQL*’ -or $_.Name -like "ns*" -or $_.Name -like "*MSOLAP*" -or $_.Name -like "Report*" -or $_.Name -like "MSDT*") -and $_.Name -ne "nsi" } | SELECT PSComputerName, name, startname, StartMode, State, PathName 
    } else {
        $Services=gwmi win32_service -computername $HostName | where {($_.Name -like ‘*SQL*’ -or $_.Name -like "ns*" -or $_.Name -like "*MSOLAP*" -or $_.Name -like "Report*" -or $_.Name -like "MSDT*") -and $_.Name -ne "nsi" } | SELECT PSComputerName, name, startname, StartMode, State, PathName 
    } 

       # Get drive info from System
       # $Services=gwmi win32_service -computername $HostName | where {($_.Name -like ‘*SQL*’ -or $_.Name -like "ns*" -or $_.Name -like "*MSOLAP*" -or $_.Name -like "Report*" -or $_.Name -like "MSDT*") -and $_.Name -ne "nsi" } | SELECT PSComputerName, name, startname, StartMode, State, PathName 

        # Insert data for $drives into $serviceTable - this is the RBAR bit
        foreach ($service in $services)
        { $serviceTable.Rows.Add($service.PSComputerName, $service.name, $service.startname, $service.StartMode, $service.State, $service.PathName, $Client, $RunTime) | Out-Null }
#System
    $newRunTime =  Get-Date 
    "$newRunTime - Host '$Server' System processing" | Out-File -append $LogFile 
    Write-Host  "Instance '$Server' System" -fore Gray

    if ($Server -eq [System.Net.Dns]::GetHostName()) {
        $hardware = gwmi Win32_bios 
        $InstanceTable.Rows.Add(1, $HostName, $Server, 'Manufacturer', $hardware.Manufacturer, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(2, $HostName, $Server, 'SerialNumber', $hardware.SerialNumber, $Client, $RunTime) | Out-Null

        $hardware = gwmi Win32_computerSystem 
        $InstanceTable.Rows.Add(3, $HostName, $Server, 'Model', $hardware.Model, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(4, $HostName, $Server, 'Domain', $hardware.Domain, $Client, $RunTime) | Out-Null

		$totalmemory =  gwmi Win32_PhysicalMemory  |  Measure-Object -Property capacity -Sum | Foreach {"{0:N2}" -f ([math]::round(($_.Sum / 1GB),2))}
        $InstanceTable.Rows.Add(5, $HostName, $Server, 'TotalPhysicalMemory', $totalmemory, $Client, $RunTime) | Out-Null

        $InstanceTable.Rows.Add(6, $HostName, $Server, 'EnableDaylightSavingsTime', $hardware.EnableDaylightSavingsTime, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(7, $HostName, $Server, 'NumberOfProcessors', $hardware.NumberOfProcessors, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(8, $HostName, $Server, 'NumberOfLogicalProcessors', $hardware.NumberOfLogicalProcessors, $Client, $RunTime) | Out-Null

        $hardware = gwmi Win32_processor 
    } else {
        $hardware = gwmi Win32_bios -computername $HostName 
        $InstanceTable.Rows.Add(1, $HostName, $Server, 'Manufacturer', $hardware.Manufacturer, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(2, $HostName, $Server, 'SerialNumber', $hardware.SerialNumber, $Client, $RunTime) | Out-Null

        $hardware = gwmi Win32_computerSystem -computername $HostName
        $InstanceTable.Rows.Add(3, $HostName, $Server, 'Model', $hardware.Model, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(4, $HostName, $Server, 'Domain', $hardware.Domain, $Client, $RunTime) | Out-Null

		$totalmemory =  gwmi Win32_PhysicalMemory -computername $HostName |  Measure-Object -Property capacity -Sum | Foreach {"{0:N2}" -f ([math]::round(($_.Sum / 1GB),2))}
        $InstanceTable.Rows.Add(5, $HostName, $Server, 'TotalPhysicalMemory', $totalmemory, $Client, $RunTime) | Out-Null

        $InstanceTable.Rows.Add(6, $HostName, $Server, 'EnableDaylightSavingsTime', $hardware.EnableDaylightSavingsTime, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(7, $HostName, $Server, 'NumberOfProcessors', $hardware.NumberOfProcessors, $Client, $RunTime) | Out-Null
        $InstanceTable.Rows.Add(8, $HostName, $Server, 'NumberOfLogicalProcessors', $hardware.NumberOfLogicalProcessors, $Client, $RunTime) | Out-Null

        $hardware = gwmi Win32_processor -computername $HostName 
    } 


		if($HostName.Version.Major -ge 3){
			$InstanceTable.Rows.Add(9, $HostName, $Server, 'CPU', $hardware.Caption[1], $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(10, $HostName, $Server, 'CPU Manufacturer', $hardware.Manufacturer[1], $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(11, $HostName, $Server, 'CPU Name', $hardware.Name[1], $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(11, $HostName, $Server, 'CPU Description', $hardware.Description[1], $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(12, $HostName, $Server, 'CPU MaxClockSpeed', $hardware.MaxClockSpeed[1], $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(13, $HostName, $Server, 'CPU NumberOfCores', $hardware.NumberOfCores[1], $Client, $RunTime) | Out-Null
		} else {
			$InstanceTable.Rows.Add(9, $HostName, $Server, 'CPU', $hardware.Caption, $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(10, $HostName, $Server, 'CPU Manufacturer', $hardware.Manufacturer, $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(11, $HostName, $Server, 'CPU Name', $hardware.Name, $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(11, $HostName, $Server, 'CPU Description', $hardware.Description, $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(12, $HostName, $Server, 'CPU MaxClockSpeed', $hardware.MaxClockSpeed, $Client, $RunTime) | Out-Null
			$InstanceTable.Rows.Add(13, $HostName, $Server, 'CPU NumberOfCores', $hardware.NumberOfCores, $Client, $RunTime) | Out-Null
		}

#LIM_IFI - need loop through instances!!!!


     $newRunTime =  Get-Date 
     "$newRunTime - Host '$Server' LIM_IFI processing" | Out-File -append $LogFile 
     Write-Host  "Instance '$Server' LIM_IFI" -fore Gray

    if ($Server -eq [System.Net.Dns]::GetHostName()) {
# for local host
            #Set-Location C:\Temp\
            $LocalSvr = get-content env:computername
            $procs = Get-CimInstance -Query 'Select * from Win32_Process where name like "%sqlservr.exe%"'

            $Imi = New-Object System.Data.DataTable
            $Imi.Columns.Add("Host Name", "System.String")     | Out-Null  
            $Imi.Columns.Add("Service", "System.String")       | Out-Null  
            $Imi.Columns.Add("Name", "System.String")          | Out-Null
            $Imi.Columns.Add("User", "System.String")          | Out-Null
            $Imi.Columns.Add("LockPages", "System.Int32")      | Out-Null
            $Imi.Columns.Add("InstantInit", "System.Int32")    | Out-Null


            foreach ($proc in $procs)
            {
                $Service = Get-CimInstance -Query 'Select * from Win32_Service where name like "mssql%"' | Where-object {$_.ProcessId -eq $proc.ProcessId} 
                $CimMethod = Invoke-CimMethod -InputObject $proc -MethodName GetOwner
                $objUser = New-Object System.Security.Principal.NTAccount($CimMethod.Domain, $CimMethod.User)
                $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
                $NTName = $strSID.Value
                $ManageVolumePriv = 0
                $LockPagesPriv = 0

                secedit /export /areas USER_RIGHTS /cfg UserRights.inf /quiet
                $FileResults = Get-Content UserRights.inf
                foreach ($line in $FileResults)
                {
                    if($line -like "SeManageVolumePrivilege*" -and $line -like "*$NTName*") { $ManageVolumePriv = 1 }
                    if($line -like "SeLockMemoryPrivilege*" -and $line -like "*$NTName*") { $LockPagesPriv = 1 }
                }
                Remove-Item UserRights.inf
                $Imi.Rows.Add($LocalSvr, $Service.Caption, $Service.Name, $CimMethod.User, $LockPagesPriv, $ManageVolumePriv) | Out-Null
                #$LimIfiTable.Rows.Add($LocalSvr, $Service.Caption, $Service.Name, $CimMethod.User, $LockPagesPriv, $ManageVolumePriv) | Out-Null
                #$Imi.Rows.Add($LocalSvr, $Service.Caption, $Service.Name, $CimMethod.User, $LockPagesPriv, $ManageVolumePriv) | Out-Null
            }
            #Return $LocalSvr, $Service.Caption, $Service.Name, $CimMethod.User, $LockPagesPriv, $ManageVolumePriv
            #$LimIfiTable += $Imi
            $LimIfiTable += $Imi
    } else {
# for remote host 

        $Rep = Invoke-Command -ComputerName $HostName -ScriptBlock {
            #Set-Location C:\Temp\
            $LocalSvr = get-content env:computername
            $procs = Get-CimInstance -Query 'Select * from Win32_Process where name like "%sqlservr.exe%"'

            $Imi = New-Object System.Data.DataTable
            $Imi.Columns.Add("Host Name", "System.String")     | Out-Null  
            $Imi.Columns.Add("Service", "System.String")       | Out-Null  
            $Imi.Columns.Add("Name", "System.String")          | Out-Null
            $Imi.Columns.Add("User", "System.String")          | Out-Null
            $Imi.Columns.Add("LockPages", "System.Int32")      | Out-Null
            $Imi.Columns.Add("InstantInit", "System.Int32")    | Out-Null

            foreach ($proc in $procs)
            {   $Service = Get-CimInstance -Query 'Select * from Win32_Service where name like "mssql%"' | Where-object {$_.ProcessId -eq $proc.ProcessId} 
                $CimMethod = Invoke-CimMethod -InputObject $proc -MethodName GetOwner
                $objUser = New-Object System.Security.Principal.NTAccount($CimMethod.Domain, $CimMethod.User)
                $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
                $NTName = $strSID.Value
                $ManageVolumePriv = 0
                $LockPagesPriv = 0

                secedit /export /areas USER_RIGHTS /cfg UserRights.inf /quiet
                $FileResults = Get-Content UserRights.inf
                foreach ($line in $FileResults)
                {
                    if($line -like "SeManageVolumePrivilege*" -and $line -like "*$NTName*") { $ManageVolumePriv = 1 } 
                    if($line -like "SeLockMemoryPrivilege*" -and $line -like "*$NTName*") { $LockPagesPriv = 1 } 
                }
                Remove-Item UserRights.inf
                $Imi.Rows.Add($LocalSvr, $Service.Caption, $Service.Name, $CimMethod.User, $LockPagesPriv, $ManageVolumePriv) | Out-Null
            }
            Return  $Imi    # $LocalSvr, $Service.Caption, $Service.Name, $CimMethod.User, $LockPagesPriv, $ManageVolumePriv
        } | select 'Host Name', 'Service', 'Name', 'User', 'LockPages', 'InstantInit' 

#$Rep  | ft

        $LimIfiTable += $Rep
    } 

   
#IPs

    $newRunTime =  Get-Date 
    "$newRunTime - Host '$Server' IPs processing" | Out-File -append $LogFile 
    Write-Host  "Instance '$Server' IPs" -fore Gray
 
        $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $HostName)
        $regKey= $reg.OpenSubKey("SOFTWARE\\Microsoft\\Microsoft SQL Server\\Instance Names\\SQL" )
        $values = $regkey.GetValueNames()

        $values | ForEach-Object {
             
             $h = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $regKey.GetValue($_) +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\IPAll" #+ $f[1].PSChildName
             if($_ -eq "MSSQLSERVER") {$Instance = "$HostName"; $Named = "$HostName"} else {$Instance = "$HostName\$_" ; $Named = "$_"}
             $RegSQLHK = $regKey.GetValue($_)

            try {
                        $m = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\" + $RegSQLHK + "\\MSSQLServer\\SuperSocketNetLib\\Tcp\\"  
                        $reg1 = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $HostName)
                        $regKey1= $reg1.OpenSubKey($m)
                        $f = $regkey1.GetSubKeyNames()
                         foreach ($d in $f){
                            $n = "SOFTWARE\\Microsoft\\Microsoft SQL Server\\"+ $RegSQLHK +"\\MSSQLServer\\SuperSocketNetLib\\Tcp\\" + $d
                            $IPTable.Rows.Add($Instance, $d,  $reg.OpenSubKey($n).GetValue("Active"),  $reg.OpenSubKey($n).GetValue("Enabled") ,  $reg.OpenSubKey($n).GetValue("IpAddress") ,  $reg.OpenSubKey($n).GetValue("TcpDynamicPorts") ,  $reg.OpenSubKey($n).GetValue("TcpPort"),  $reg.OpenSubKey($n).GetValue("DisplayName")) | Out-Null 
                        }

                } catch {  $e = "No IP entries in registry for " + $Instance + " on host " + $HostName +". Try to run the script against another cluster node"; Write-Host $e -fore red; }

            }

#}
}


 $newRunTime =  Get-Date 
 "$newRunTime - End HOSTs loop" | Out-File -append $LogFile 

Write-Host  "End HOSTs loop" -fore green
Write-Host  "Start Queries loop" -fore green

# END Loop through HOSTs


 $newRunTime =  Get-Date 
 "$newRunTime - Start Queries loop" | Out-File -append $LogFile 

# getting list of scripts
$ScriptsList = Get-ChildItem -Path $ScriptsPath | where {$_.Extension -eq '.sql' } | Select Name, BaseName

    # Loop through all scripts
    foreach ($Script in $ScriptsList) {


      IF (($Script.Name -ne "IndexFragmentation") -or $RunIndexFragmentation) {

        $ScriptFullName = $ScriptsPath + $Script.Name
        $CSVFileName = $CSVPath + "-" + $Script.BaseName + ".csv"
        $Query = Get-Content -Path $ScriptFullName -Raw
        $ResultS = $null

        $QN = $Script.BaseName 
        # Loop through all instances
        foreach ($Instance in $Instances) {

            if (($Instance -eq '') -or ($Instance.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string 

            Write-Host  " Query: '$QN' on the instance '$Instance'" -fore Gray
            $newRunTime =  Get-Date
            "$newRunTime - Instance '$Instance' Query: '$QN'" | Out-File -append $LogFile 

            $ConnectionCFG = New-Object System.Data.SQLClient.SQLConnection("server='$Instance';Integrated Security=SSPI;Initial Catalog='master';");
            $ConnectionCFG.Open()
            $CommandCFG = New-Object System.Data.SQLClient.SQLCommand
            $CommandCFG.Connection = $ConnectionCFG
            $CommandCFG.CommandTimeout = 0
            $adapter = New-Object System.Data.SqlClient.SqlDataAdapter $CommandCFG
            $dataset = New-Object System.Data.DataSet

            $CommandCFG.CommandText = $Query 
               $adapter.Fill($dataset) | out-null 
               $Result = $dataset.Tables[0]
            if ($Result.Count -ne 0) { $ResultS += $Result } 
        }

        #$ResultS.Count

        if ($ResultS.Count -ne 0) { $ResultS | export-csv -Path $CSVFileName  -NoTypeInformation }
    }}

 $newRunTime =  Get-Date 
 "$newRunTime - End Queries loop" | Out-File -append $LogFile 

Write-Host  "End Queries loop" -fore green

###################################################################################################


 $newRunTime =  Get-Date 
 "$newRunTime - Start Instances loop" | Out-File -append $LogFile   
 
 Write-Host  "Start AAG backups loop" -fore green      

    foreach($Server in $Instances)
    {
#$Server

    $HostName = $Server 

    if (($Server -eq '') -or ($Server.Substring(0,4) -eq 'REM ')) { Continue } # Ignore empty or REM string 

    Write-Host "Instance processing AAG backups: $HostName " -fore yellow


#Instance
 $newRunTime =  Get-Date 
 "$newRunTime - Instance: $Server" | Out-File -append $LogFile     

        $InstanceInfo = New-Object "Microsoft.SqlServer.Management.Smo.Server" $HostName | Select *

        $HostName = $InstanceInfo.ComputerNamePhysicalNetBIOS


  #      $InstTable = New-Object System.Data.DataTable
        $InstTable.Rows.Add(1, $HostName, $Server, 'Instance Name', $Server, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(2, $HostName, $Server, 'Edition', $InstanceInfo.Edition, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(3, $HostName, $Server, 'Version', $InstanceInfo.ResourceVersionString, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(3, $HostName, $Server, 'Platform', $InstanceInfo.Platform, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(4, $HostName, $Server, 'SPs', $InstanceInfo.ProductLevel, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(5, $HostName, $Server, 'Instance Collation', $InstanceInfo.Collation, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(6, $HostName, $Server, 'Instance Up from', $InstanceInfo.Databases["tempdb"].CreateDate, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(7, $HostName, $Server, 'BackupDirectory', $InstanceInfo.BackupDirectory, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(8, $HostName, $Server, 'DefaultLog', $InstanceInfo.DefaultLog, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(9, $HostName, $Server, 'DefaultFile', $InstanceInfo.DefaultFile, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(10, $HostName, $Server, 'ErrorLogPath', $InstanceInfo.ErrorLogPath, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(11, $HostName, $Server, 'InstallDataDirectory', $InstanceInfo.InstallDataDirectory, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(12, $HostName, $Server, 'InstallSharedDirectory', $InstanceInfo.InstallSharedDirectory, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(13, $HostName, $Server, 'MasterDBLogPath', $InstanceInfo.MasterDBLogPath, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(14, $HostName, $Server, 'MasterDBPath', $InstanceInfo.MasterDBPath, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(15, $HostName, $Server, 'RootDirectory', $InstanceInfo.RootDirectory, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(16, $HostName, $Server, 'NumberOfLogFiles', $InstanceInfo.NumberOfLogFiles, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(17, $HostName, $Server, 'IsClustered', $InstanceInfo.IsClustered, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(18, $HostName, $Server, 'ClusterName', $InstanceInfo.ClusterName, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(19, $HostName, $Server, 'ClusterQuorumState', $InstanceInfo.ClusterQuorumState, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(20, $HostName, $Server, 'ClusterQuorumType', $InstanceInfo.ClusterQuorumType, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(21, $HostName, $Server, 'FilestreamLevel', $InstanceInfo.FilestreamLevel, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(22, $HostName, $Server, 'LoginMode', $InstanceInfo.LoginMode, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(23, $HostName, $Server, 'PhysicalMemoryMB', $InstanceInfo.PhysicalMemory, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(24, $HostName, $Server, 'PhysicalMemoryUsageMB', $InstanceInfo.PhysicalMemoryUsageInKB / 1024, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(25, $HostName, $Server, 'Processors', $InstanceInfo.Processors, $Client, $RunTime) | Out-Null
#        $InstTable.Rows.Add(26, $HostName, $Server, 'BrowserServiceAccount', $InstanceInfo.BrowserServiceAccount, $Client, $RunTime) | Out-Null
#        $InstTable.Rows.Add(27, $HostName, $Server, 'ServiceAccount', $InstanceInfo.ServiceAccount, $Client, $RunTime) | Out-Null

        $InstTable.Rows.Add(28, $HostName, $Server, 'MinRAM', $InstanceInfo.configuration.minServerMemory.runValue, $Client, $RunTime) | Out-Null
        $InstTable.Rows.Add(29, $HostName, $Server, 'MaxRAM', $InstanceInfo.configuration.maxServerMemory.runValue, $Client, $RunTime) | Out-Null
        
        $InstTable.Rows.Add(30, $HostName, $Server, 'MaxDegreeOfParallelism', $InstanceInfo.configuration.MaxDegreeOfParallelism.runValue, $Client, $RunTime) | Out-Null
	


		if ($InstanceInfo.configuration.DefaultBackupCompression.runValue -eq 0) { $InstTable.Rows.Add(31, $HostName,$Server,  'DefaultBackupCompression', 'Disabled', $Client, $RunTime) | Out-Null }
			else {$InstTable.Rows.Add(31, $HostName,$Server,  'DefaultBackupCompression', 'Enabled', $Client, $RunTime) | Out-Null }

	
		

	    $InstTable.Rows.Add(32, $HostName, $Server, 'ActiveDirectory', $InstanceInfo.ActiveDirectory, $Client, $RunTime) | Out-Null

	# 04/04/17
#	    $InstTable.Rows.Add(33, $HostName, $Server, 'Collation', $InstanceInfo.Collation, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(34, $HostName, $Server, 'EngineEdition', $InstanceInfo.EngineEdition, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(35, $HostName, $Server, 'FilestreamShareName', $InstanceInfo.FilestreamShareName, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(36, $HostName, $Server, 'FullTextService', $InstanceInfo.FullTextService.State, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(37, $HostName, $Server, 'IsFullTextInstalled', $InstanceInfo.IsFullTextInstalled, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(38, $HostName, $Server, 'IsPolyBaseInstalled', $InstanceInfo.IsPolyBaseInstalled, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(39, $HostName, $Server, 'JobServer', $InstanceInfo.JobServer.JobServerType, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(40, $HostName, $Server, 'Mail', $InstanceInfo.Mail.State, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(41, $HostName, $Server, 'MailProfile', $InstanceInfo.MailProfile, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(42, $HostName, $Server, 'MaxPrecision', $InstanceInfo.MaxPrecision, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(43, $HostName, $Server, 'OSVersion', $InstanceInfo.OSVersion, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(44, $HostName, $Server, 'ProxyAccount', $InstanceInfo.ProxyAccount.IsEnabled, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(45, $HostName, $Server, 'ServerType', $InstanceInfo.ServerType, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(46, $HostName, $Server, 'ServiceStartMode', $InstanceInfo.ServiceStartMode, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(47, $HostName, $Server, 'Status', $InstanceInfo.Status, $Client, $RunTime) | Out-Null
		$InstTable.Rows.Add(48, $HostName, $Server, 'TcpEnabled', $InstanceInfo.TcpEnabled, $Client, $RunTime) | Out-Null
	#	$InstTable.Rows.Add(1, $HostName, '', $InstanceInfo., $Client, $RunTime) | Out-Null
	#	$InstTable.Rows.Add(1, $HostName, '', $InstanceInfo., $Client, $RunTime) | Out-Null
		
#       $InstTable.Rows.Add(1, $HostName, 'AvailabilityGroups', $InstanceInfo.AvailabilityGroups, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(1, $HostName, 'Configuration', $InstanceInfo.Configuration, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(1, $HostName, 'Information', $InstanceInfo.Information, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(1, $HostName, 'ResourceGovernor', $InstanceInfo.ResourceGovernor, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(1, $HostName, 'Settings', $InstanceInfo.Settings, $Client, $RunTime) | Out-Null
#		$InstTable.Rows.Add(1, $HostName, 'SmartAdmin', $InstanceInfo.SmartAdmin, $Client, $RunTime) | Out-#Null
	#Credentials - collection
	#LinkedServers - collection

        #$InstTable | Format-Table

		
		$SQLServer = new-object "Microsoft.SQLServer.Management.Smo.Server" $Server

		$TraceFlags = $SQLServer.EnumActiveGlobalTraceFlags()

		[int] $Flag     =  1
		[string] $FlagSTR     =  ""

		ForEach($TraceFlag in $TraceFlags)
		 {
			$FlagSTR = "Startup flag " + $Flag
			$Flag = $Flag + 1
 			$InstTable.Rows.Add(48+$Flag, $HostName, $Server, $FlagSTR, $TraceFlag.TraceFlag, $Client, $RunTime) | Out-Null
		  }


#### AAG backups

    # create temp table to collect backups from all replicas
    try {
        #Write-Host $instance
        Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Temp_table_create
    } catch {
        #Write-Error $_.Exception.Message
        #Exit
        continue
    }

    # Getting SQL version
    [int] $sql_int = 0
    #$instanceTMP = $instance
    try {
        $sql_int = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query "select CAST(SUBSTRING(CAST(SERVERPROPERTY('productversion') as VARCHAR(10)),1,CHARINDEX('.',CAST(SERVERPROPERTY('productversion') as VARCHAR(10)),1)-1) AS INT)" -As DataValue
    } catch {
        #Write-Host $_.Exception.Message
        Write-Error $_.Exception.Message
    }

    $pshost = get-host
    $pswindow = $pshost.ui.rawui
    $newsize = $pswindow.buffersize
    $newsize.width = 8000
    $pswindow.buffersize = $newsize

    if ($sql_int -ge 11) {
        # SQL 2012 and later can have AAG    

 $newRunTime =  Get-Date 
 "$newRunTime - AAG backups on $Server" | Out-File -append $LogFile   

        # getting list of primary AAG on this instance
        try {
            $AAGs = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_List_AAGs -As DataRow
        } catch {"sdfsdf"; Write-Error $_.Exception.Message; continue }

        foreach($AAG in $AAGs) {
            $AAGname = $AAG.Name
            #$AAGname

            # returns list of replicas for AAG that primary on that SQL instance
            $SQL_List_replicas_primary_AAG = "select ar.replica_server_name as [instance]
                                            from sys.availability_groups ag 
	                                        inner join sys.availability_replicas ar on ag.group_id = ar.group_id
                                            where ag.name = '$AAGname'"

            # getting list of replicas on primary AAG
            try {
                $AAGlist = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_List_replicas_primary_AAG -As DataRow
                #$AAGlist
            } catch { Write-Error $_.Exception.Message }

            if ($AAGlist.Rows.Count -ge 1) {
                # loop throgh all 
                foreach($AAGnode in $AAGlist) {
                    [string] $AAGinstance = $AAGnode.instance
                    $SQL_Last_backup = "SELECT t1.name, 
	                    databasepropertyex(t1.name, 'Recovery') as RM,
                        '$AAGname' as [AAGname],
	                    DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus1.backup_finish_date)) AS LastBackUpTime_FULL,
	                    DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus.backup_finish_date))  AS LastBackUpTime_LOG
                        FROM master.sys.databases t1 
	                    LEFT OUTER JOIN msdb.dbo.backupset bus ON bus.database_name = T1.name AND bus.type= 'L' 
	                    LEFT OUTER JOIN msdb.dbo.backupset bus1 ON bus1.database_name = T1.name AND (bus1.type= 'D' OR bus1.type= 'I')
                        where t1.name not in ('tempdb') 
                                                    AND t1.name IN (Select dg.Database_name
                                                    from master.sys.dm_hadr_database_replica_cluster_states dg
	                                                INNER join master.sys.availability_replicas ar on ar.replica_id = dg.replica_id
	                                                lEFT join master.sys.availability_groups ag on ag.group_id = ar.group_id
                                                    WHERE ag.name = '$AAGname')  
                        GROUP BY t1.name"

                    try {
                        $results = Invoke-SqlCmd2 -ServerInstance $AAGinstance -Database "master" -Query $SQL_Last_backup -As DataTable
                        try {
                            Write-DataTable -ServerInstance $Server -Database "master" -TableName "tempdb.dbo.$tableName" -Data $results
                        } catch {
                            Write-Error $_.Exception.Message 
                        }
                    } catch { 
                        #if any replica is not operational ignore
                        #Write-Host $_.Exception.Message
                        #Write-Error $_.Exception.Message 
                        continue 
                    } 
                }
            }
        }

        try {
            #this is run for databases that are not in AAG 
            $results = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_NOAAG -As DataTable
            Write-DataTable -ServerInstance $Server -Database "master" -TableName "tempdb.dbo.$tableName" -Data $results

            # run last most important query
            #Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_ALL_REPLICAS -As DataTable  | FT -AutoSize
            #Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_ALL_REPLICAS  | Export-Csv -Path $Path-aagbackups.csv -NoTypeInformation
            $resultListTable = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_ALL_REPLICAS   
            $BackupAAG = $BackupAAG + $resultListTable 
        } catch { Write-Error $_.Exception.Message }

    } else {
        #Write-Host "SQL lower 2012 - NO AAG processing"
        try {
            $results = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_SQL08 -As DataTable
            Write-DataTable -ServerInstance $Server -Database "master" -TableName "tempdb.dbo.$tableName" -Data $results

            # run last most important query
            #Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_SQL2000 -As DataTable | FT -AutoSize
            $resultListTable = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Last_backup_SQL2000 #| Export-Csv -Path $Path-aagbackups.csv -NoTypeInformation
            $BackupAAG = $BackupAAG + $resultListTable 
        } catch { Write-Error $_.Exception.Message }

    }

    # drop tmp table
    try {
        Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Temp_table_drop 
    } catch {
        Write-Error $_.Exception.Message
    }


#### AAG discrepancies
    # create temp table in TempDB to collect info from all replicas
    try { 
 $newRunTime =  Get-Date 
 "$newRunTime - AAG discrepancies on $Server" | Out-File -append $LogFile   

        for($i=0; $i -le $AAG_A[0].Count-1; $i++){
            $val = $AAG_A[0][$i]
            if ($i -le 6 ) { $SQL_Temp_table = "IF NOT EXISTS (select 1 from tempdb.dbo.sysobjects where name = '$val') CREATE TABLE tempdb.dbo.$val([InstanceName] [sysname] NOT NULL,[Name] [sysname] NULL);TRUNCATE TABLE tempdb.dbo.$val"
            } else { $SQL_Temp_table = $AAG_A[2][$i] }
            Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Temp_table
        }
    } catch { continue }

    # Getting SQL version
    [int] $sql_int = 0
    #$instanceTMP = $instance
    try { $sql_int = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query "select CAST(SUBSTRING(CAST(SERVERPROPERTY('productversion') as VARCHAR(10)),1,CHARINDEX('.',CAST(SERVERPROPERTY('productversion') as VARCHAR(10)),1)-1) AS INT)" -As DataValue
    } catch { "DDDD"; Write-Error $_.Exception.Message }


    # ????? - don't remember this for?
    $pshost = get-host
    $pswindow = $pshost.ui.rawui
    $newsize = $pswindow.buffersize
    $newsize.width = 8000
    $pswindow.buffersize = $newsize

    if ($sql_int -ge 11) {
    # SQL 2012 and later can have AAG - getting list of primary AAG on this instance
        try { $AAGs = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query "select distinct ag.name as [name] from sys.dm_hadr_availability_replica_states ars inner join sys.availability_groups ag on ag.group_id = ars.group_id where ars.role_desc = 'PRIMARY'" -As DataRow
        } catch { 
            #Write-Error $_.Exception.Message 
            continue }
    

        # Loop through several AAGs on the instance
        foreach($AAG in $AAGs) {
            $AAGname = $AAG.Name
            # getting list of replicas on primary AAG
            try { $AAGlist = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query "select ar.replica_server_name as [instance] from sys.availability_groups ag inner join sys.availability_replicas ar on ag.group_id = ar.group_id where ag.name = '$AAGname'" -As DataRow
            } catch { "FFDFDF";Write-Error $_.Exception.Message }

            if ($AAGlist.Rows.Count -ge 1) {
                # loop throgh all replicas for selected AAG
                foreach($AAGnode in $AAGlist) {
                    [string] $AAGinstance = $AAGnode.instance
                    try { 

    $AAG_A0 = $AAG_A[0][0]
    $AAG_A1 = $AAG_A[0][1]
    $AAG_A2 = $AAG_A[0][2]
    $AAG_A3 = $AAG_A[0][3]
    $AAG_A4 = $AAG_A[0][4]
    $AAG_A5 = $AAG_A[0][5]
    $AAG_A6 = $AAG_A[0][6]
    $AAG_A7 = $AAG_A[0][7]
    $AAG_A8 = $AAG_A[0][8]
    $AAG_A9 = $AAG_A[0][9]
    $AAG_A10 = $AAG_A[0][10]
    $AAG_A11 = $AAG_A[0][11]
    $AAG_A12 = $AAG_A[0][12]
    $AAG_A13 = $AAG_A[0][13]
    $AAG_A14 = $AAG_A[0][14]

    $CheckUnique = "
    SELECT COUNT(*) FROM (
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A0
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A1
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A2
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A3
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A4
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A5
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A6
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A7
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A8
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A9
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A10
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A11
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A12
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A13
    UNION
    SELECT [InstanceName] FROM [tempdb].[dbo].$AAG_A14
    ) S where S.[InstanceName] ='$AAGinstance'
    "
    [int] $Instance_checked = 0
    #$instanceTMP = $instance
    try { $Instance_checked = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $CheckUnique -As DataValue
    } catch {"sdfdfsdfg2222"; Write-Error $_.Exception.Message }

    IF ($Instance_checked -eq 0) {

                           for($i=0; $i -le $AAG_A[0].Count-1; $i++){
                           #for($i=0; $i -le 1; $i++){

                           #"Loop $i"
                                $val = $AAG_A[0][$i]
                                $SQL_for_AAG = $AAG_A[1][$i]
                                $results = Invoke-SqlCmd2 -ServerInstance $AAGinstance -Database "master" -Query $SQL_for_AAG -As DataTable
                                try { Write-DataTable -ServerInstance $Server -Database "master" -TableName "tempdb.dbo.$val" -Data $results
                                } catch { Write-Error $_.Exception.Message 
                                }
                            }
    }
                    } catch { continue }  #if any replica is not operational ignore
                }
            }
        }

        try {
    # run last most important query
            #$res = @{Name = "Resultset";Expression = {"$($_.Column1)$($_.bkp)"[0..200] -join ''}}
            $res = @{Name = "Resultset";Expression = {"$($_.Column1)$($_.bkp)"}}
    #        Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_BD_RS -As DataTable | where { -not ([string]::IsNullOrEmpty($_.bkp))}| Select $res | FT -AutoSize
            $DicrTable = Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_BD_RS #| Export-Csv -Path $Path-aagobjects.csv -NoTypeInformation
            $DicrAAG = $DicrAAG + $DicrTable 
            #-As DataTable | where { -not ([string]::IsNullOrEmpty($_.bkp))}| Select $res | FT -AutoSize
        } catch { Write-Error $_.Exception.Message }

    } 

    # drop tmp table
    try { 
        for($i=0; $i -le $AAG_A[0].Count-1; $i++){
            $val = $AAG_A[0][$i]
            $SQL_Temp_table = "IF EXISTS (select 1 from tempdb.dbo.sysobjects where name = '$val') DROP TABLE tempdb.dbo.$val"
            Invoke-SqlCmd2 -ServerInstance $Server -Database "master" -Query $SQL_Temp_table
        }
    } catch { Write-Error $_.Exception.Message }

}

 Write-Host  "End AAG backups loop" -fore green   

 $newRunTime =  Get-Date 
 "$newRunTime - END of HC" | Out-File -append $LogFile   


###################################################################################################

$driveTable  | Export-Csv  -Path $CSVPath-drives.csv -NoTypeInformation  
$OSTable  | Export-Csv -Path $CSVPath-os.csv -NoTypeInformation  
$serviceTable  | Export-Csv -Path $CSVPath-service.csv -NoTypeInformation  
$InstanceTable  | Export-Csv -Path $CSVPath-system.csv -NoTypeInformation  
$LimIfiTable | Export-Csv -Path $CSVPath-limifi.csv -NoTypeInformation  
$InstTable  | Export-Csv -Path $CSVPath-instance.csv -NoTypeInformation  
$IPTable      | Export-Csv -Path $CSVPath\-IPs.csv -NoTypeInformation 

if ($AAG -ne $null)
    { $AAG | Export-Csv -Path $CSVPath-aag.csv -NoTypeInformation 
      $AAG = $null
    } else {
             Set-Content $CSVPath-aag.csv -Value ""
            #New-Item -Name $Path-aag.csv -ItemType 
            #Out-File -FilePath $Path-aag.csv
            #"".ToString() | Export-Csv -Path $Path-aag.csv -NoTypeInformation
          }

$BackupAAG | Export-Csv -Path $CSVPath-aagbackups.csv -NoTypeInformation
#$Backups | Export-Csv -Path $Path-Backups.csv -NoTypeInformation

if ($DicrAAG -ne $null)
    { $DicrAAG | Export-Csv -Path $CSVPath-aagobjects.csv -NoTypeInformation
      $DicrAAG = $null
    } else {
            Set-Content $CSVPath-aagobjects.csv -Value ""
            #New-Item -Name $Path-aagobjects.csv -ItemType File
            #Out-File -FilePath $Path-aagobjects.csv
            #$null | Export-Csv -Path $Path-aagobjects.csv -NoTypeInformation
          }

Write-Host "Reports location: $CSVPath" -fore Green

 Get-Date  
"End HC"