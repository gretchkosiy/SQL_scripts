
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE NAME = 'LOAD')
	EXEC('CREATE SCHEMA [LOAD]')
GO

DROP TABLE IF EXISTS [LOAD].[AAG_Load]
GO
CREATE TABLE [LOAD].[AAG_Load](
	[AAG name] [varchar](max) NULL,
	[Listener DNS name] [varchar](max) NOT NULL,
	[Listener PORT] [varchar](max) NOT NULL,
	[Cluster IP configuration string] [varchar](max) NOT NULL,
	[Primary node] [varchar](max) NULL,
	[Secondary node] [varchar](max) NULL,
	[Endpoint] [varchar](max) NULL,
	[Availability Mode] [varchar](max) NULL,
	[Failover Mode] [varchar](max) NULL,
	[Seeding Mode] [varchar](max) NULL,
	[Operational State] [varchar](max) NULL,
	[Connected State] [varchar](max) NULL,
	[Health] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[AAG]
GO
CREATE TABLE [dbo].[AAG](
	[AAG name] [varchar](max) NULL,
	[Listener DNS name] [varchar](max) NOT NULL,
	[Listener PORT] [varchar](max) NOT NULL,
	[Cluster IP configuration string] [varchar](max) NOT NULL,
	[Primary node] [varchar](max) NULL,
	[Secondary node] [varchar](max) NULL,
	[Endpoint] [varchar](max) NULL,
	[Availability Mode] [varchar](max) NULL,
	[Failover Mode] [varchar](max) NULL,
	[Seeding Mode] [varchar](max) NULL,
	[Operational State] [varchar](max) NULL,
	[Connected State] [varchar](max) NULL,
	[Health] [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[AAGbackup_load]
GO
CREATE TABLE [LOAD].[AAGbackup_load](
	[InstaneName] [varchar](max) NULL,
	[type] [varchar](max) NOT NULL,
	[name] [varchar](max) NOT NULL,
	[RM] [varchar](max) NOT NULL,
	[AAGname] [varchar](max) NULL,
	[Last Backup] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[AAGbackup]
GO
CREATE TABLE [dbo].[AAGbackup](
	[InstaneName] [varchar](max) NULL,
	[type] [varchar](max) NULL,
	[name] [varchar](max) NULL,
	[RM] [varchar](max) NULL,
	[AAGname] [varchar](max) NULL,
	[Last Backup] [datetime] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL,
	[Host Name] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[AAGobjects_load]
GO
CREATE TABLE [LOAD].[AAGobjects_load](
	[ObjName] [varchar](max) NULL,
	[InstanceName] [varchar](max) NOT NULL,
	[name] [varchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[AAGobjects]
GO
CREATE TABLE [dbo].[AAGobjects](
	[Object type] [varchar](max) NULL,
	[Instance Name] [varchar](max) NOT NULL,
	[Object name] [varchar](max) NOT NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL,
	[Host Name] [varchar](50) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[ChangeTracking_load]
GO
CREATE TABLE [LOAD].[ChangeTracking_load](
	[InstanceName] [varchar](max) NOT NULL,
	[change_tracking_db] [varchar](max) NULL,
	[is_auto_cleanup_on] [varchar](max) NOT NULL,
	[retention_period] [varchar](max) NOT NULL,
	[retention_period_units_desc] [varchar](max) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[ChangeTracking]
GO
CREATE TABLE [dbo].[ChangeTracking](
	[InstanceName] [varchar](max) NOT NULL,
	[change_tracking_db] [varchar](max)	 NULL,
	[is_auto_cleanup_on] INT NOT NULL,
	[retention_period] INT NOT NULL,
	[retention_period_units_desc] [varchar](max) NOT NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[Compression_load]
GO
CREATE TABLE [LOAD].[Compression_load](
	[InstanceName] [varchar](max) NULL,
	[DatabaseName] [varchar](max) NULL,
	[Table] [varchar](max) NULL,
	[Partition] [varchar](max) NULL,
	[Compression] [varchar](max) NULL,
	[Index] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


DROP TABLE IF EXISTS [dbo].[Compression]
GO
CREATE TABLE [dbo].[Compression](
	[InstanceName] [varchar](max) NULL,
	[DatabaseName] [varchar](max) NULL,
	[Table] [varchar](max) NULL,
	[Partition] [varchar](max) NULL,
	[Compression] [varchar](max) NULL,
	[Index] [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

DROP TABLE IF EXISTS [dbo].[Configuration]
GO
CREATE TABLE [dbo].[Configuration](
	[HostName] [varchar](max) NULL,
	[InstanceName] [varchar](max) NOT NULL,
	[StartUpFlags] [nvarchar](4000) NULL,
	[DAC] [varchar](50) NULL,
	[net_transport] [varchar](20) NULL,
	[protocol_type] [varchar](20) NULL,
	[auth_scheme] [varchar](20) NULL,
	[ActiveNode] [varchar](max) NULL,
	[ListNodes] [varchar](max) NULL,
	[client_net_address] [varchar](20) NULL,
	[local_net_address] [varchar](20) NULL,
	[local_tcp_port] [int] NULL,
	[ServiceAccount] [varchar](max) NULL,
	[ServiceAccountStatus] [varchar](max) NULL,
	[ServiceAccountStartup] [varchar](max) NULL,
	[AgentAccount] [varchar](max) NULL,
	[AgentAccountStatus] [varchar](max) NULL,
	[AgentAccountStartup] [varchar](max) NULL,
	[AuthentificationMode] [varchar](max) NULL,
	[BackupCompression] [varchar](max) NULL,
	[DOP] [int] NULL,
	[OSmemoryGB] [int] NULL,
	[MinRAM] [int] NULL,
	[MaxRAM] [int] NULL,
	[CPUs] [int] NULL,
	[GrowthFile_Master] [varchar](max) NULL,
	[GrowthFile_Msdb] [varchar](max) NULL,
	[GrowthFile_Model] [varchar](max) NULL,
	[NumberTempDB] [int] NULL,
	[ListSharedDrives] [varchar](max) NULL,
	[DataFileSizeMB] [int] NULL,
	[MSDB_used] [varchar](30) NULL,
	[MASTER_file_location] [varchar](max) NULL,
	[MODEL_file_location] [varchar](max) NULL,
	[MSDB_file_location] [varchar](max) NULL,
	[InitialSizeTempDB] [varchar](max) NULL,
	[GrowthFileTempDB] [varchar](max) NULL,
	[SizeDataTempDB] [varchar](1000) NULL,
	[SizeLogTempDB] [varchar](1000) NULL,
	[TempDB_fileLocation] [varchar](max) NULL,
	[TempDB_LogLocation] [varchar](max) NULL,
	[DB_FileLocation] [nvarchar](4000) NULL,
	[DB_LogLocation] [nvarchar](4000) NULL,
	[DB_BackupLocation] [nvarchar](4000) NULL,
	[BIN_Location] [nvarchar](4000) NULL,
	[MailServer] [varchar](150) NULL,
	[ProductLevel] [varchar](max) NULL,
	[ProductUpdateLevel] [varchar](max) NULL,
	[ProductBuildType] [varchar](max) NULL,
	[ProductUpdateReference] [varchar](max) NULL,
	[ProductVersion] [varchar](max) NULL,
	[ProductMajorVersion] [varchar](max) NULL,
	[ProductMinorVersion] [varchar](max) NULL,
	[ProductBuild] [varchar](max) NULL,
	[ProductCollation] [varchar](max) NULL,
	[Edition] [varchar](max) NULL,
	[MaintenancePlansWith_no_SA] [int] NULL,
	[JobsWith_no_SA] [int] NULL,
	[ErrorLogLocation] [varchar](max) NULL,
	[AgentErrorLogLocation] [nvarchar](255) NULL,
	[MultiServerJobs] [varchar](9) NOT NULL,
	[OsName] [varchar](100) NULL,
	[NumberErrorLog_files] [int] NULL,
	[MSDB_DatabaseMailUserRole] [varchar](50) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[Configuration_load]
GO
CREATE TABLE [LOAD].[Configuration_load](
	[HostName] [varchar](max) NULL,
	[InstanceName] [varchar](max) NOT NULL,
	[StartUpFlags] [varchar](max) NULL,
	[DAC] [varchar](max) NULL,
	[net_transport] [varchar](max) NULL,
	[protocol_type] [varchar](max) NULL,
	[auth_scheme] [varchar](max) NULL,
	[ActiveNode] [varchar](max) NULL,
	[ListNodes] [varchar](max) NULL,
	[client_net_address] [varchar](max) NULL,
	[local_net_address] [varchar](max) NULL,
	[local_tcp_port] [varchar](max) NULL,
	[ServiceAccount] [varchar](max) NULL,
	[ServiceAccountStatus] [varchar](max) NULL,
	[ServiceAccountStartup] [varchar](max) NULL,
	[AgentAccount] [varchar](max) NULL,
	[AgentAccountStatus] [varchar](max) NULL,
	[AgentAccountStartup] [varchar](max) NULL,
	[AuthentificationMode] [varchar](max) NULL,
	[BackupCompression] [varchar](max) NULL,
	[DOP] [varchar](max) NULL,
	[OSmemoryGB] [varchar](max) NULL,
	[MinRAM] [varchar](max) NULL,
	[MaxRAM] [varchar](max) NULL,
	[CPUs] [varchar](max) NULL,
	[GrowthFile_Master] [varchar](max) NULL,
	[GrowthFile_Msdb] [varchar](max) NULL,
	[GrowthFile_Model] [varchar](max) NULL,
	[NumberTempDB] [varchar](max) NULL,
	[ListSharedDrives] [varchar](max) NULL,
	[DataFileSizeMB] [varchar](max) NULL,
	[MSDB_used] [varchar](max) NULL,
	[MASTER_file_location] [varchar](max) NULL,
	[MODEL_file_location] [varchar](max) NULL,
	[MSDB_file_location] [varchar](max) NULL,
	[InitialSizeTempDB] [varchar](max) NULL,
	[GrowthFileTempDB] [varchar](max) NULL,
	[SizeDataTempDB] [varchar](max) NULL,
	[SizeLogTempDB] [varchar](max) NULL,
	[TempDB_fileLocation] [varchar](max) NULL,
	[TempDB_LogLocation] [varchar](max) NULL,
	[DB_FileLocation] [varchar](max) NULL,
	[DB_LogLocation] [varchar](max) NULL,
	[DB_BackupLocation] [varchar](max) NULL,
	[BIN_Location] [varchar](max) NULL,
	[MailServer] [varchar](max) NULL,
	[ProductLevel] [varchar](max) NULL,
	[ProductUpdateLevel] [varchar](max) NULL,
	[ProductBuildType] [varchar](max) NULL,
	[ProductUpdateReference] [varchar](max) NULL,
	[ProductVersion] [varchar](max) NULL,
	[ProductMajorVersion] [varchar](max) NULL,
	[ProductMinorVersion] [varchar](max) NULL,
	[ProductBuild] [varchar](max) NULL,
	[ProductCollation] [varchar](max) NULL,
	[Edition] [varchar](max) NULL,
	[MaintenancePlansWith_no_SA] [varchar](max) NULL,
	[JobsWith_no_SA] [varchar](max) NULL,
	[ErrorLogLocation] [varchar](max) NULL,
	[AgentErrorLogLocation] [varchar](max) NULL,
	[MultiServerJobs] [varchar](max) NOT NULL,
	[OsName] [varchar](max) NULL,
	[NumberErrorLog_files] [varchar](max) NULL,
	[MSDB_DatabaseMailUserRole] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[DatabaseDetails]
GO
CREATE TABLE [dbo].[DatabaseDetails](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [sysname] NULL,
	[File Name] [varchar](200) NULL,
	[Type] [varchar](1) NULL,
	[Total Size (MB)] [bigint] NULL,
	[Used Size (MB)] [bigint] NULL,
	[Auto-growth] [varchar](200) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO


DROP TABLE IF EXISTS [LOAD].[DatabaseDetails_load]
GO
CREATE TABLE [LOAD].[DatabaseDetails_load](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [sysname] NULL,
	[File Name] [varchar](200) NULL,
	[Type] [varchar](50) NULL,
	[Total Size (MB)] [varchar](50) NULL,
	[Used Size (MB)] [varchar](50) NULL,
	[Auto-growth] [varchar](200) NULL
) ON [PRIMARY]
GO


DROP TABLE IF EXISTS [LOAD].[DatabaseMasterKey_load]
GO
CREATE TABLE [LOAD].[DatabaseMasterKey_load](
	InstanceName [varchar](max) NOT NULL
	,KeyName [varchar](max) NOT NULL
	,PrincipalName [varchar](max) NOT NULL
	,create_date [varchar](max) NOT NULL
	,modify_date [varchar](max) NOT NULL)

DROP TABLE IF EXISTS [dbo].[DatabaseMasterKey]
GO
CREATE TABLE [dbo].[DatabaseMasterKey](
	InstanceName [varchar](max) NOT NULL
	,KeyName [varchar](max) NOT NULL
	,PrincipalName [varchar](max) NOT NULL
	,create_date [datetime] NOT NULL
	,modify_date [datetime] NOT NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL)


DROP TABLE IF EXISTS [dbo].[DatabasesRoles]
GO
CREATE TABLE [dbo].[DatabasesRoles](
	[Instance Name] [varchar](128) NULL,
	[Host Name] [nvarchar](50) NULL,
	[Database Name] [nvarchar](100) NULL,
	[Role] [sysname] NULL,
	[User name] [sysname] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[DatabasesRoles_load]
GO
CREATE TABLE [LOAD].[DatabasesRoles_load](
	[Instance Name] [varchar](128) NULL,
	[Host Name] [nvarchar](50) NULL,
	[Database Name] [nvarchar](100) NULL,
	[Role] [sysname] NULL,
	[User name] [sysname] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[DBoption]
GO
CREATE TABLE [dbo].[DBoption](
	[Instance Name] [varchar](max) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [varchar](max) NULL,
	[DBowner] [varchar](max) NULL,
	[State] [varchar](max) NULL,
	[Compatibility] [tinyint] NULL,
	[Collation] [varchar](max) NULL,
	[Page Verify] [varchar](max) NULL,
	[auto_close] [varchar](1) NULL,
	[auto_shrink] [varchar](1) NULL,
	[db_chaining] [varchar](1) NULL,
	[auto_create_stats] [varchar](1) NULL,
	[auto_update_stats] [varchar](1) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[DBoption_load]
GO
CREATE TABLE [LOAD].[DBoption_load](
	[Instance Name] [varchar](max) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [varchar](max) NULL,
	[DBowner] [varchar](max) NULL,
	[State] [varchar](max) NULL,
	[Compatibility] [varchar](max) NULL,
	[Collation] [varchar](max) NULL,
	[Page Verify] [varchar](max) NULL,
	[auto_close] [varchar](max) NULL,
	[auto_shrink] [varchar](max) NULL,
	[db_chaining] [varchar](max) NULL,
	[auto_create_stats] [varchar](max) NULL,
	[auto_update_stats] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[DiskSpace]
GO
CREATE TABLE [dbo].[DiskSpace](
	[Host Name] [varchar](max) NULL,
	[DeviceID] [varchar](max) NULL,
	[VolumeName] [varchar](max) NULL,
	[Size] [varchar](max) NULL,
	[FreeSpace] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[DiskSpace_load]
GO
CREATE TABLE [LOAD].[DiskSpace_load](
	[Host Name] [varchar](max) NULL,
	[DeviceID] [varchar](max) NULL,
	[VolumeName] [varchar](max) NULL,
	[Size] [varchar](max) NULL,
	[FreeSpace] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[EcryptionCertificates]
GO
CREATE TABLE [dbo].[EcryptionCertificates](
	[InstanceName] [nvarchar](128) NULL,
	[Name] [sysname] NOT NULL,
	[pvt_key_encryption_type_desc] [nvarchar](60) NULL,
	[start_date] [datetime] NULL,
	[expiry_date] [datetime] NULL,
	[pvt_key_last_backup_date] [datetime] NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO


DROP TABLE IF EXISTS [LOAD].[EcryptionCertificates_load]
GO
CREATE TABLE [LOAD].[EcryptionCertificates_load](
	  [InstanceName] [varchar](max)  NULL,
      [Name] [varchar](max) NULL
      ,[pvt_key_encryption_type_desc] [varchar](max) NULL
      ,[start_date] [varchar](max) NULL
      ,[expiry_date] [varchar](max) NULL
      ,[pvt_key_last_backup_date] [varchar](max) NULL
	  )

DROP TABLE IF EXISTS [dbo].[ExtendedEvents]
GO
CREATE TABLE [dbo].[ExtendedEvents](
	[InstanceName] [nvarchar](128) NULL,
	[Name] [sysname] NOT NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[ExtendedEvents_load]
GO
CREATE TABLE [LOAD].[ExtendedEvents_load](
	  [InstanceName] [varchar](max)  NULL,
      [Name] [varchar](max) NULL
	  )

DROP TABLE IF EXISTS [dbo].[IdleDatabases]
GO
CREATE TABLE [dbo].[IdleDatabases](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [sysname] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[IdleDatabases_load]
GO
CREATE TABLE [LOAD].[IdleDatabases_load](
	[Instance Name] [varchar](200) NULL,
	[Host Name] [varchar](200) NULL,
	[Database Name] [varchar](200) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[IndexFragmentation]
GO
CREATE TABLE [dbo].[IndexFragmentation](
	[Instance Name] [varchar](128) NULL,
	[Host Name] [varchar](128) NULL,
	[Database Name] [varchar](128) NULL,
	[Table Name] [varchar](128) NULL,
	[Index Size (MB)] [varchar](128) NULL,
	[Max Percentage] [varchar](128) NULL,
	[Average Percentage] [varchar](128) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[IndexFragmentation_load]
GO
CREATE TABLE [LOAD].[IndexFragmentation_load](
	[Instance Name] [varchar](128) NULL,
	[Host Name] [varchar](128) NULL,
	[Database Name] [varchar](128) NULL,
	[Table Name] [varchar](128) NULL,
	[Index Size (MB)] [varchar](128) NULL,
	[Max Percentage] [varchar](128) NULL,
	[Average Percentage] [varchar](128) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[InstanceInformation]
GO
CREATE TABLE [dbo].[InstanceInformation](
	[ID] [int] NULL,
	[Host Name] [varchar](max) NULL,
	[Instance Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[InstanceInformation_load]
GO
CREATE TABLE [LOAD].[InstanceInformation_load](
	[ID] [varchar](max) NULL,
	[Host Name] [varchar](max) NULL,
	[Instance Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [varchar](200) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[IntegrityCheck]
GO
CREATE TABLE [dbo].[IntegrityCheck](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [varchar](max) NULL,
	[State] [varchar](max) NULL,
	[Last Executed] [datetime] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[IntegrityCheck_load]
GO
CREATE TABLE [LOAD].[IntegrityCheck_load](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](100) NULL,
	[Database Name] [varchar](100) NULL,
	[State] [nvarchar](60) NULL,
	[Last Executed] [varchar](100) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[IPs]
GO
CREATE TABLE [dbo].[IPs](
	InstanceName	 [varchar](max) NULL
	,IPname	 [varchar](max) NULL
	,Active  INT NULL	
	,Enabled  INT NULL	
	,IPaddress	 [varchar](max) NULL	
	,Dynamic  INT NULL		
	,port  INT NULL		
	,DisplayName	 [varchar](max) NULL
	,[Client] [varchar](200) NULL
	,[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[IPs_load]
GO
CREATE TABLE [LOAD].[IPs_load](
	InstanceName [varchar](max) NULL	
	,IPname	 [varchar](max) NULL
	,Active	 [varchar](max) NULL
	,Enabled	 [varchar](max) NULL
	,IPaddress	 [varchar](max) NULL
	,Dynamic [varchar](max) NULL	
	,port	 [varchar](max) NULL
	,DisplayName [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[isolation_level_load]
GO
CREATE TABLE [LOAD].[isolation_level_load](
	[Instance name] [varchar](max) NULL
	,[Database Name] [varchar](max) NULL	
	,ALLOW_SNAPSHOT_ISOLATION [varchar](max) NULL	
	,TRANSACTION_ISOLATION_LEVEL [varchar](max) NULL
	)

DROP TABLE IF EXISTS [dbo].[isolation_level]
GO
CREATE TABLE [dbo].[isolation_level](
	[Instance name] [varchar](max) NULL
	,[Database Name] [varchar](max) NULL	
	,ALLOW_SNAPSHOT_ISOLATION [varchar](max) NULL	
	,TRANSACTION_ISOLATION_LEVEL [varchar](max) NULL
	,[Client] [varchar](200) NULL
	,[timestamp] [datetime] NULL
	)

DROP TABLE IF EXISTS [dbo].[Jobs]
GO
CREATE TABLE [dbo].[Jobs](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](100) NULL,
	[Job Name] [sysname] NOT NULL,
	[enabled] [tinyint] NOT NULL,
	[job_id] [varchar](100)NOT NULL,
	[freq_type] [int] NULL,
	[freq_recurrence_factor] [int] NULL,
	[active_start_date] [int] NULL,
	[freq_interval] [int] NULL,
	[freq_relative_interval] [int] NULL,
	[freq_subday_type] [int] NULL,
	[active_start_time] [int] NULL,
	[active_end_time] [int] NULL,
	[freq_subday_interval] [int] NULL,
	[Owner] [sysname] NULL,
	[Client] [varchar](100) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[Jobs_load]
GO
CREATE TABLE [LOAD].[Jobs_load](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](100) NULL,
	[Job Name] [varchar](200) NOT NULL,
	[enabled] [varchar](100) NOT NULL,
	[job_id] [varchar](100) NOT NULL,
	[freq_type] [varchar](100) NULL,
	[freq_recurrence_factor] [varchar](100) NULL,
	[active_start_date] [varchar](100) NULL,
	[freq_interval] [varchar](100) NULL,
	[freq_relative_interval] [varchar](100) NULL,
	[freq_subday_type] [varchar](100) NULL,
	[active_start_time] [varchar](100) NULL,
	[active_end_time] [varchar](100) NULL,
	[freq_subday_interval] [varchar](100) NULL,
	[Owner] [varchar](100) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[JobsScheduler]
GO
CREATE TABLE [dbo].[JobsScheduler](
	[Instance Name][varchar](max) NULL
	,JobName [varchar](max) NULL	
	,TimeZone [varchar](max) NULL	
	,Schedule [varchar](max) NULL	
	,JobOwner [varchar](max) NULL	
	,[Schedule Name] [varchar](max) NULL	
	,[Schedule Enabled] [varchar](max) NULL 
	,[Start date] [varchar](max) NULL 	
	,[End date] [varchar](max) NULL 
	,[Recent Start date] [varchar](max) NULL 
	,[Client] [varchar](100) NULL
	,[timestamp] [datetime] NULL
	)
GO

DROP TABLE IF EXISTS [LOAD].[JobsScheduler_load]
GO
CREATE TABLE [LOAD].[JobsScheduler_load](
	[Instance Name] [varchar](max) NULL
	,JobName [varchar](max) NULL	
	,TimeZone [varchar](max) NULL	
	,Schedule [varchar](max) NULL	
	,JobOwner [varchar](max) NULL	
	,[Schedule Name] [varchar](max) NULL	
	,[Schedule Enabled] [varchar](max) NULL
	,[Start date] [varchar](max) NULL	
	,[End date] [varchar](max) NULL
	,[Recent Start date] [varchar](max) NULL
	)
GO

DROP TABLE IF EXISTS [dbo].[ifi_lim]
GO
CREATE TABLE [dbo].[ifi_lim](
	[Host Name] [varchar](200) NULL,
	[Service] [varchar](200) NULL,
	[Name] [varchar](200) NULL,
	[User] [varchar](200) NULL,
	[LockPages] [int] NULL,
	[InstantInit] [int] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[ifi_lim_load]
GO
CREATE TABLE [LOAD].[ifi_lim_load](
	[Host Name] [varchar](200) NULL,
	[Service] [varchar](200) NULL,
	[Name] [varchar](200) NULL,
	[User] [varchar](200) NULL,
	[LockPages] [varchar](200) NULL,
	[InstantInit] [varchar](200) NULL
	--,[Client] [varchar](200) NULL,
	--[timestamp] [varchar](200) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[MaintenencePlans]
GO
CREATE TABLE [dbo].[MaintenencePlans](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Name] [sysname] NULL,
	[Owner] [sysname] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[MaintenencePlans_load]
GO
CREATE TABLE [LOAD].[MaintenencePlans_load](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Name] [sysname] NULL,
	[Owner] [sysname] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[MSDB]
GO
CREATE TABLE [dbo].[MSDB](
	[ServerName] [nvarchar](128) NULL,
	[name] [sysname] NOT NULL,
	[DataFileSizeMB] [int] NULL,
	[MSDB_used] [varchar](30) NULL,
	[LogFileSizeMB] [int] NULL,
	[LS_history] [int] NULL,
	[LS_errors] [int] NULL,
	[Job_History] [int] NULL,
	[Backup_Files] [int] NULL,
	[Backup_Set] [int] NULL,
	[backupmediafamily] [int] NULL,
	[logmarkhistory] [int] NULL,
	[sysmail_attachments] [int] NULL,
	[sysmail_log] [int] NULL,
	[sysmail_send_retries] [int] NULL,
	[sysmail_allitems] [int] NULL,
	[transmission_queue] [int] NULL,
	[sysdtslog90] [int] NULL,
	[sysmaintplan_log] [int] NULL,
	[sysmaintplan_logdetail] [int] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[MSDB_load]
GO
CREATE TABLE [LOAD].[MSDB_load](
	[ServerName] [varchar](200) NULL,
	[name] [varchar](200) NOT NULL,
	[DataFileSizeMB] [varchar](200) NULL,
	[MSDB_used] [varchar](200) NULL,
	[LogFileSizeMB] [varchar](200) NULL,
	[LS_history] [varchar](200) NULL,
	[LS_errors] [varchar](200) NULL,
	[Job_History] [varchar](200) NULL,
	[Backup_Files] [varchar](200) NULL,
	[Backup_Set] [varchar](200) NULL,
	[backupmediafamily] [varchar](200) NULL,
	[logmarkhistory] [varchar](200) NULL,
	[sysmail_attachments] [varchar](200) NULL,
	[sysmail_log] [varchar](200) NULL,
	[sysmail_send_retries] [varchar](200) NULL,
	[sysmail_allitems] [varchar](200) NULL,
	[transmission_queue] [varchar](200) NULL,
	[sysdtslog90] [varchar](200) NULL,
	[sysmaintplan_log] [varchar](200) NULL,
	[sysmaintplan_logdetail] [varchar](200) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[OperationSystem]
GO
CREATE TABLE [dbo].[OperationSystem](
	[ID] [int] NULL,
	[Host Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[OperationSystem_load]
GO
CREATE TABLE [LOAD].[OperationSystem_load](
	[ID] [varchar](max) NULL,
	[Host Name] [varchar](max) NULL,
	[Instance Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[OrphanUsers]
GO
CREATE TABLE [dbo].[OrphanUsers](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [sysname] NULL,
	[User Name] [varchar](200) NULL,
	[Status] [varchar](200) NULL,
	[Type] [varchar](200) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[OrphanUsers_load]
GO
CREATE TABLE [LOAD].[OrphanUsers_load](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](150) NULL,
	[Database Name] [sysname] NULL,
	[User Name] [varchar](200) NULL,
	[Status] [varchar](200) NULL,
	[Type] [varchar](200) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[ServerRoles]
GO
CREATE TABLE [dbo].[ServerRoles](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [nvarchar](50) NULL,
	[Role] [sysname] NULL,
	[User name] [sysname] NULL,
	[Type] [nvarchar](60) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[ServerRoles_load]
GO
CREATE TABLE [LOAD].[ServerRoles_load](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [nvarchar](50) NULL,
	[Role] [sysname] NULL,
	[User name] [sysname] NULL,
	[Type] [nvarchar](60) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[Services]
GO
CREATE TABLE [dbo].[Services](
	[Host Name] [varchar](200) NULL,
	[Service Name] [varchar](200) NULL,
	[Account] [varchar](200) NULL,
	[Startup] [varchar](200) NULL,
	[Status] [varchar](200) NULL,
	[PathName] [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[Services_load]
GO
CREATE TABLE [LOAD].[Services_load](
	[Host Name] [varchar](200) NULL,
	[Service Name] [varchar](200) NULL,
	[Account] [varchar](200) NULL,
	[Startup] [varchar](200) NULL,
	[Status] [varchar](200) NULL,
	[PathName] [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [varchar](200) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[Hardware]
GO
CREATE TABLE [dbo].[Hardware](
	[ID] [int] NULL,
	[Host Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[Hardware_load]
GO
CREATE TABLE [LOAD].[Hardware_load](
	[ID] [varchar](max) NULL,
	[Host Name] [varchar](max) NULL,
	[Instance Name] [varchar](max) NULL,
	[Type] [varchar](max) NULL,
	[Value] [varchar](max) NULL,
	[Client] [varchar](max) NULL,
	[timestamp] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[UpdateStatistics]
GO
CREATE TABLE [dbo].[UpdateStatistics](
	[Instance Name] [varchar](50) NULL,
	[Host Name] [nvarchar](max) NULL,
	[Database Name] [varchar](max) NULL,
	[Last Executed] [datetime] NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[UpdateStatistics_load]
GO
CREATE TABLE [LOAD].[UpdateStatistics_load](
	[Instance Name] [varchar](150) NULL,
	[Host Name] [nvarchar](150) NULL,
	[Database Name] [varchar](150) NULL,
	[Last Executed] [nvarchar](150) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[VirtualLogFile]
GO
CREATE TABLE [dbo].[VirtualLogFile](
	[Instance Name] [varchar](max) NULL,
	[Host Name] [nvarchar](max) NULL,
	[Database Name] [varchar](max) NULL,
	[Count] [varchar](20) NULL,
	[Total Size (MB)] [varchar](20) NULL,
	[Average Size (MB)] [varchar](20) NULL,
	[Auto-growth] [varchar](20) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[VirtualLogFile_load]
GO
CREATE TABLE [LOAD].[VirtualLogFile_load](
	[Instance Name] [varchar](50) NULL,
	[Host Name] [nvarchar](50) NULL,
	[Database Name] [varchar](150) NULL,
	[Count] [varchar](20) NULL,
	[Total Size (MB)] [varchar](20) NULL,
	[Average Size (MB)] [varchar](20) NULL,
	[Auto-growth] [varchar](20) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [LOAD].[MissedIndexes_load]
GO
CREATE TABLE [LOAD].[MissedIndexes_load](
	[Instance Name]	 [varchar](max) NULL
	,[DatabaseName]	 [varchar](max) NULL
	,TableName	 [varchar](max) NULL
	,improvement_measure  [varchar](max) NULL	
	,create_index_statement  [varchar](max) NULL
	)

DROP TABLE IF EXISTS [dbo].[MissedIndexes]
GO
CREATE TABLE [dbo].[MissedIndexes](
	[Instance Name]	 [varchar](max) NULL
	,[DatabaseName]	 [varchar](max) NULL
	,TableName	 [varchar](max) NULL
	,improvement_measure  [varchar](max) NULL	
	,create_index_statement  [varchar](max) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
	)

DROP TABLE IF EXISTS [LOAD].[QueryStore_load]
GO
CREATE TABLE [LOAD].[QueryStore_load](
	InstanceName		 [varchar](max) NULL
	,DatabaseName		 [varchar](max) NULL
	,desired_state_desc		 [varchar](max) NULL
	,actual_state_desc		 [varchar](max) NULL
	,max_storage_size_mb	 [varchar](max) NULL
	)

DROP TABLE IF EXISTS [dbo].[QueryStore]
GO
CREATE TABLE [dbo].[QueryStore](
	InstanceName		 [varchar](max) NULL
	,DatabaseName		 [varchar](max) NULL
	,desired_state_desc		 [varchar](max) NULL
	,actual_state_desc		 [varchar](max) NULL
	,max_storage_size_mb 	 [varchar](max) NULL
	,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
	)

DROP TABLE IF EXISTS [LOAD].[SSIScatalogue_load]
GO
CREATE TABLE [LOAD].[SSIScatalogue_load](
	InstanceName 	 [varchar](max) NULL	
	,NAME 	 [varchar](max) NULL	
	,RETENTION_WINDOW 	 [varchar](max) NULL	
	,MAX_PROJECT_VERSIONS		 [varchar](max) NULL
	,SERVER_LOGGING_LEVEL		 [varchar](max) NULL
	,Location		 [varchar](max) NULL
	,DatabaseSize 	 [varchar](max) NULL
	)

DROP TABLE IF EXISTS [dbo].[SSIScatalogue]
GO
CREATE TABLE [dbo].[SSIScatalogue](
	InstanceName 	 [varchar](max) NULL	
	,NAME 	 [varchar](max) NULL	
	,RETENTION_WINDOW 	 INT NULL	
	,MAX_PROJECT_VERSIONS		 INT NULL
	,SERVER_LOGGING_LEVEL		 INT NULL
	,Location		 [varchar](max) NULL
	,DatabaseSize 	INT NULL
	,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
	)


DROP TABLE IF EXISTS [LOAD].[StartupProcedures_load]
GO
CREATE TABLE [LOAD].[StartupProcedures_load](
	InstanceName [varchar](max) NULL		
	,StartupProcedure [varchar](max) NULL	
	)

DROP TABLE IF EXISTS [dbo].[StartupProcedures]
GO
CREATE TABLE [dbo].[StartupProcedures](
	InstanceName [varchar](max) NULL		
	,StartupProcedure [varchar](max) NULL	
	,[Client] [varchar](200) NULL
	,[timestamp] [datetime] NULL
	)

DROP TABLE IF EXISTS [LOAD].[TDEencryption_load]
GO
CREATE TABLE [LOAD].[TDEencryption_load](
	InstanceName [varchar](max) NULL		
	,database_name [varchar](max) NULL			
	,encryption_state [varchar](max) NULL			
	,encryption_state_desc [varchar](max) NULL			
	,create_date [varchar](max) NULL		
	,set_date [varchar](max) NULL	
	)

DROP TABLE IF EXISTS [dbo].[TDEencryption]
GO
CREATE TABLE [dbo].[TDEencryption](
	InstanceName [varchar](max) NULL		
	,database_name [varchar](max) NULL			
	,encryption_state [varchar](max) NULL			
	,encryption_state_desc [varchar](max) NULL			
	,create_date [varchar](max) NULL	
	,set_date [varchar](max) NULL	
	,[Client] [varchar](200) NULL
	,[timestamp] [datetime] NULL
	)

DROP TABLE IF EXISTS [LOAD].[Traces_load]
GO
CREATE TABLE [LOAD].[Traces_load](
		InstanceName [varchar](max) NULL, 
		id [varchar](max) NULL,
		status [varchar](max) NULL,
		Path [varchar](max) NULL,
		start_time [varchar](max) NULL,
		last_event_time [varchar](max) NULL
	)

DROP TABLE IF EXISTS [dbo].[Traces]
GO
CREATE TABLE [dbo].[Traces](
	InstanceName [varchar](max) NULL, 
		id INT NULL,
		status INT NULL,
		Path [varchar](max) NULL,
		start_time [datetime] NULL,
		last_event_time [datetime] NULL
	,[Client] [varchar](200) NULL
	,[timestamp] [datetime] NULL
	)

DROP TABLE IF EXISTS [LOAD].[UnusedIndexes_load]
GO
CREATE TABLE [LOAD].[UnusedIndexes_load](
	InstanceName [varchar](max) NULL
	,DatabaseName [varchar](max) NULL	
	,SchemaName	 [varchar](max) NULL
	,ObjectName	 [varchar](max) NULL
	,IndexName  [varchar](max) NULL
	)

DROP TABLE IF EXISTS [dbo].[UnusedIndexes]
GO
CREATE TABLE [dbo].[UnusedIndexes](
	InstanceName [varchar](max) NULL
	,DatabaseName [varchar](max) NULL	
	,SchemaName	 [varchar](max) NULL
	,ObjectName	 [varchar](max) NULL
	,IndexName  [varchar](max) NULL
	,[Client] [varchar](200) NULL
	,[timestamp] [datetime] NULL
	)


DROP TABLE IF EXISTS [LOAD].[Backups_load]
GO
CREATE TABLE [LOAD].[Backups_load](
	[Instance Name] [varchar](max) NULL,
	[Host Name] [varchar](max) NULL,
	[Database Name] [varchar](max) NULL,
	[Recovery Model] [varchar](max) NULL,
	[Recent Full Database] [varchar](max) NULL,
	[Recent Transaction Log] [varchar](max) NULL
) ON [PRIMARY]
GO

DROP TABLE IF EXISTS [dbo].[Backups]
GO
CREATE TABLE [dbo].[Backups](
	[Instance Name] [nvarchar](128) NULL,
	[Host Name] [varchar](50) NULL,
	[Database Name] [sysname] NULL,
	[Recovery Model] [nvarchar](60) NULL,
	[Recent Full Database] [varchar](20) NULL,
	[Recent Transaction Log] [varchar](20) NULL,
	[Client] [varchar](200) NULL,
	[timestamp] [datetime] NULL
) ON [PRIMARY]
GO

----------------------

--DROP VIEW IF EXISTS [dbo].[vw_DatabaseBackups]
--GO
--CREATE VIEW [dbo].[vw_DatabaseBackups]
--AS 
--SELECT 
--	[Client]					AS [Client],
--	[Host Name]					AS [Host Name],
--	[Instance Name]				AS [Instance Name],
--	[Database Name]				AS [Database Name],
--	[Recovery Model]			AS [Recovery Model],
--	[Recent Full Database]		AS [Recent Full Database],
--	[Recent Transaction Log]	AS [Recent Transaction Log]
--	 ,[timestamp]
--FROM [dbo].[Backups]
--GO
