﻿cls
# secpol.msc    - lock in memory, instant file initiation
# https://docs.microsoft.com/en-us/sql/database-engine/configure-windows/enable-the-lock-pages-in-memory-option-windows
# https://blogs.msdn.microsoft.com/sql_pfe_blog/2009/12/22/how-and-why-to-enable-instant-file-initialization/

# https://sarafian.github.io/2016/05/19/invoke-command-local-or-remote.html

$Updates = "No" # "Yes"

$Path = split-path -parent $MyInvocation.MyCommand.Definition 
$RunTime = Get-Date  
$ScanReport =  'Hosts_LMI_IFI_' `
    + $RunTime.Year.ToString() `
    + ("0"+$RunTime.Month.ToString()).SUBSTRING(("0"+$RunTime.Month.ToString()).Length-2) `
    + ("0"+$RunTime.Day.ToString()).SUBSTRING(("0"+$RunTime.Day.ToString()).Length-2) + "_" `
    + ("0"+$RunTime.Hour.ToString()).SUBSTRING(("0"+$RunTime.Hour.ToString()).Length-2) `
    + ("0"+$RunTime.Minute.ToString()).SUBSTRING(("0"+$RunTime.Minute.ToString()).Length-2) `
    + ("0"+$RunTime.Second.ToString()).SUBSTRING(("0"+$RunTime.Second.ToString()).Length-2)  + ".txt"

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) { Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!";  Break }
if ((Test-Path -Path $Path ) -ne $true) { Write-Warning "The folder '$Path' doesn't exists!"; Break }
if ((Test-Path $Path\hosts.txt) -ne $true) { Write-Warning "The file 'hosts.txt' doesn't exists in the folder $Path!"; Break } 

$block={ param($isUpdate)
    $procs = Get-CimInstance -Query 'Select * from Win32_Process where name like "%sqlservr.exe%"'

    $LimIfiTableINT = New-Object System.Data.DataTable
    $LimIfiTableINT.Columns.Add("Host",       "System.String")     | Out-Null  
    $LimIfiTableINT.Columns.Add("Service",    "System.String")     | Out-Null  
    $LimIfiTableINT.Columns.Add("Name",       "System.String")     | Out-Null
    $LimIfiTableINT.Columns.Add("User",       "System.String")     | Out-Null
    $LimIfiTableINT.Columns.Add("LockPages",  "System.String")     | Out-Null
    $LimIfiTableINT.Columns.Add("InstantInit","System.String")     | Out-Null
    $LimIfiTableINT.Columns.Add("Action",     "System.String")     | Out-Null  

    foreach ($proc in $procs)
        {
            $Service = Get-CimInstance -Query 'Select * from Win32_Service where name like "mssql%"' | Where-object {$_.ProcessId -eq $proc.ProcessId} 
            $CimMethod = Invoke-CimMethod -InputObject $proc -MethodName GetOwner
            $objUser = New-Object System.Security.Principal.NTAccount($CimMethod.Domain, $CimMethod.User)
            $strSID = $objUser.Translate([System.Security.Principal.SecurityIdentifier])
            $NTName = $strSID.Value  # SQL Server account 
            $ManageVolumePriv = "No"
            $LockPagesPriv = "No"
            
            $guid = ([guid]::NewGuid()).ToString()
            $P = "C:\$guid"
            if ((Test-Path -Path $P ) -ne $true) { New-item -Path $P -ItemType Directory > NULL }

            $Action = ""
            secedit /export /areas USER_RIGHTS /cfg $P\UserRights_upd.inf /quiet
            $FileResults = Get-Content $P\UserRights_upd.inf

            foreach ($line in $FileResults)
            {
                $SeManageVolumePrivilegeFound = 0 
                $SeLockMemoryPrivilegeFound = 0 

                if ($line -like "SeManageVolumePrivilege*") 
                    {   $SeManageVolumePrivilegeFound = 1 
                        if ($line -like "*$NTName*") { $ManageVolumePriv = "Yes" }}

                if ($line -like "SeLockMemoryPrivilege*")
                    {   $SeLockMemoryPrivilegeFound = 1
                        if ($line -like "*$NTName*") { $LockPagesPriv = "Yes" }}

                if ( $isUpdate -eq "Yes" ) {
	                # setting flag SeManageVolumePrivilege	
                    if  ($SeManageVolumePrivilegeFound -eq 1){ 
                        if ($ManageVolumePriv -eq "No") {
                            # ManageVolumePriv line exists but not set
                            if ($Action.Length -ne 0) { $Action = $Action + ", "}
                            $Action = $Action + "SeManageVolumePrivilege line exists, parameter not set and setting now"
                            $line = Get-Content $P\UserRights_upd.inf | Select-String 'SeManageVolumePrivilege'
                            (Get-Content $P\UserRights_upd.inf).Replace($line,"$line,$objUser") | Out-File $P\UserRights_upd.inf
                            $ManageVolumePriv = "Set"
                        }
	                } else { if ($Action.Length -ne 0 -and $SeManageVolumePrivilegeFound -eq 1) { $Action = $Action + ", "} }

	                # setting flag SeLockMemoryPrivilegeFound	
                    if  ($SeLockMemoryPrivilegeFound -eq 1){ 
                        if ($LockPagesPriv -eq "No") {
                            # ManageVolumePriv line exists but not set
                            if ($Action.Length -ne 0) { $Action = $Action + ", "}
                            $Action = $Action + "SeLockMemoryPrivilege line exists, parameter not set and setting now"
                            $line = Get-Content $P\UserRights_upd.inf | Select-String 'SeLockMemoryPrivilege'
                            (Get-Content $P\UserRights_upd.inf).Replace($line,"$line,$objUser") | Out-File $P\UserRights_upd.inf
                            $LockPagesPriv = "Set"
                        } else { if ($Action.Length -ne 0 -and $SeLockMemoryPrivilegeFound -eq 1) { $Action = $Action + ", "} }
	                }
                }

            }
            if ( $isUpdate -eq "Yes" ) { 

                if  (($ManageVolumePriv -eq "No") -and ($isUpdate -eq "Yes")) {
                        #line doesn't exists. Try to add    
                        $ManageVolumePriv = "Set"
                        $upd = "SeManageVolumePrivilege = $objUser`r`n" 
                        $line = Get-Content $P\UserRights_upd.inf | Select-String 'Version'
                        (Get-Content $P\UserRights_upd.inf).Replace($line,"$upd$line") | Out-File $P\UserRights_upd.inf
                        if ($Action.Length -ne 0) { $Action = $Action + ", Line SeManageVolumePrivilege is added"} else {  $Action =  "Line SeManageVolumePrivilege is added" }
                    }

                if  (($LockPagesPriv -eq "No") -and ($isUpdate -eq "Yes")) {
                        #line doesn't exists. Try to add    
                        $LockPagesPriv = "Set"
                        $upd = "SeLockMemoryPrivilege = $objUser`r`n" 
                        $line = Get-Content $P\UserRights_upd.inf | Select-String 'Version'
                        (Get-Content $P\UserRights_upd.inf).Replace($line,"$upd$line") | Out-File $P\UserRights_upd.inf
                        if ($Action.Length -ne 0) { $Action = $Action + ", Line SeLockMemoryPrivilege is added"} else {  $Action =  "Line SeLockMemoryPrivilege is added" }
                    }

                Secedit /import /db secedit.sdb /cfg "$P\UserRights_upd.inf"  /quiet
                Secedit /configure /db secedit.sdb /quiet
                Secedit /refreshpolicy machine_policy /enforce /quiet
            } 
            if ($Action.Length -eq 0) { $Action = "No changes made"}
            Remove-Item $P\UserRights_upd.inf
            Remove-Item $P -Force 
            $LocalSvr = get-content env:computername
            $LimIfiTableINT.Rows.Add( $LocalSvr, $Service.Caption, $Service.Name, $objUser.Value, $LockPagesPriv, $ManageVolumePriv, $Action) | Out-Null 
    }
    Return $LimIfiTableINT
}

# list of hosts for checking
$ServerList = Get-Content $Path\hosts.txt
#$ServerList = @('BCSADLNB73')

"Started " + (Get-Date)
$RunningHost = [System.Net.Dns]::GetHostName()
Write-Host "Lock in memory, instant file initiation check script running from $RunningHost host" -ForegroundColor Green
Write-Host "Reports location: $Path\$ScanReport" -fore Green
if ( $Updates -eq "Yes" ) { Write-Host "Flags will be updated" -ForegroundColor Yellow } else { Write-Host "Collecting information" -ForegroundColor Green }
 
$LimIfiTable = New-Object System.Data.DataTable
$LimIfiTable.Columns.Add("Host",       "System.String")     | Out-Null  
$LimIfiTable.Columns.Add("Service",    "System.String")     | Out-Null  
$LimIfiTable.Columns.Add("Name",       "System.String")     | Out-Null
$LimIfiTable.Columns.Add("User",       "System.String")     | Out-Null
$LimIfiTable.Columns.Add("LockPages",  "System.String")     | Out-Null
$LimIfiTable.Columns.Add("InstantInit","System.String")     | Out-Null
$LimIfiTable.Columns.Add("Action",     "System.String")     | Out-Null  

$I = $ServerList.Count
$ii = 0 

foreach ($HostName in $ServerList)
{   $ii += 1
    if (($HostName -eq '') -or ($HostName.Substring(0,4) -eq 'REM ')) { Write-Host "Skipping $ii of $I - $HostName" -fore Gray; Continue } # Ignore empty or REM string 
    Write-Host "Checking $ii of $I - $HostName" -fore Gray

    if ($HostName -eq [System.Net.Dns]::GetHostName()) { $Rep = Invoke-Command -ScriptBlock $block -ArgumentList "$Updates" }
                                                  else { $Rep = Invoke-Command -ComputerName $HostName -ScriptBlock $block -ArgumentList "$Updates" }

    $LimIfiTable = $LimIfiTable + $Rep
}

$LimIfiTable | SELECT Host, Service, Name, User, LockPages, InstantInit, Action  | Export-Csv -Path $Path\$ScanReport -NoTypeInformation
"Finished " + (Get-Date)

