SELECT TOP (1000) [Host Name]
      ,[DeviceID]
      ,[VolumeName]
      ,Cast([Size] AS BIGINT) /1024 /1024 /1024 AS [Size Gb]
      --,[FreeSpace]
	  ,(Cast([FreeSpace] AS BIGINT)*100/Cast([Size] AS BIGINT)) AS Pers
      --,[Client]
      --,[timestamp]
  FROM [HC_AAL].[dbo].[DiskSpace]
  WHERE (Cast([FreeSpace] AS BIGINT)*100/Cast([Size] AS BIGINT))  <=40
  --WHERE (Cast([FreeSpace] AS BIGINT)*100/Cast([Size] AS BIGINT))  <=15