SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
		 SERVERPROPERTY('MachineName') AS [Host Name],
		t1.name AS [Database Name], 
		t1.recovery_model_desc AS [Recovery Model], 
		t1.date AS [Recent Full Database], 
		t2.date AS [Recent Transaction Log] 
	FROM (SELECT t1.name, t1.recovery_model_desc, COALESCE(Convert(varchar(20), MAX(t2.backup_finish_date), 120),'') date
		FROM sys.databases t1 LEFT OUTER JOIN msdb.dbo.backupset t2
		ON t2.database_name = t1.name AND t2.type= 'D'
		GROUP BY t1.name, t1.recovery_model_desc
		) t1, 
		(SELECT t1.name, t1.recovery_model_desc, 
		CASE t1.recovery_model_desc 
		WHEN 'SIMPLE' THEN ''
		ELSE COALESCE(Convert(varchar(20), MAX(t2.backup_finish_date), 120),'')
		END date
		FROM sys.databases t1 LEFT OUTER JOIN msdb.dbo.backupset t2
		ON t2.database_name = t1.name AND t2.type= 'L' 
		GROUP BY t1.name, t1.recovery_model_desc
		) t2 
	WHERE t1.name= t2.name AND t1.name <> 'tempdb'