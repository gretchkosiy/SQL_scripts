IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##compression')			
	DROP TABLE ##compression

CREATE TABLE ##compression (
	[InstanceName] VARCHAR(MAX),
	DatabaseName VARCHAR(MAX),
	[Table] VARCHAR(MAX),
	[Partition] VARCHAR(MAX),
	[Compression] VARCHAR(MAX),
	[Index] VARCHAR(MAX))

INSERT INTO ##compression 
EXEC sp_MSforeachdb 'USE [?] 
SELECT DISTINCT
	@@SERVERNAME AS [InstanceName],
	DB_NAME() AS DatabaseName,
	''['' + [ss].[name] + ''].['' + [t].[name] + '']'' AS [Table]
	,[p].[partition_number] AS [Partition]
	,[p].[data_compression_desc] AS [Compression]
	,CASE WHEN [i].[name] IS NULL THEN ''<<< HEAP >>>'' ELSE [i].[name] END AS [Index]
FROM [sys].[partitions] AS [p]
INNER JOIN sys.tables AS [t] ON [t].[object_id] = [p].[object_id]
INNER JOIN sys.schemas ss on ss.schema_id = t.schema_id
INNER JOIN sys.indexes AS [i] ON [i].[object_id] = [p].[object_id] AND [i].[index_id] = [p].[index_id]
--WHERE [p].[data_compression_desc] != ''NONE'''

SELECT * FROM ##compression
DROP TABLE ##compression