SELECT
	@@SERVERNAME AS [InstanceName],
	SK.name AS [KeyName],
	SP.name AS [PrincipalName],
	SK.create_date,
	SK.modify_date
FROM master.sys.symmetric_keys AS SK 
	left join  master.sys.server_principals SP on SP.sid = sk.principal_id
WHERE SK.name = '##MS_DatabaseMasterKey##'