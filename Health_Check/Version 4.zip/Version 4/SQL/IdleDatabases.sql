IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##idle_database')   
DROP TABLE ##idle_database    
CREATE TABLE ##idle_database   (dbname sysname, last_user_seek datetime, last_user_scan datetime, last_user_lookup datetime, last_user_update datetime)    
EXEC sp_MSforeachdb 'USE [?]   
INSERT ##idle_database  SELECT DB_NAME(), MAX(last_user_seek), MAX(last_user_scan), MAX(last_user_lookup), MAX(last_user_update)  
FROM sys.stats st  INNER JOIN sys.all_objects al  
ON (st.object_id = al.object_id) AND al.name not in(''dtproperties'') AND al.type_desc= ''USER_TABLE''  
INNER JOIN sys.dm_db_index_usage_stats iu  ON OBJECT_NAME(iu.OBJECT_ID) = al.name AND iu.database_id= DB_ID()'  
SELECT @@servername AS [Instance Name],    SERVERPROPERTY('MachineName') AS [Host Name], dbname  
FROM ##idle_database t2  
WHERE DATABASEPROPERTYEX(dbname, 'Status')= 'ONLINE'  AND (last_user_seek IS NULL AND last_user_scan IS NULL AND last_user_lookup IS NULL AND last_user_update IS NULL)  OR (DATEDIFF(dd, last_user_seek, GETDATE())>=60 OR DATEDIFF(dd, last_user_scan, GETDATE())>=60 OR DATEDIFF(dd, last_user_lookup, GETDATE())>=60 OR DATEDIFF(dd, last_user_update, GETDATE())>=60)
