SELECT
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
		SERVERPROPERTY('MachineName') AS [Host Name],
		msdb.dbo.sysjobs.name as [Job Name],
		msdb.dbo.sysjobs.enabled enabled,
		msdb.dbo.sysjobs.job_id job_id,
		msdb.dbo.sysschedules.freq_type freq_type,
		msdb.dbo.sysschedules.freq_recurrence_factor freq_recurrence_factor,
		msdb.dbo.sysschedules.active_start_date active_start_date,
		msdb.dbo.sysschedules.freq_interval freq_interval,
		msdb.dbo.sysschedules.freq_relative_interval freq_relative_interval,
		msdb.dbo.sysschedules.freq_subday_type freq_subday_type,
		msdb.dbo.sysschedules.active_start_time active_start_time,
		msdb.dbo.sysschedules.active_end_time active_end_time,
		msdb.dbo.sysschedules.freq_subday_interval freq_subday_interval,
		master.sys.syslogins.name AS [Owner]
   --INTO Jobs
   FROM         msdb.dbo.sysjobs 
				LEFT OUTER JOIN msdb.dbo.sysjobschedules ON msdb.dbo.sysjobs.job_id = msdb.dbo.sysjobschedules.job_id 
				LEFT OUTER JOIN msdb.dbo.sysschedules ON msdb.dbo.sysjobschedules.schedule_id = msdb.dbo.sysschedules.schedule_id
				LEFT OUTER JOIN master.sys.syslogins on msdb.dbo.sysjobs.owner_sid = master.sys.syslogins.sid