IF exists (Select 1 from master.sys.databases where name = 'SSISDB')
	Select 
		@@SERVERNAME as InstanceName,
		NAME,
		(SELECT [property_value] FROM [SSISDB].[internal].[catalog_properties] where [property_name] IN ('RETENTION_WINDOW')) AS RETENTION_WINDOW,
		(SELECT [property_value] FROM [SSISDB].[internal].[catalog_properties] where [property_name] IN ('MAX_PROJECT_VERSIONS')) AS MAX_PROJECT_VERSIONS,
		(SELECT [property_value] FROM [SSISDB].[internal].[catalog_properties] where [property_name] IN ('SERVER_LOGGING_LEVEL')) AS SERVER_LOGGING_LEVEL,
		CASE 
			WHEN EXISTS(SELECT 1  
						FROM master.sys.master_files
						where physical_name  like '%SSISDB%'
						AND REPLACE(REPLACE(REPLACE(physical_name,'SSISDB',''),'mdf',''),'ldf','') 
							IN (SELECT DISTINCT 
								  REPLACE(REPLACE(REPLACE(physical_name,'master',''),'mdf',''),'ldf','') 
								FROM master.sys.master_files
								where physical_name  like '%master%')) THEN 'Attention - SSISDB on system loction'
			ELSE 'OK - SSISDB is not system loction'
		END [Location]
		,(SELECT SUM(size * 8/1024) FROM master.sys.master_files where physical_name  like '%SSISDB%') AS  DatabaseSize
	from master.sys.databases 
	where name = 'SSISDB'
