IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##vlf_db_detail')			DROP TABLE ##vlf_db_detail
IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##VLF_temp')				DROP TABLE ##VLF_temp
IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##VLF_db_total_temp')		DROP TABLE ##VLF_db_total_temp

CREATE TABLE ##vlf_db_detail(
	rowid int IDENTITY(1, 1),
	dbname sysname,
	vlf_count varchar(20),
	total_size varchar(20),
	avg_size varchar(20),
	auto_growth varchar(20)
)

DECLARE @vvchSQLServerversion varchar(128)
SELECT @vvchSQLServerversion = CAST(SERVERPROPERTY('productversion') AS VARCHAR(MAX))
DECLARE @SQLtxt varchar(512)


IF LEFT(@vvchSQLServerversion COLLATE DATABASE_DEFAULT, 3) = '10.' OR LEFT(@vvchSQLServerversion COLLATE DATABASE_DEFAULT, 2) = '9.'
BEGIN
       -- SQL SERVER VERSION 2005, 2008, 2008 R2 
       SET @SQLtxt = '
       CREATE TABLE ##VLF_temp (FileID varchar(3), FileSize numeric(20,0),
       StartOffset bigint, FSeqNo bigint, Status char(1),
       Parity varchar(4), CreateLSN numeric(25,0))'
END
ELSE
BEGIN
       -- SQL SERVER VERSION 2012 OR LATER
       SET @SQLtxt = '
       CREATE TABLE ##VLF_temp (RecoveryUnitID int, FileID varchar(3), FileSize numeric(20,0),
       StartOffset bigint, FSeqNo bigint, Status char(1),
       Parity varchar(4), CreateLSN numeric(25,0))'
END
EXEC(@SQLtxt)
CREATE TABLE ##VLF_db_total_temp(name sysname, vlf_count int)
DECLARE db_cursor CURSOR READ_ONLY FOR SELECT name FROM master.sys.databases where state_desc <> 'OFFLINE'
DECLARE @stmt varchar(40)
DECLARE @dbname sysname

OPEN db_cursor
FETCH NEXT FROM db_cursor INTO @dbname
WHILE (@@fetch_status <> -1)
BEGIN
       IF (@@fetch_status <> -2)
       BEGIN
       INSERT INTO ##VLF_temp
       EXEC ('DBCC LOGINFO ([' + @dbname + ']) WITH NO_INFOMSGS')
       INSERT INTO ##VLF_db_total_temp SELECT @dbname, COUNT(*) FROM ##VLF_temp
       TRUNCATE TABLE ##VLF_temp
       END
       FETCH NEXT FROM db_cursor INTO @dbname
END

CLOSE db_cursor
DEALLOCATE db_cursor

INSERT INTO ##vlf_db_detail
SELECT v.name, 
	CONVERT(varchar(20), vlf_count),
	CONVERT(varchar(20), d.Total_Log_Size_MB),
	CONVERT(varchar(20), CAST(d.Total_Log_Size_MB/vlf_count AS decimal(18,2))),
	CONVERT(varchar(20), d.Log_Growth) + ' ' + d.Growth_Type
FROM ##VLF_db_total_temp v
INNER JOIN (
       select d.name as Name, 
              CAST(m.size/128.0 AS DECIMAL(18,2)) as Total_Log_Size_MB,
              case is_percent_growth
                     when 0 then m.growth/128
                     else m.growth
              end as Log_Growth,
              case is_percent_growth
                     when 0 then 'mb'
                     else 'percent(s)'
              end as Growth_Type
       from sys.databases d
       inner join sys.master_files m
       on d.database_id = m.database_id
       where m.type = 1
) d
ON v.name = d.Name
WHERE vlf_count >= 1
ORDER BY vlf_count DESC

SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
	SERVERPROPERTY('MachineName') AS [Host Name],
	dbname  as [Database Name],
	vlf_count as [count],
	total_size as [Total Size (MB)],
	avg_size as [Average Size (MB)],
	auto_growth as [Auto-growth]
FROM ##vlf_db_detail