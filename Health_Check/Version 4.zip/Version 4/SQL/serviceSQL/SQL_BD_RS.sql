


select 'Jobs' AS ObjName, [InstanceName], name
from (	
    SELECT MAX([InstanceName]) AS InstanceName , name
    FROM tempdb.dbo.AAG_Jobs
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_Jobs) S)) U
UNION
select 'Linked Server' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_LS
    GROUP BY Name, 
        provider
        ,data_source
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_LS) S)) u

UNION
select 'Login' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name, sid
    FROM tempdb.dbo.AAG_logins
    GROUP BY Name, sid
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_logins) S)) u

UNION
select 'Notification' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_notifications
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_notifications) S)) u


UNION
select 'Extended Procedure' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_EXproc
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_EXproc) S)
  ) u

UNION
select DISTINCT 'Credential' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_credentials
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_credentials) S)) u


UNION
select 'Trigger' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_triggers
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_triggers) S)
  ) u

UNION
select 'Procedure' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_procedures
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_procedures) S)
  ) u

UNION
select 'End-point' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_endpoints
    GROUP BY Name
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_endpoints) S)
  ) u

UNION
select 'Cross-Database' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_CrossDatabaseQueries
    WHERE Name in (Select distinct dg.Database_name
					from master.sys.dm_hadr_database_replica_cluster_states dg
					INNER join master.sys.availability_replicas ar on ar.replica_id = dg.replica_id
					lEFT join master.sys.availability_groups ag on ag.group_id = ar.group_id
					WHERE ag.name IN (select distinct ag.name as [name]
									from sys.dm_hadr_availability_replica_states ars
									inner join sys.availability_groups ag on ag.group_id = ars.group_id 
									where ars.role_desc = 'PRIMARY'))
    GROUP BY Name, [is_trustworthy_on],[is_db_chaining_on]
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_CrossDatabaseQueries) S)
  ) u

UNION
select 'Server Option' AS ObjName, InstanceName, u.Name
from (	
    SELECT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_ServerOptions
    GROUP BY Name, value, minimum, maximum, value_in_use
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_ServerOptions) S)
  ) u


UNION
select 'Database Owner' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName, Name
    FROM tempdb.dbo.AAG_DBowner
    WHERE Name in (Select distinct dg.Database_name
					from master.sys.dm_hadr_database_replica_cluster_states dg
					INNER join master.sys.availability_replicas ar on ar.replica_id = dg.replica_id
					lEFT join master.sys.availability_groups ag on ag.group_id = ar.group_id
					WHERE ag.name IN (select distinct ag.name as [name]
									from sys.dm_hadr_availability_replica_states ars
									inner join sys.availability_groups ag on ag.group_id = ars.group_id 
									where ars.role_desc = 'PRIMARY'))

    GROUP BY Name, DBowner
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_DBowner) S)
  ) u


UNION
select 'Message' AS ObjName, InstanceName, CAST(message_id AS nVARCHAR(max)) AS Name
 from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName,  message_id 
    FROM tempdb.dbo.AAG_MSG
    GROUP BY message_id
	,language_id
	,severity
	,is_event_logged
	,text
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_MSG) S)
  ) u


UNION
select 'Role' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName,  RoleName + ' ' + MemberName AS Name 
    FROM tempdb.dbo.AAG_Roles
    GROUP BY RoleName, MemberName 
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_Roles) S)) u


UNION
select 'Permission' AS ObjName, InstanceName, u.Name
from (	
    SELECT DISTINCT MAX([InstanceName]) AS InstanceName, [name]
    FROM tempdb.dbo.AAG_Permissions
    GROUP BY [name]
      ,[class]
      ,[type]
      ,[permission_name]
      ,[state]
      ,[is_disabled]
    HAVING COUNT(*) < (SELECT COUNT (*) FROM (SELECT DISTINCT InstanceName FROM tempdb.dbo.AAG_Permissions) S)
  ) u