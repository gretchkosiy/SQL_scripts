SELECT t1.name, databasepropertyex(t1.name, 'Recovery') as RM,
            '-' AS [AAGname],
	        DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus1.backup_finish_date)) AS LastBackUpTime_FULL,
	        DATEADD(mi, -DATEDIFF(mi, GETUTCDATE(), GETDATE()), MAX(bus.backup_finish_date))  AS LastBackUpTime_LOG
            FROM master.dbo.sysdatabases t1 
	        LEFT OUTER JOIN msdb.dbo.backupset bus ON bus.database_name = t1.name AND bus.type= 'L' 
	        LEFT OUTER JOIN msdb.dbo.backupset bus1 ON bus1.database_name = t1.name AND (bus1.type= 'D' OR bus1.type= 'I')
            where t1.name not in ('tempdb') 
            AND t1.dbid not in (select database_id from  sys.dm_hadr_database_replica_states)
            AND databasepropertyex(t1.name,'status')= 'ONLINE'
            AND DATEDIFF(dd,t1.crdate,getdate()) >= 1 
            GROUP BY t1.name