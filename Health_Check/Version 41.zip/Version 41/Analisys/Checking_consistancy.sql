

SELECT 


UPDATE [dbo].[InstanceInformation]
  SET [Instance Name] = REPLACE([Instance Name],'.ecwapac.local','')

UPDATE [dbo].[InstanceInformation]
  SET [Host Name] = REPLACE([Host Name],'.ecwapac.local','')


UPDATE [dbo].[InstanceInformation]
  SET VALUE = REPLACE(VALUE,'.ecwapac.local','')
  WHERE TYPE = 'Instance Name'

UPDATE [dbo].[IPs]
  SET [InstanceName] = REPLACE([InstanceName],'.ecwapac.local','')

UPDATE [dbo].[OperationSystem]
  SET [Host Name] = REPLACE([Host Name],'.ecwapac.local','')


UPDATE [dbo].[Hardware]
  SET [Host Name] = REPLACE([Host Name],'.ecwapac.local','')