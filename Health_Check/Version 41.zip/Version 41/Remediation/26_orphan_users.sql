IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##ORPHANUSER')	DROP TABLE ##ORPHANUSER

CREATE TABLE ##ORPHANUSER 
( 
	DBNAME VARCHAR(100), 
	USERNAME VARCHAR(100), 
	[STATUS] VARCHAR(100), 
	[LOGIN TYPE] VARCHAR(100) ,
	[Login name (probable)] VARCHAR(100) 
) 

EXEC master.sys.sp_MSforeachdb ' USE [?] 
INSERT INTO ##ORPHANUSER 
SELECT DB_NAME() DBNAME, SU.NAME, 
CASE  When SU.[hasdbaccess] = 0 then ''Disabled''
       ELSE ''''
END [STATUS], 
(CASE  
WHEN SU.ISNTGROUP = 0 AND SU.ISNTUSER = 0 THEN ''SQL LOGIN'' 
WHEN SU.ISNTGROUP = 1 THEN ''NT GROUP'' 
WHEN SU.ISNTGROUP = 0 AND SU.ISNTUSER = 1 THEN ''NT LOGIN'' 
END) [LOGIN TYPE] 
--,SU.SID
,ISNULL(SL1.Name,'''')AS [Login name (probable)]
FROM sys.sysusers SU
	LEFT JOIN sys.syslogins SL ON SL.SID = SU.SID
	LEFT JOIN sys.syslogins SL1 ON SL1.Name collate SQL_Latin1_General_CP1_CI_AS = SU.Name collate SQL_Latin1_General_CP1_CI_AS
WHERE SL.Name IS NULL 
	 AND SU.NAME NOT LIKE ''db_%''
	 AND SU.NAME NOT IN (''public'', ''guest'', ''INFORMATION_SCHEMA'', ''sys'')' 

SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
	SERVERPROPERTY('MachineName') AS [Host Name],
	DBNAME			AS [Database Name],
	USERNAME		AS [User Name],
	STATUS			AS[Status],
	[LOGIN TYPE]	AS [Type],
	[Login name (probable)] AS [Login name (probable)]
FROM ##ORPHANUSER
WHERE DBNAME not in ('master', 'msdb', 'model', 'tempdb')
	AND [LOGIN TYPE] = 'SQL LOGIN'
DROP TABLE ##ORPHANUSER