IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##db_detail')				DROP TABLE ##db_detail

CREATE TABLE ##db_detail (
	db_name sysname NULL,
	file_name varchar(200),
	file_type varchar(1),
	file_size_total_mb decimal(19),
	file_size_used_mb decimal(19),
	auto_growth_setting varchar(200)
)


EXEC sp_MSforeachdb 'USE [?]
INSERT INTO ##db_detail
SELECT 
	DB_NAME() AS db_name,
	physical_name,
	type,
	size/128 as total_size,
	(size - CAST (FILEPROPERTY(name, ''SpaceUsed'') AS int))/128 AS total_used,
	 CASE 
	 WHEN growth = 0 THEN ''N/A''
	 WHEN growth <> 0 AND is_percent_growth = 1 AND max_size <> -1 THEN CAST(growth AS varchar) + '' percent max of '' + CAST(max_size/128 AS varchar) + '' mb''
	 WHEN growth <> 0 AND is_percent_growth = 1 AND max_size = -1 THEN CAST(growth AS varchar) + '' percent unrestricted''
	 WHEN growth <> 0 AND is_percent_growth = 0 AND max_size <> -1 THEN CAST(growth/128 AS varchar) + '' mb max of '' + CAST(max_size/128 AS varchar) + '' mb''
	 WHEN growth <> 0 AND is_percent_growth = 0 AND max_size = -1 THEN CAST(growth/128 AS varchar) + '' mb unrestricted''
	 END AS auto_growth
FROM sys.database_files'

SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
	SERVERPROPERTY('MachineName')	AS [Host Name],
	[db_name]						as [Database Name],
	file_name						AS [File Name],
	file_type						AS [Type],
	file_size_total_mb				AS [Total Size (MB)],
	file_size_used_mb				AS [Used Size (MB)],
	auto_growth_setting				AS [Auto-growth]
FROM ##db_detail