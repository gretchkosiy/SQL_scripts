IF EXISTS(select 1 from tempdb.dbo.sysobjects where name like '##dbinfo%')					DROP TABLE ##dbinfo
IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##integrity_check')			DROP TABLE ##integrity_check

CREATE TABLE ##dbinfo(ParentObject varchar(255),[Object] varchar(255),[Field] varchar(255),[Value] varchar(255))

CREATE TABLE ##integrity_check([Database Name] varchar(255),	[Last Executed] datetime)


EXEC sp_MSforeachdb 'USE [?];
INSERT INTO ##dbinfo EXEC (''DBCC DBInfo() With TableResults, NO_INFOMSGS'')
INSERT INTO ##integrity_check
select 
	A.Value AS [Database Name], 
	(select DISTINCT Value from ##dbinfo b where Field = ''dbi_dbccLastKnownGood'') AS  [Last Executed]  
from ##dbinfo A 
WHERE A.Field = ''dbi_dbname'';
TRUNCATE TABLE ##dbinfo'

SELECT 
			CASE 
				WHEN @@SERVERNAME IS NULL THEN SERVERPROPERTY('MachineName')
				ELSE @@SERVERNAME
			END  AS [Instance Name], 
	SERVERPROPERTY('MachineName') AS [Host Name],
	A.name AS [Database Name], 
	CASE 
		WHEN C.mirroring_role_desc IS NOT NULL THEN C.mirroring_role_desc
		ELSE A.state_desc 
	END AS [State],
	CASE 
		WHEN I.[Last Executed] IS NULL THEN '1900-01-01 00:00:00.000'
		ELSE I.[Last Executed]
	END [Last Executed]
FROM sys.databases A
LEFT JOIN sys.database_mirroring C ON A.name = DB_NAME(C.database_id)
LEFT JOIN ##integrity_check I ON I.[Database Name] = A.name 