/*
-- http://williamweber.net/table-disk-space-usage-by-filegroup-and-partition/

IF EXISTS(select 1 from tempdb.dbo.sysobjects where name = '##Partitions')			
	DROP TABLE ##Partitions

CREATE TABLE ##Partitions (
	[InstanceName] VARCHAR(MAX),
	DatabaseName VARCHAR(MAX),
	[Table] VARCHAR(MAX),
	IndexId VARCHAR(MAX),
	IndexName VARCHAR(MAX),
	PartitionNumber BIGINT,
	LowerBoundary sql_variant,
	UpperBoundary sql_variant,
	FileGroupName sql_variant,
	UsedPages_MB NUMERIC(18,2),
	DataPages_MB NUMERIC(18,2),
	ReservedPages_MB NUMERIC(18,2),
	[RowCount] BIGINT,
	[Type] VARCHAR(MAX),
	avg_frag_perc sql_variant
	)


INSERT INTO ##Partitions 
EXEC sp_Myforeachdb 'USE[?];
SELECT
	   @@SERVERNAME AS [InstanceName],
       DB_NAME() AS ''DatabaseName''
       --,OBJECT_NAME(p.OBJECT_ID) AS ''TableName''
	   ,''['' + [ss].[name] + ''].['' + [t].[name] + '']'' AS [Table]
       ,p.index_id AS ''IndexId''
       ,CASE
              WHEN p.index_id = 0 THEN ''HEAP''
              ELSE i.name
       END AS ''IndexName''
       ,p.partition_number AS ''PartitionNumber''
       ,prv_left.VALUE AS ''LowerBoundary''
       ,prv_right.VALUE AS ''UpperBoundary''
       ,CASE
              WHEN fg.name IS NULL THEN ds.name
              ELSE fg.name
       END AS ''FileGroupName''
       ,CAST(p.used_page_count * 0.0078125 AS NUMERIC(18,2)) AS ''UsedPages_MB''
       ,CAST(p.in_row_data_page_count * 0.0078125 AS NUMERIC(18,2)) AS ''DataPages_MB''
       ,CAST(p.reserved_page_count * 0.0078125 AS NUMERIC(18,2)) AS ''ReservedPages_MB''
       ,CASE
              WHEN p.index_id IN (0,1) THEN p.ROW_COUNT
              ELSE 0
       END AS [RowCount]
       ,CASE
              WHEN p.index_id IN (0,1) THEN ''data''
              ELSE ''index''
       END ''Type''
       ,ind_stats.avg_fragmentation_in_percent as avg_frag_perc 


FROM sys.dm_db_partition_stats p
	  INNER JOIN sys.tables AS [t] ON [t].[object_id] = [p].[object_id]
	  INNER JOIN sys.schemas ss on ss.schema_id = t.schema_id
       INNER JOIN sys.indexes i
              ON i.OBJECT_ID = p.OBJECT_ID AND i.index_id = p.index_id
       INNER JOIN sys.data_spaces ds
              ON ds.data_space_id = i.data_space_id
       LEFT OUTER JOIN sys.partition_schemes ps
              ON ps.data_space_id = i.data_space_id
       LEFT OUTER JOIN sys.destination_data_spaces dds
              ON dds.partition_scheme_id = ps.data_space_id
              AND dds.destination_id = p.partition_number
       LEFT OUTER JOIN sys.filegroups fg
              ON fg.data_space_id = dds.data_space_id
       LEFT OUTER JOIN sys.partition_range_values prv_right
              ON prv_right.[function_id] = ps.[function_id]
              AND prv_right.boundary_id = p.partition_number
       LEFT OUTER JOIN sys.partition_range_values prv_left
              ON prv_left.[function_id] = ps.[function_id]
              AND prv_left.boundary_id = p.partition_number - 1
       LEFT JOIN sys.dm_db_index_physical_stats (DB_ID(),null, Null, Null, NULL) ind_stats 
              ON     ind_stats.database_id = DB_ID()
              AND ind_stats.object_id = p.object_id
              AND ind_stats.index_id = p.index_id
              AND ind_stats.partition_number = p.partition_number

       --Left join dbo.sysfiles SF 
       --     ON SF.groupid = fg.groupid
WHERE
       OBJECTPROPERTY(p.OBJECT_ID, ''ISMSSHipped'') = 0
	   AND prv_left.VALUE IS NOT NULL 
	   AND prv_right.VALUE IS NOT NULL  
       --AND p.index_id in (0,1)
	   
	   '


SELECT * FROM ##Partitions
DROP TABLE ##Partitions


*/