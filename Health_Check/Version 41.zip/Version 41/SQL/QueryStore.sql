IF substring(convert(char(12),serverproperty('productversion')), 1, 2) IN ('13','14','15','16')
BEGIN
	CREATE TABLE ##T(
		InstanceName NVARCHAR(max)
		,DatabaseName NVARCHAR(max)
		,desired_state_desc NVARCHAR(max)
		,actual_state_desc NVARCHAR(max)
		,max_storage_size_mb INT
	);


	EXEC sp_msforeachdb 'USE [?]; INSERT INTO ##T SELECT 
		@@SERVERNAME AS [InstanceName]
		,DB_NAME() AS [DatabaseName]
		,desired_state_desc
		,actual_state_desc
		,max_storage_size_mb
	FROM sys.database_query_store_options'


	SELECT * FROM ##T

	DROP TABLE ##T

END