IF SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)),1,CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)))-1) > 10 
EXEC( 'SELECT  
		@@SERVERNAME as [Instance Name],
		DB_NAME(sd.source_database_id) AS [SourceDatabase], 
		sd.name AS [Snapshot],
		--mf.name AS [Filename], 
	        mf.physical_name AS [Filename], 
		size_on_disk_bytes/1024/1024  AS [Size (MB)],
		mf2.size/128 AS [Allocated Size (MB)]
		,sd.create_date
		,suser_sname(sd.owner_sid) AS [Owner]
FROM sys.master_files mf
JOIN sys.databases sd
	ON mf.database_id = sd.database_id
JOIN sys.master_files mf2
	ON sd.source_database_id = mf2.database_id
	AND mf.file_id = mf2.file_id
CROSS APPLY sys.dm_io_virtual_file_stats(sd.database_id, mf.file_id)
WHERE mf.is_sparse = 1
AND mf2.is_sparse = 0
ORDER BY 1') 
ELSE 
SELECT  
		@@SERVERNAME as [Instance Name],
		''  AS [SourceDatabase], 
		''  AS [Snapshot],
	    ''  AS [Filename], 
		0  AS [Size (MB)],
		0  AS [Allocated Size (MB)]
		,'1900-01-01' AS create_date
		,'' AS [Owner]