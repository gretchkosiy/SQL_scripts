    SELECT 
		@@servername AS InstanceName, 
		id,
		status,
		Path,
		start_time,
		last_event_time


		--,*
	FROM sys.traces