SELECT @@SERVERNAME AS InstaneName, 'Full' as [type], [name], RM, AAGname, MAX(LastBackUpTime_FULL) AS [Last Backup]
FROM tempdb.dbo.$tableName 
GROUP BY  [name],[AAGname], RM
UNION 
--SELECT @dbListTL = @dbListTL  + ', ' + [name]
SELECT @@SERVERNAME AS InstaneName, 'Tran' as [type], [name], RM, AAGname, MAX(LastBackUpTime_LOG) AS [Last Backup]
FROM tempdb.dbo.$tableName 
WHERE RM <> 'SIMPLE'
GROUP BY  [name],[AAGname], RM