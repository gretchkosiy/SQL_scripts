IF (SUBSTRING(CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)),1,CHARINDEX('.',CAST(SERVERPROPERTY('ProductVersion') AS VARCHAR(20)))-1) > 10)
	select distinct ag.name as [name]
    from sys.dm_hadr_availability_replica_states ars
	inner join sys.availability_groups ag on ag.group_id = ars.group_id 
    where ars.role_desc = 'PRIMARY'